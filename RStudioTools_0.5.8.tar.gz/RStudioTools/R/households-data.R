#' Hypothetical data on some household characteristics
#'
#' The hhid number corresponds to the children data.
#' The data contain several inconsisitencies for practicing data management and cleaning.
#'
#' \itemize{
#'   \item hhid unique household identifier 
#'   \item agehh age of household head (99: missing)
#'   \item sexhh sex of household head
#'   \item npers number of persons living in the household (99: missing)
#'   \item income monthly income with currency (factor, 99: missing)
#'   \item occup occupation category (factor)
#' }
#'
#' @format A data frame with 136 records and 6 variables
#' @docType data
#' @usage data("households")
"households"
