#' @title 2x2 tables: Odds ratio or relative risks and 95\% confidence intervals
#' @description Calculates the odds ratio or relative risks of 2 dichotoumous variables
#'
#' @param out If data is specified the name of a variable, a vector otherwise
#' @param risk If data is specified the name of a variable, a vector of the
#' same length as out otherwise
#' @param data A dataset
#' @param outT A single value or a vector of values representing the presence
#' of an outcome, should be numeric if out is numerical or logical and quotet
#' text if out is character or factor
#' @param outF Value(s) representing the presence of the outcome
#' @param riskT Value(s) representing presence of a risk factor
#' @param riskF Value(s) representing absence of a risk factor
#' @param weights Value(s) The number of observations each record represents.
#' If data is specified the name of the weighting variable, a vector of the
#'  same length as out otherwise
#' @param estimate Specifies the type of ratio to estimate OR or RR
#' @param copyToClip If TRUE the estimation table will be copied into the
#' clipboard (to paste e.g. into Excel). Will not work on Linux/Unix systems.
#' @param boot If confidene intervals should be estimated by bootstrap
#' resampling, ignored if ratio is OR
#'
#' @details
#' The function estimates the odds ratio or relative risk (risk ratio) from
#' 2 dichotomous (binary) variables or vecors.
#' By default 1 and TRUE are considered present in numerical or logical
#'  outcome or risk factor variables and text (or levels) starting with either
#' '+', 'y' or 'Y' in character or factor variables.
#' Absence of an outcome or risk factor is represented by 0, 2, FALSE, '-', 'n', 'N'.
#' In case other values represent presence and absence they can be specified
#' via outT/outF or riskT/riskF, respectively.
#' Note that if presence values are specified, absence values need to be
#' specified, too (and vice versa).
#' P values are always calculated using Fisher's exact test by calling
#'  \code{\link[stats]{fisher.test}}.
#' Confidence intervals for odds ratios are estimated using Fisher's exact formula,
#' for relative risks they can be estimated via a Wald approximation or with
#' bootstrap replicates.
#' Since P and CI for RR are calculated with different methods, it can happen
#' that P < 0.05 although the 95\% CI is not including 1 or the other way round.
#' Print and summary methods available for the tab2by2-class.
#'
#' @return An object of class 'tab2by2'; a list consisting of
#'   \item{call}{the matched call}
#'   \item{table}{the 2 x 2 table}
#'   \item{result}{a data frame providing Npos/Ntotal, prevalence, ratio, 95\%CI and P-value; this table is copied to the clipboard if the argument copyToClip is TRUE}
#'   \item{N}{Number of non-missing observations}
#'   \item{N.na}{Number of missing (omitted) observations}
#'   \item{ratio.type}{OR or RR}
#'   \item{ratio}{the estimated ratio}
#'   \item{conf.int}{the 95\% confidence interval}
#'   \item{conf.type}{the estimation method}
#'   \item{P.value}{the estimated P-Value}
#'   \item{expected}{table of expected cell counts}
#'   \item{outcome}{outcome used for table and estimation (replicated if weighted)}
#'   \item{risk.factor}{risk factor used for table and estimation (replicated if weighted)}
#'
#' @examples
#' library(RStudioTools)
#'# Example using low birthweight data
#'data("birthwt", package="MASS")
#'# Caluculate odds ratio
#'# Note: outcome (low) and risk (smoke) are coded 0/1 and will be interpreted correctly
#'t1 <- tab2by2(low, smoke, data=birthwt)
#'summary(t1)
#'
#'# Relative risk via bootstrap
#'t2 <- tab2by2(low, smoke, data=birthwt, estimate = "RR", boot = T)
#'summary(t2)
#'str(t2)
#'
#'# Example comparing bacteremia and active vs placebo treatment
#'data("bacteria", package="MASS")
#'# Note: outcome (y) has levels y and n and will be automatically interpreted correctly
#'# risk factor vatiable has levels a (active) and p (placebo) which must be specified
#'t3 <- tab2by2(y, ap, data=bacteria, riskT="a", riskF="p")
#'summary(t3)
#'
#'# Example with weights, claculating odds of survival (positive outcome) 1st calss vs 2nd & 3rd
#'df <-  data.frame(Titanic)
#'t4 <- tab2by2(Survived, Class, data=df, riskT="3rd", riskF=c("1st","2nd"), weights = Freq)
#'summary(t4)
#' 
#' @export

tab2by2 <-
function (out, risk, data = NULL, outT = NULL, outF = NULL, riskT = NULL, 
    riskF = NULL, weights, estimate = c("OR", "RR"), copyToClip = F, 
    boot = F) 
{
    if (is.null(outT) != is.null(outF)) 
        stop("Outcome values T/F, either both or no value must be specified")
    if (is.null(riskT) != is.null(riskF)) 
        stop("Risk factor values T/F, either both or no value must be specified")
    if (is.null(data)) {
        x <- out
        y <- risk
        if (!missing(weights)) 
            w <- weights
    }
    else {
        x <- data[, deparse(substitute(out))]
        y <- data[, deparse(substitute(risk))]
        if (!missing(weights)) 
            w <- data[, deparse(substitute(weights))]
    }
    if (length(x) != length(y)) 
        stop("out and risk not of same length")
    if (!missing(weights)) {
        if (length(x) != length(w)) 
            stop("w must be of same length as out and risk")
        else if (any(w < 0 | is.na(w))) 
            stop("Negative or NA weigths not allowed")
        else if (any(w != as.integer(w))) 
            stop("Only integer weight numbers allowed")
        else {
            x <- rep(x, w)
            y <- rep(y, w)
        }
    }
    if (class(x) %in% c("numeric", "integer", "logical")) {
        if (is.null(outT)) 
            outT <- 1
        if (is.null(outF)) 
            outF <- c(0, 2)
        x[!x %in% c(outT, outF)] <- NA
    }
    else if (class(x) %in% c("character", "factor")) {
        if (is.null(outT)) 
            x <- substr(tolower(as.character(x)), 1, 1)
        if (is.null(outT)) 
            outT <- c("+", "y")
        if (is.null(outF)) 
            outF <- c("-", "n")
        x[!x %in% c(outT, outF)] <- NA
    }
    else stop(paste("Outcome class", class(x), "is not supported"))
    if (class(y) %in% c("numeric", "integer", "logical")) {
        if (is.null(riskT)) 
            riskT <- 1
        if (is.null(riskF)) 
            riskF <- c(0, 2)
        y[!y %in% c(riskT, riskF)] <- NA
    }
    else if (class(y) %in% c("character", "factor")) {
        if (is.null(riskT)) 
            y <- substr(tolower(as.character(y)), 1, 1)
        if (is.null(riskT)) 
            riskT <- c("+", "y")
        if (is.null(riskF)) 
            riskF <- c("-", "n")
        y[!y %in% c(riskT, riskF)] <- NA
    }
    else stop(paste("Risk factor class", class(y), "is not supported"))
    if (any(outT %in% outF) | any(outF %in% outT) | any(riskT %in% 
        riskF) | any(riskF %in% riskT)) 
        stop(paste("Values for true and false must be different"))
    tab <- table(y[!is.na(x) & !is.na(y)] %in% riskT, x[!is.na(x) & 
        !is.na(y)] %in% outT)
    if (any(dim(tab) != 2)) 
        stop("Values within a row or a column cannot be both 0")
    tab <- tab[2:1, 2:1]
    rownames(tab) <- paste(deparse(substitute(risk)), "[", c("+", 
        "-"), "]", sep = "")
    colnames(tab) <- paste(deparse(substitute(out)), "[", c("+", 
        "-"), "]", sep = "")
    resmat <- data.frame(matrix(NA, 2, 5))
    rownames(resmat) <- paste(deparse(substitute(risk)), "[", 
        c("-", "+"), "]", sep = "")
    colnames(resmat) <- c(paste(deparse(substitute(out)), "[N+/Ntot]", 
        sep = ""), "Prev", match.arg(estimate), "CI95%", "P")
    resmat[1, ] <- c(paste(tab[2, 1], "/", sum(tab[2, ]), sep = ""), 
        round(tab[2, 1]/sum(tab[2, ]) * 100, 1), "1", "-", "-")
    resmat[2, 1:2] <- c(paste(tab[1, 1], "/", sum(tab[1, ]), 
        sep = ""), round(tab[1, 1]/sum(tab[1, ]) * 100, 1))
    ratiotype <- match.arg(estimate)
    exact <- fisher.test(tab)
    if (ratiotype == "OR") {
        est <- exact$estimate
        ci <- exact$conf.int
        citype <- "Fisher exact"
    }
    else {
        if (boot) {
            replicates <- signif(1e+06/sqrt(sum(tab)), 1)
            riskE <- rbinom(replicates, sum(tab[1, ]), tab[1, 
                1]/sum(tab[1, ]))/sum(tab[1, ])
            riskNE <- rbinom(replicates, sum(tab[2, ]), tab[2, 
                1]/sum(tab[2, ]))/sum(tab[2, ])
            relrisk <- riskE/riskNE
            est <- median(relrisk, na.rm = T)
            ci <- quantile(relrisk, c(0.025, 0.975), na.rm = T)
            citype <- paste("Bootstrap (", format(replicates, 
                scientific = F), " rep)", sep = "")
        }
        else {
            est <- (tab[1, 1]/sum(tab[1, ]))/(tab[2, 1]/sum(tab[2, 
                ]))
            logRR <- log(est)
            SElogRR <- sqrt((1/tab[1, 1]) - (1/sum(tab[1, ])) + 
                (1/tab[2, 1]) - (1/sum(tab[2, ])))
            ci <- exp(logRR + c(-1, 1) * qnorm(0.975) * SElogRR)
            citype <- "Wald (Z approx)"
        }
    }
    resmat[2, 3] <- round(est, 2)
    resmat[2, 4] <- paste(round(ci[1], 2), "-", round(ci[2], 
        2), sep = "")
    if (exact$p.value >= 0.0095) 
        niceP <- round(exact$p.value, 2)
    else if (exact$p.value < 0.001) 
        niceP <- "<0.001"
    else niceP <- round(exact$p.value, 3)
    resmat[2, 5] <- niceP
    if (copyToClip) {
        ctable <- cbind(list(Risk.factor = rownames(resmat)), 
            resmat)
        WINDOWS <- .Platform$OS.type == "windows"
        if (WINDOWS) 
            write.table(ctable, "clipboard", sep = "\t", row.names = F)
        else write.table(ctable, file = pipe("pbcopy"), sep = "\t", 
            row.names = F)
    }
    res <- list(call = match.call(), table = tab, result = resmat, 
        N = sum(tab), N.na = sum(is.na(x) | is.na(y)), ratio.type = ratiotype, 
        ratio = est, conf.int = ci, conf.type = citype, p.value = exact$p.value, 
        expected = outer(rowSums(tab), colSums(tab), "*")/sum(tab), 
        outcome = x, risk.factor = y)
    class(res) <- "tab2by2"
    res
}
