#' @export
print.tab2by2 <-
function (object) 
{
    print(object$table)
    print(format(object$result, width = 8, quote = F, justify = "right"))
}
