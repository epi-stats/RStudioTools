#' Hypothetical data on child health
#'
#' A dataset containing basic demographic, anthropometric and morbidity data.
#' 
#' The data contain several inconsisitencies 
#' for practicing data management and cleaning.
#'
#' \itemize{
#'   \item hhid unique household identifier 
#'   \item childid unique child identifier
#'   \item age age in years
#'   \item sex 1: male, 2:female
#'   \item height height in cm 
#'   \item weight weight in kg 
#'   \item wfhz weight for height Z-scores (using WHO reference population)
#'   \item breastf breastfed 
#'   \item plasmod Plasmodium infection 
#' }
#'
#' @format A data frame with 187 records and 9 variables
#' @docType data
#' @usage data("children")
"children"
