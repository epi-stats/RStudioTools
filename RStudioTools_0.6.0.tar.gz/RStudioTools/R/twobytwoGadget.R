#' @title RStudio gadget for 2 x 2 tables
#' 
#' @description Interactive interface to calculate the odds ratio or relative
#'  risk (risk ratio) from 2 x 2 tables and to generate the associated R-code.
#' 
#' @param view Controls where the gadget is displayed: 'dialog' a new interactive
#' dialog window, 'pane' the RStudio pane viewer or 'browser' the system's
#' default web browser. The pain window is usually the most
#' compfortable option but the window size might be too small, 
#' if the screen size or resolution results in overlapping elements,
#' especially the option 'browser' provides more space.
#' @details An RStudio addin (shiny gadgets) -
#' runs only with RStudio (v1.1.383 or later). 
#' The application is usually invoked via the Addins pulldown menu
#' (if the toolbar is not visible, choose [View] > [Show toolbars]).
#' The associated R code can be generated (recommended),
#' which will be pasted into the R-script.
#' 
#' The first step is to select [Select data] the dataset. 
#' The tool lists all data frames wich are found in the current R session. 
#' In addition 2 example datasets are available.
#' 
#' 2 variables have to be specified: the outcome (usually disaease status) and
#' exposure (usually a risk factor) variables have to be specified.
#' If the [Values ...] set to '-auto-' values 1 and TRUE are interpreted as
#' present/yes in numerical variables and if the first character is '+', 'y'
#' or 'Y' in character or factor variables.
#' Values 0, 2, FALSE, '-', 'n', 'N' are interpreted as absent/no.
#' 
#' A 'weighting' variable can be specified if the data are in a table-like
#' format with a frequency variable indicating how many observation are
#' represented by each record (e.g variable 'Freq' in the Titanic example).
#' 
#' The button [Copy estimate to clipboard] is copying the estimate table in the clipboard.
#' The table can be pasted into spreadsheet applications like Excel or Calc.
#' 
#' [inspect] provides different options to investigate the data.
#' [info] displays number of records and variables, the variable classes
#' (types) using \code{\link[utils]{str}}.
#' [table] displays a table which can be that can be searched, filtered
#' sorted.
#' [summary] displays a summary of all variables,
#' e.g. quantiles, mean and number of misssing values for numeric data.
#' 
#' @examples
#' library(RStudioTools)
#' 
#' # Start the gadget (better to start via the [Addins] menu)
#' twobytwoGadget()
#' 
#' # Select 'Example 'children'' in [select data]
#' # Select 'plasmod' as [outcome] and 'sex' as [exposure]
#' # Text output:
#' #  - ...
#' #  -               outcome[+] outcome[-] Sum
#' #  -  exposure[+]         14         78    92
#' #  -  exposure[-]         13         81    94
#' #  -  Sum                 27        159    186
#' 
#' # Select 'Example 'Titanic'' in [select data]
#' # Select 'Survived' as [outcome] and 'Class' as [exposure]
#' # Class values can't be automatically interpretted: 
#' # Select '3rd' for [Value True] and '1st' for [Value False]
#' # Data are in table format (have a look at [inspect] > [table]
#' # Therefore we need to specify 'Freq' in [Weighting var]
#' # Text output:
#' #  - ...
#' #  -                outcome[+] outcome[-] Sum
#' #  - exposure[+]        178        528    706
#' #  - exposure[-]        203        122    325
#' #  - Sum                381        650    1031
#' 
#' @export
#' @import miniUI rstudioapi shiny
twobytwoGadget <-
function(view = c("pane", "dialog", "browser")) {
  
  ui <- miniPage(
    # tags$style(type='text/css', '#text {font-size: 90%}'), 
    # div(
    # gadgetTitleBar("2 x 2 tables",  right = miniTitleBarButton("help", "Help", primary = TRUE)),
    # style = "font-family: 'Source Sans Pro';
    # color: #000; text-align: center;
    # padding: 0px; height: 42px; font-size:50%"),
    
    miniTabstripPanel(
      miniTabPanel(
        "2 x 2",
        icon = icon("th-large"),
        fillCol(
          fillRow(
            selectInput(
              "data",
              "Select data *",
              choices = c("Example 'children'", "Example 'Titanic'"),
              width = "90%"
            ),
            selectInput(
              "weight",
              "Weighting variable",
              choices = "---",
              selected = 1,
              width = "80%"
            ),
            miniButtonBlock(
              actionButton(
                "help",
                "Help",
                icon = icon("question"),
                style = "color: #ffffff; background-color: #444444"
              ),
              actionButton("quit", "Quit", icon = icon("close"),
                           style = "color: #ffffff; background-color: #444444"),
              border = "bottom"
            ),
            flex = c(2,2, 1)
            # verbatimTextOutput("infodata"),
            # flex = c(1.2, 1, 1.2)
          ),
          fillRow(
            selectInput(
              "ratio",
              "Estimate *",
              choices = c("Odds ratio", "Relative risk"),
              selected = 1,
              width = "90%"
            ),
            selectInput(
              "outcome",
              "Outcome (disease status)*",
              choices = "---",
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "outT",
              "Value yes/present",
              choices = "-auto-",
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "outF",
              "Value no/absent",
              choices = "-auto-",
              multiple = F,
              width = "90%"
            ),
            flex = c(1, 1.8, 1.2, 1.2)
          ),
          fillRow(
            fillCol(
              selectInput(
                "risk",
                "Expsosure (risk factor)*",
                choices = "---",
                multiple = F,
                width = "90%"
              ),
              selectInput(
                "riskT",
                "Value yes/present",
                choices = "-auto-",
                multiple = F,
                width = "90%"
              ),
              selectInput(
                "riskF",
                "Value no/absent",
                choices = "-auto-",
                multiple = F,
                width = "90%"
              )
            ),
            fillCol(#plotOutput("plot"),
              verbatimTextOutput("text"))
            ,
            flex = c(1, 4)
          ),
          fillRow(miniButtonBlock(
            actionButton("pasteCode", "Paste code into script"),
            actionButton("copyClip", "Copy estimate to clipboard (Win/osX)")
          ))
          ,
          flex = c(1, 0.9, 5, 0.6)
        )
      ),
      
      ## standard inspect panel
      miniTabPanel(
        "inspect",
        icon = icon("search-plus"),
        miniTabstripPanel(
          miniTabPanel("str", icon = icon("info"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput("str")
                       ))),
          miniTabPanel("table", icon = icon("table"),
                       miniContentPanel(fillCol(
                         dataTableOutput('table')
                       ))),
          miniTabPanel("summary", icon = icon("list-ol"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput('summary')
                       )))
        ),
        p("")
      )
    )
  )
  
  server <- function(input, output, session) {
    varclass <- function(vclass) {
      return(colnames(dataInput()[sapply(dataInput(), class) %in% vclass]))
    }
    
    dataInput <- reactive({
      if (input$data == "Example 'Titanic'")
        data.frame(Titanic)
      else if (input$data == "Example 'children'") {
        RStudioTools::children
      }
      else
        get(input$data)
    })
    
    sData <- reactive({
      datas <-
        Filter(function(x)
          inherits(get(x), "data.frame"),
          ls(envir = .GlobalEnv))
      c(datas, "Example 'children'", "Example 'Titanic'")
    })
    
    observe({
      updateSelectInput(session, "data", choices = sData())
    })
    
    observeEvent(input$data,
                 {
                   #updateSelectInput(session, "data",  choices = sData())
                   updateSelectInput(session,
                                     "weight",
                                     choices = c("---", varclass(c(
                                       "numeric", "integer"
                                     ))),
                                     selected = "---")
                   updateSelectInput(
                     session,
                     "outcome",
                     choices = c("---", varclass(
                       c("numeric", "integer", "logical", "factor", "character")
                     )),
                     selected = "---"
                   )
                   updateSelectInput(session,
                                     "risk",
                                     choices = c("---", varclass(
                                       c("numeric", "integer", "logical", "factor", "character")
                                     )),
                                     selected = "---")
                 })
    
    observeEvent(input$outcome,
                 {
                   if (input$outcome %in% colnames(dataInput())) {
                     vf <- which(colnames(dataInput()) == input$outcome)
                     updateSelectInput(session, "outT", choices = c("-auto-", sort(unique(
                       as.character(dataInput()[, vf])
                     ))))
                     updateSelectInput(session, "outF", choices = c("-auto-", sort(unique(
                       as.character(dataInput()[, vf])
                     ))))
                   }
                 })
    
    observeEvent(input$risk,
                 {
                   if (input$risk %in% colnames(dataInput())) {
                     vf <- which(colnames(dataInput()) == input$risk)
                     updateSelectInput(session, "riskT", choices = c("-auto-", sort(unique(
                       as.character(dataInput()[, vf])
                     ))))
                     updateSelectInput(session, "riskF", choices = c("-auto-", sort(unique(
                       as.character(dataInput()[, vf])
                     ))))
                   }
                 })
    
    # output$infodata <- renderPrint({
    #   cat(paste(
    #     ncol(dataInput()),
    #     " variables, ",
    #     nrow(dataInput()),
    #     " records",
    #     sep = ""
    #   ))
    #   if (input$weight != "---") {
    #     sumWt <- try(sum(dataInput()[, input$weight], na.rm = T), T)
    #     if (class(sumWt) != "try-error")
    #       cat(paste("\nSum of weights:", round(sum(
    #         dataInput()[, input$weight]
    #       ))))
    #   }
    # })
    
    check2x2 <- function() {
      ret <- "ok"
      if (!input$outcome %in% colnames(dataInput()) |
          !input$risk %in% colnames(dataInput()))
        ret <- "Date changed updating in progress"
      if (input$weight != "---" &
          !input$weight %in% colnames(dataInput()))
        ret <- "Date changed updating in progress"
      if (input$outcome == input$risk)
        ret <- "Outcome and risk can't be the same variable"
      else if (sum(c(input$outT, input$outF) %in% "---") == 1)
        ret <-
          "Outcome True/False must be both -auto- or both speciefied"
      else if (sum(c(input$riskT, input$riskF) %in% "---") == 1)
        ret <-
          "Exposure True/False must be both -auto- or both speciefied"
      else {
        if (input$weight != "---") {
          if (anyNA(dataInput()[, input$weight]))
            ret <- "Missing in weight variable not allowed"
          if (min(dataInput()[, input$weight], na.rm = T) < 0)
            ret <- "Negative values in weight variable not allowed"
          if (any(dataInput()[, input$weight] != as.integer(dataInput()[, input$weight])))
            ret <- "Only integer values in weight variable allowed"
        }
      }
      ret
    }
    
    est2x2 <- function(copy = F) {
      outcome <- dataInput()[, input$outcome]
      if (class(outcome) == "factor")
        outcome <- as.character(outcome)
      exposure <- dataInput()[, input$risk]
      if (class(exposure) == "factor")
        exposure <- as.character(exposure)
      if (input$weight != "---")
        wt <- dataInput()[, input$weight]
      if (input$outT == "-auto-")
        ot <- NULL
      else
        ot <- input$outT
      if (input$outF == "-auto-")
        of <- NULL
      else
        of <- input$outF
      if (input$riskT == "-auto-")
        rt <- NULL
      else
        rt <- input$riskT
      if (input$riskF == "-auto-")
        rf <- NULL
      else
        rf <- input$riskF
      if (input$ratio == "Odds ratio")
        rat <- "OR"
      else
        rat <- "RR"
      if (input$weight != "---")
        res <-
        try(RStudioTools::tab2by2(
          outcome,
          exposure,
          outT = ot,
          outF = of,
          riskT = rt,
          riskF = rf,
          estimate = rat,
          weights = wt,
          copyToClip = copy
        ),
        T)
      else
        res <-
        try(RStudioTools::tab2by2(
          outcome,
          exposure,
          outT = ot,
          outF = of,
          riskT = rt,
          riskF = rf,
          estimate = rat,
          copyToClip = copy
        ),
        T)
      res
    }
    
    output$text <- renderPrint({
      if (input$outcome == "---" | input$risk == "---")
        cat("Outcome and exposure must be specified")
      else {
        check <- try(check2x2(), T)
        if (check != "ok")
          cat(check)
        else {
          res <- try(est2x2(), T)
          if (class(res) == "try-error")
            cat("Can't generate valid 2x2 table")
          else {
            cat(paste(
              ifelse(
                res$ratio.type == "OR",
                "Odds ratio: ",
                "Relative risk (risk ratio): "
              ),
              round(res$ratio, 3),
              sep = ""
            ))
            cat(paste(
              "\nNumber of observations:",
              res$N,
              ifelse(
                res$N.na > 0,
                paste(
                  "(",
                  res$N.na,
                  " observations deleted due to missingness)",
                  sep = ""
                ),
                ""
              )
            ))
            cat("\n2 x 2 table observed")
            print(addmargins(res$table))
            cat("2 x 2 table expected\n")
            print(round(res$expected, 1))
            cat("\nEstimates\n")
            print(format(
              res$result,
              width = 8,
              quote = F,
              justify = "right"
            ))
            cat(
              paste(
                "\nConfidence interval estimation:",
                res$conf.type,
                "\nP-value estimation: Fisher exact\n"
              )
            )
          }
        }
      }
    })

    observeEvent(input$pasteCode, {
      if (input$outcome == "---" | input$risk == "---")
        cat("Outcome and exposure must be specified")
      else {
        check <- check2x2()
        if (check != "ok")
          cat(check)
        else {
          res <- try(est2x2(), T)
          if (class(res) == "try-error")
            cat("Can't generate valid 2x2 table")
          else {
            mtxt <-
              setdiff(paste("tab", 1:100, sep = ""), ls(pos = .GlobalEnv))[1]
            if (input$data == "Example 'children'")
              dtxt <- "children"
            else if (input$data == "Example 'Titanic'")
              dtxt <- "data.frame(Titanic)"
            else
              dtxt <- input$data
            txt <-
              paste(
                mtxt,
                " <- tab2by2(",
                input$outcome,
                ", ",
                input$risk,
                ", data = ",
                dtxt,
                ", ",
                sep = ""
              )
            if (input$outT != "-auto-") {
              if (class(dataInput()[, input$outcome]) %in% c("factor", "character"))
                ovtxt <-
                  paste("outT = \"",
                        input$outT,
                        "\", outF = \"",
                        input$outF,
                        "\", ",
                        sep = "")
              else
                ovtxt <-
                  paste("outT = ",
                        input$outT,
                        ", outF = ",
                        input$outF,
                        ", ",
                        sep = "")
              txt <- paste(txt, ovtxt, sep = "")
            }
            if (input$riskT != "-auto-") {
              if (class(dataInput()[, input$risk]) %in% c("factor", "character"))
                evtxt <-
                  paste("riskT = \"",
                        input$riskT,
                        "\", riskF = \"",
                        input$riskF,
                        "\", ",
                        sep = "")
              else
                evtxt <-
                  paste("riskT = ",
                        input$riskT,
                        ", riskF = ",
                        input$riskF,
                        ", ",
                        sep = "")
              txt <- paste(txt, evtxt, sep = "")
            }
            if (input$weight != "---")
              txt <-
              paste(txt, "weights = ", input$weight, ", ", sep = "")
            if (input$ratio == "Odds ratio")
              rat <- "OR"
            else
              rat <- "RR"
            txt <- paste(txt, "estimate = \"",rat,"\")", sep = "")
            rstudioapi::insertText("\nlibrary(RStudioTools)\n")
            rstudioapi::insertText(txt[1])
            rstudioapi::insertText(paste("\nsummary(", mtxt, ")\n", sep =
                                           ""))
            assign(mtxt, res, pos = .GlobalEnv)
          }
        }
      }
    })
    
    observeEvent(input$copyClip, {
      if (input$outcome == "---" | input$risk == "---")
        cat("Outcome and exposure must be specified")
      else {
        check <- check2x2()
        if (check != "ok")
          cat(check)
        else {
          res <- try(est2x2(copy = T), T)
          if (class(res) == "try-error")
            cat("Can't generate valid 2x2 table")
        }
      }
    })

    ## standard inspect output when no data not possible
    ## - inspect -
    
    output$str <- renderPrint({
      str(
        dataInput(),
        give.attr = F,
        width = 70,
        strict.width = 'cut'
      )
    })
    
    output$table <- renderDataTable({
      dataInput()
    },
    options = list(pageLength = 7,  lengthMenu = c(5, 10, 25)))
    
    output$summary <- renderPrint({
      op <- options()
      options(width = 85)
      print(summary(dataInput()))
      options(op)
    })
    
    observeEvent(input$help, {
      RStudioTools:::browserHelp("twobytwoGadget", "RStudioTools")
    })
    
    observeEvent(input$quit, {
      stopApp(print("Good bye"))
    })
  }
  
  view <- match.arg(view)
  viewer <- RStudioTools:::selectViewer(view, height = 750, width = 800)
  runGadget(ui, server, viewer = viewer, stopOnCancel = F)
}
