#' @title RStudio gadget to manage data
#'
#' @description Interactive interface for data management.
#' Data frames can be sorted, subsetted, appended and merged. 
#' Variable names can be renamed or converted to lowercase and the app detects
#' violations of R naming conventions.
#' 
#' @param view Controls where the gadget is displayed: 'dialog' a new interactive
#' dialog window, 'pane' the RStudio pane viewer or 'browser' the system's
#' default web browser. The pain window is usually the most
#' compfortable option but the window size might be too small, 
#' if the screen size or resolution results in overlapping elements,
#' especially the option 'browser' provides more space.
#' @details An RStudio addin (shiny gadgets) -
#' runs only with RStudio (v1.1.383 or later). 
#' The application is usually invoked via the Addins pulldown menu
#' (if the toolbar is not visible, choose [View] > [Show toolbars]).
#' The associated R code can be generated (recommended),
#' which will be pasted into the R-script.
#' 
#' [select data] pull down menu which lists all data frames available in the
#' R session. If the user has no data frames defined, 'No data in current R
#' session' appears. In this case the application has to be closed and data
#' needs to be be loaded or imported.
#' 
#' The tab panel consists of 6 tabs.
#' 
#' [inspect] provides different options to investigate the data.
#' [info] displays number of records and variables, the variable classes
#' (types) using \code{\link[utils]{str}}.
#' [table] displays a table which can be that can be searched, filtered
#' sorted.
#' [summary] displays a summary of all variables,
#' e.g. quantiles, mean and number of misssing values for numeric data.
#' 
#' [manage.data] manipulate variable and row names.
#' Single variables can be renamed or variable names can be converted to
#' lowercase.
#' Usually, during data import R ensures that all varible names have valid
#' names but there are certain situations 
#' (e.g. import data from Excel) where variable names violates
#' R naming convention.
#' If R incompatible variable names are detected (e.g. starting 
#' with numbers, containing spaces or dollar signs) a warning message appears.
#' When the option is checked variables will be renamed to a valid R names
#' if required. The application checks if name conversion will result in a
#' conflict with another variable name (e.g. if the variables 'AGE' and 'age'
#' exist both, conversion to lowercase will prompt a warning message).
#' It is important to keep in mind that the rownames in R are NAMES
#' and not record numbers as in most other statistical packages.
#' Although, this has cerain advantages it is recommended - especially for
#' people new to R - to match the rownames to the record numbers.
#' The tool indicates if the row names are matching the record numbers and
#' offers to chenge them if this not the case.
#' 
#' [sort] Data frames can be soerted in descending or ascending direction.
#' Missing values are put last.
#' 
#' [subset.data] generates a new data frame as a subset of the original data.
#' [name of new data] the name for the new data frame.
#' If no (valid) name is provided a name will generated (usually X).
#' If an object with the specified name already exisis, 
#' a warning message will appear but the command can be executed (the object
#' will be replcaed).
#' [expression] the condition to select the subset. 
#' Only those records where the condition is true will remain in the new data.
#' The application checks if the condition is syntactically correct.
#' If the field is left empty all records will remain in the new data frame.
#' A condition can contain one or more variables and all typical
#' operators like == != > < %in% is.na  & | ! . Missing data
#' may result in unexpected behaviour. To drop all records with missing values
#' in a certain variable use '! varname %in% NA' or '!is.na(varname)'
#' (instead of 'varname != NA').
#' Text values (or factor levels) should be quoted,  e.g. 'sex %in% "female"'.
#' Conditions can contain logical connectives, e.g. 'age > 18 & age < 65'.
#' The application is also useful for data cleaning, e.g. identify inconsistent
#' value combinations, e.g. 'startdate > enddate' or 'sex == "male" & 
#' pregnancy == TRUE'.
#' If not all variables should remain in the new data frame, the variables to
#' keep can be selected in [select variables] (if left empty all are kept).
#' 
#' [append.data] is used to combine 2 datasets row-wise. A 2nd dataset and a
#' name for the combined data frame should be specified.
#' If both data frames share the same variables (same order is not required)
#' the tool performs a simple \code{\link[base]{rbind}}.
#' If there are variables in one data frame without a matching variable in the
#' other one, those variables can either be dropped or kept.
#' All values will be set to NA in the records comming from the other data.
#' Variables can be renamed using [manage.data] before appending.
#' If the same variable name occurs in both data frames but the variables are
#' of different types (e.g. class numeric and factor) they will be transformed
#' character in the combined dataset.  Factors have their levels expanded as
#' necessary.
#' 
#' [merge.data] is used to merge to 2 data frames via a certain identifier
#' variable (ID). 2 data frames have to be specified. For each data frame
#' the name of the ID variable has to be specified (but the ID has often the
#' same name in both data frames).
#' The default math method is 1:1 but often several records of one data frame
#' should be matched to a single record of the other, e.g. if a survey colected
#' data on person and on houshold level the option 1:m or m:1 merge has to be
#' specified in the fied [Options for merging].
#' If the ID varible(s) which are expected to have unique values contain
#' duplicates, an error message will appear.
#' The number of non-matching IDs for both datasets are displayed and in
#' contrast to the default behaviour of the underlying function
#' \code{\link[base]{merge}} non-matching IDs will remain in the combined
#' dataset. M:N merging (i.e. both not unique) and merging record by record
#' are usually not recopmmended and not supportet.
#' A new variable (usually .merge0) will values 1 to 3. 1: record occured only
#' in 1st data frame, 2: only in 2nd data frame, 3 in both data frames.
#' 
#' [Assign & quit] executes the action and stop the application.
#' [Assign, paste and quit] as above + paste the code into the active
#' R-script at the last curser position. 
#' Make sure that the curser is at an appropriate postion before running
#' the application.
#' [Assign, paste & continue] as above but will not stop the application.
#' 
#' Additional details and examples are provided in the package vignette (pdf)
#'  \url{/library/RStudioTools/doc/RstudioTools_introduction.pdf}
#' 
#' @examples
#' library(RStudioTools)
#' 
#' # Manipulate variable and row names
#' data("swiss")
#' head(swiss)
#' 
#' # Now start the gadget (better to start via the [Addins] menu)
#' dataGadget()
#' 
#' # Select 'swiss' in [select data], tab: [manage.data],
#' # check [Var names to lowercase] & [row names to 1:N], press [Apply]
#' head(swiss)
#' 
#' # Appending 2 datasets
#' data("lung", package="survival")
#' data("kidney", package="survival")
#' dataGadget()
#' 
#' # Change tab to [append.data]
#' # Select 'lung' in [select data] and 'kidney' in [sel data to append]
#' # Text output:
#' #  -  Varaibles in both datasets:
#' #  -  4 : time status age sex
#' #  -  Varaibles only in lung : 6 : inst ph.ecog ph.karno pat.karno mea
#' #  -  Varaibles only in kidney : 3 : id disease frail 
#' 
#' # Merging 2 datasets
#' data("children", package="RStudioTools")
#' data("households", package="RStudioTools")
#' dataGadget()
#' 
#' # Change tab to [merge.data]
#' # Select 'children' in [select data] and 'households' in [sel data to merge]
#' # Select 'hhid' in both [ID variables ..]
#' # Text output:
#' #  -  ERROR: ID not unique in 'children', e.g. 135: 2 times
#' # Select 'm:1' in field [Options for merging]
#' # Text output:
#' # - children ID is of type integer , households ID is of type integer
#' #  - Mathcing unique IDs:, 134 , non-matching unique IDS: 1 in children...
#' #  - Merged dataset has 14 variables, and 189 observations
#' #  - 186 obs appeared in both,  1 in 1st,  2 in 2nd
#' #  -     hhid childid age agehh sexhh
#' #  - 1      1      25 2.5    41     M
#' #  - 189  138     512 3.5    35     M
#' 
#' @export
#' @import miniUI rstudioapi shiny
dataGadget <-
function(view = c("pane", "dialog", "browser")) {
  ui <- miniPage(
    fillCol(
      fillRow(
        selectInput(
          "data",
          "Select data",
          choices = "---",
          selected = 1
        ),
        miniButtonBlock(
          actionButton(
            "help",
            "Help",
            icon = icon("question"),
            style = "color: #ffffff; background-color: #444444"
          ),
          actionButton("quit", "Quit", icon = icon("close"),
                       style = "color: #ffffff; background-color: #444444"),
          border = "bottom"
        ),
        flex = c(3, 1)
      ),
      verbatimTextOutput("infodata"),
      flex = c(1, 1),
      height = 120
    ),
    
    miniTabstripPanel(
      miniTabPanel(
        "inspect",
        icon = icon("search-plus"),
        miniTabstripPanel(
          miniTabPanel("info", icon = icon("info"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput("str")
                       ))),
          miniTabPanel("table", icon = icon("table"),
                       miniContentPanel(fillCol(
                         dataTableOutput('table')
                       ))),
          miniTabPanel("summary", icon = icon("list-ol"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput('summary')
                       )))
        ),
        p("")# insert space between the nested tab panels
      ),
      
      miniTabPanel("manage.data", icon = icon("table"),
                   miniContentPanel(
                     fillCol(
                       fillRow(
                         selectInput(
                           "renamevar",
                           "Rename variable ...",
                           choices = "---",
                           multiple = F
                         ),
                         textInput("newvarname", "... to", placeholder = "newvarname")
                       ),
                       verbatimTextOutput("inforename"),
                       checkboxInput('lowercase', 'Change variable names to lowercase', F),
                       verbatimTextOutput("infolower"),
                       checkboxInput('cleanrownames', 'Change row names to 1:N', F),
                       verbatimTextOutput("inforownames"),
                       checkboxInput(
                         'removeblanks',
                         'Remove space, quotes, etc. from variable names',
                         FALSE,
                         width = "60%"
                       ),
                       verbatimTextOutput("infoblanks"),
                       miniButtonBlock(
                         actionButton("assignmd", "Assign & quit", icon = icon("gears")),
                         actionButton("assignPastemd", "Assign, paste code & quit", icon = icon("paste")),
                         actionButton(
                           "assignContinuemd",
                           "Assign, paste & continue",
                           icon = icon("retweet")
                         )
                       ),flex=c(1.2,1,0.8,1.2,0.8,1.2,0.8,1.2,0.6)
                     )
                   )),
      
      miniTabPanel("sort.data", icon = icon("sort"),
                   miniContentPanel(
                     fillCol(
                       fillRow(
                         selectInput(
                           "var1",
                           "Select sort variable 1",
                           choices = "",
                           multiple = F,
                           width = '80%'
                         ),
                         selectInput(
                           "var2",
                           "Select sort variable 2",
                           choices = "",
                           multiple = F,
                           width = '80%'
                         ),
                         checkboxInput(
                           "sort",
                           "Sort largest to smallest (99,...,0,NA)" ,
                           value = F,
                           width = '70%'
                         )
                       ),
                       verbatimTextOutput("infosort"),
                       miniButtonBlock(
                         actionButton("assignso", "Assign & quit", icon = icon("gears")),
                         actionButton("assignPasteso", "Assign, paste code & quit", icon = icon("paste")),
                         actionButton(
                           "assignContinueso",
                           "Assign, paste & continue",
                           icon = icon("retweet")
                         )
                       ),
                       flex = c(1.2, 6, 0.8)
                     )
                   )),
      
      miniTabPanel("subset.data", icon = icon("filter"),
                   miniContentPanel(
                     fillCol(
                       fillRow(
                         textInput("subsetname", "Name of new data", placeholder = "newdata"),
                         textInput("express", " Expression (empty: keep all obs)", placeholder =
                                     "e.g. sex == \"F\""),
                         selectInput(
                           "selectvar",
                           " Select variables (empty: keep all)",
                           choices = "",
                           multiple = T
                         ),
                         flex = c(2, 3, 3)
                       ),
                       verbatimTextOutput("infosubset"),
                       miniButtonBlock(
                         actionButton("assignsu", "Assign & quit", icon = icon("gears")),
                         actionButton("assignPastesu", "Assign, paste code & quit", icon = icon("paste"))
                       ),
                       dataTableOutput("subsettable"),
                       flex = c(1.2, 1, 0.8, 6)
                     )
                   )),
      
      miniTabPanel(
        "append.data",
        icon = icon("arrows-v"),
        miniContentPanel(
          fillCol(
            selectInput(
              "dataappend",
              "Select data to append",
              choices = "---",
              selected = 1
            ),
            verbatimTextOutput("infodataappend"),
            fillRow(
              textInput("appendname", "Name of combined data", placeholder = "newdata"),
              selectInput(
                "appendopt",
                "Options for uneaqual datasets",
                choices = "---",
                multiple = F
              )
              
            ),
            verbatimTextOutput("infoappend"),
            miniButtonBlock(
              actionButton("assignap", "Assign & quit", icon = icon("gears")),
              actionButton("assignPasteap", "Assign, paste code & quit", icon = icon("paste"))
            ),
            flex = c(1, 2, 1, 1, 0.7)
          )
        )
      ),
      
      miniTabPanel(
        "merge.data",
        icon = icon("arrows-h"),
        miniContentPanel(
          fillCol(
            selectInput(
              "datamerge",
              "Select data to merge",
              choices = "---",
              selected = 1
            ),
            verbatimTextOutput("infodatamerge"),
            fillRow(
              textInput("mergename", "Name of combined data", placeholder = "newdata"),
              selectInput(
                "mergeopt",
                "Options for merging",
                choices = c("1:1", "1:m", "m:1"),
                multiple = F
              ),
              selectInput(
                "mergeid1",
                "match ID (1st data)",
                choices = "---",
                multiple = F
              ),
              selectInput(
                "mergeid2",
                "match ID (2nd data)",
                choices = "---",
                multiple = F
              )
            ),
            verbatimTextOutput("infomerge"),
            miniButtonBlock(
              actionButton("assignme", "Assign & quit", icon = icon("gears")),
              actionButton("assignPasteme", "Assign, paste code & quit", icon = icon("paste"))
            ),
            flex = c(1.4, 1.8, 2, 4, 0.8)
          )
        )
      )
    )
  )
  
  server <- (function(input, output, session) {
    noData <- c("---", "No data found in current R session")
    txtNoData <- "No data selected"
    txtNoVar <- "No variable selected"
    txtSelData <- "Select data"
    txtSelVar <- "Select variable"
    txtSelVars <- "Select variable(s)"
    
    dataInput <- reactive({
      if (input$data %in% noData)
        NULL
      else
        get(input$data)
    })
    
    sData <- reactive({
      if (length(Filter(
        function(x)
          inherits(get(x), "data.frame"),
        ls(envir = .GlobalEnv)
      ))
      > 0)
        c("---", Filter(
          function(x)
            inherits(get(x), "data.frame"),
          ls(envir = .GlobalEnv)
        ))
      else
        "No data found in current R session"
    })
    
    ## - inspect -
    
    output$str <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else
        str(
          dataInput(),
          give.attr = F,
          width = 77,
          strict.width = 'cut'
        )
    })
    
    output$table <- renderDataTable({
      dataInput()
    },
    options = list(lengthMenu = list(c(8, 20,-1), c('8', '20', 'All')),
                   pageLength = 8))
    
    output$summary <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        op <- options()
        options(width = 96)
        print(summary(dataInput()))
        options(op)
      }
    })
    
    # manage.data
    
    observe({
      updateSelectInput(session, "data",
                        choices = sData())
    })
    output$infodata <- renderPrint({
      if (input$data %in% noData)
        cat("No data selected")
      else{
        cat(paste(
          "Variables:",
          dim(dataInput())[2],
          ", observations:",
          dim(dataInput())[1],
          "\n"
        ))
        if (max(table(colnames(dataInput()))) > 1)
          cat(paste(
            "Warning: Some variables in",
            input$data,
            "have the same name\n"
          ))
      }
    })
    
    output$infolower <- renderPrint({
      if (input$data %in% noData)
        cat("")
      else{
        if (any(colnames(dataInput()) != tolower(colnames(dataInput()))))
          cat("Some variable names contain uppercase characters\n")
        else
          cat("All variable names are already lowercase\n")
        if (max(table(colnames(dataInput()))) == 1 &
            max(table(tolower(colnames(
              dataInput()
            )))) > 1)
          cat("Warning: some variables will have the same name after changing to lowercase")
      }
    })
    
    output$infoblanks <- renderPrint({
      if (input$data %in% noData)
        cat("")
      else{
        if (any(colnames(dataInput()) != make.names(colnames(dataInput()))))
          cat("Inavlid variable names detected\n")
        else
          cat("No invalid variable names detected\n")
        if (max(table(colnames(dataInput()))) == 1 &
            max(table(gsub(" ", "", colnames(
              dataInput()
            )))) > 1)
          cat("Warning: some variables will have the same name after removal of spaces")
      }
    })
    output$inforownames <- renderPrint({
      if (input$data %in% noData)
        cat("")
      else{
        if (any(rownames(dataInput()) != as.character(1:nrow(dataInput()))))
          cat("Row names != 1:N\n")
        else
          cat("Row names are already 1:N\n")
      }
    })
    
    observe({
      updateSelectInput(session, "renamevar",
                        choices = c("---", colnames(dataInput())))
    })
    
    output$inforename <- renderPrint({
      if (input$data %in% noData | input$renamevar == "---")
        cat("")
      else{
        if (input$newvarname != make.names(input$newvarname))
          cat(
            paste(
              "Warning: No/invalid variable name, will be renamed to '",
              make.names(input$newvarname),
              "'\n",
              sep = ""
            )
          )
        if (make.names(input$newvarname) %in% colnames(dataInput()))
          cat(paste(
            "Warning: variable name exists already in data",
            input$data
          ))
        
      }
    })
    
    observeEvent(input$assignmd, {
      if (input$lowercase |
          input$removeblanks |
          input$cleanrownames | input$renamevar != "---")  {
        dtemp <- dataInput()
        if (input$renamevar != "---")
          colnames(dtemp)[which(colnames(dtemp) == input$renamevar)] <-
            make.names(input$newvarname)
        if (input$lowercase)
          colnames(dtemp) <- tolower(colnames(dtemp))
        if (input$removeblanks)
          colnames(dtemp) <- make.names(colnames(dtemp))
        if (input$cleanrownames)
          rownames(dtemp) <- 1:nrow(dtemp)
        assign(make.names(input$data),  dtemp, pos = .GlobalEnv)
      }
      stopApp(NULL)
    })
    
    observeEvent(input$assignPastemd, {
      if (input$lowercase |
          input$removeblanks |
          input$cleanrownames | input$renamevar != "---")  {
        dtemp <- dataInput()
        txt <- ""
        if (input$renamevar != "---") {
          colnames(dtemp)[which(colnames(dtemp) == input$renamevar)] <-
            make.names(input$newvarname)
          txt <-
            paste(
              txt,
              "\ncolnames(",
              input$data,
              ")[which(colnames(",
              input$data,
              ") == \"",
              input$renamevar,
              "\")] <- \"",
              make.names(input$newvarname) ,
              "\"",
              sep = ""
            )
        }
        if (input$lowercase) {
          colnames(dtemp) <- tolower(colnames(dtemp))
          txt <-
            paste(
              txt,
              "\ncolnames(",
              input$data,
              ") <- tolower(colnames(",
              input$data,
              "))",
              sep = ""
            )
        }
        if (input$removeblanks) {
          colnames(dtemp) <-  make.names(colnames(dtemp))
          txt <-
            paste(
              txt,
              "\ncolnames(",
              input$data,
              ") <- make.names(colnames(",
              input$data,
              "))",
              sep = ""
            )
        }
        if (input$cleanrownames) {
          rownames(dtemp) <- 1:nrow(dtemp)
          txt <-
            paste(txt,
                  "\nrownames(",
                  input$data,
                  ") <- 1:nrow(",
                  input$data,
                  ")",
                  sep = "")
        }
        assign(make.names(input$data),  dtemp, pos = .GlobalEnv)
        rstudioapi::insertText(paste(txt, "\n"))
      }
      stopApp(NULL)
    })
    
    observeEvent(input$assignContinuemd, {
      if (input$lowercase |
          input$removeblanks |
          input$cleanrownames | input$renamevar != "---")  {
        dtemp <- dataInput()
        txt <- ""
        if (input$renamevar != "---") {
          colnames(dtemp)[which(colnames(dtemp) == input$renamevar)] <-
            make.names(input$newvarname)
          txt <-
            paste(
              txt,
              "\ncolnames(",
              input$data,
              ")[which(colnames(",
              input$data,
              ") == \"",
              input$renamevar,
              "\")] <- \"",
              make.names(input$newvarname) ,
              "\"",
              sep = ""
            )
        }
        if (input$lowercase) {
          colnames(dtemp) <- tolower(colnames(dtemp))
          txt <-
            paste(
              txt,
              "\ncolnames(",
              input$data,
              ") <- tolower(colnames(",
              input$data,
              "))",
              sep = ""
            )
        }
        if (input$removeblanks) {
          colnames(dtemp) <-  make.names(colnames(dtemp))
          txt <-
            paste(
              txt,
              "\ncolnames(",
              input$data,
              ") <- make.names(colnames(",
              input$data,
              "))",
              sep = ""
            )
        }
        if (input$cleanrownames) {
          rownames(dtemp) <- 1:nrow(dtemp)
          txt <-
            paste(txt,
                  "\nrownames(",
                  input$data,
                  ") <- 1:nrow(",
                  input$data,
                  ")",
                  sep = "")
        }
        assign(make.names(input$data),  dtemp, pos = .GlobalEnv)
        rstudioapi::insertText(paste(txt, "\n"))
        updateSelectInput(session,
                          "data",
                          choices = sData(),
                          selected = "---")
      }
    })
    
    ## sorting data
    
    observe({
      updateSelectInput(session, "var1",
                        choices = c("---", colnames(dataInput())))
    })
    
    observe({
      updateSelectInput(session, "var2",
                        choices = c("---", colnames(dataInput())))
    })
    
    datasetSorted <- reactive({
      dsort <- dataInput()
      if (input$var1 != "---" & input$var2 == "---")
        ord <-
          order(dataInput()[, input$var1], decreasing = input$sort)
      if (input$var1 == "---" & input$var2 != "---")
        ord <-
          order(dataInput()[, input$var2], decreasing = input$sort)
      if (input$var1 != "---" & input$var2 != "---")
        ord <-
          order(dataInput()[, input$var1], dataInput()[, input$var2], decreasing = input$sort)
      dsort <- dsort[ord,]
      return(dsort)
    })
    
    output$infosort <- renderPrint({
      if ((input$var1 == "---" & input$var2 == "---") |
          !all(c(input$var1, input$var2) %in% c("---", colnames(dataInput()))))
        cat("Select at least 1 variable")
      else{
        if (input$var1 != "---") {
          print(input$var1)
          vn <- which(colnames(dataInput()) == input$var1)
          str(datasetSorted()[, vn])
        }
        if (input$var2 != "---") {
          print(input$var2)
          vn <- which(colnames(dataInput()) == input$var2)
          str(datasetSorted()[, vn])
        }
        if (input$var1 != "---" | input$var2 != "---") {
          print(datasetSorted()[1:7, 1:min(ncol(datasetSorted()), 6)])
        }
      }
    })
    
    pasteSortCode <- function() {
      assign(input$data,  datasetSorted(), pos = .GlobalEnv)
      if (input$var1 != "---" & input$var2 == "---") {
        rstudioapi::insertText(
          paste(
            "\n",
            input$data,
            " <- ",
            input$data,
            "[order(",
            input$data,
            "$",
            input$var1,
            ", decreasing =",
            input$sort,
            "),]\n",
            sep = ""
          )
        )
      }
      if (input$var1 == "---" & input$var2 != "---") {
        rstudioapi::insertText(
          paste(
            "\n",
            input$data,
            " <- ",
            input$data,
            "[order(",
            input$data,
            "$",
            input$var2,
            ", decreasing =",
            input$sort,
            "),]\n",
            sep = ""
          )
        )
      }
      if (input$var1 != "---" & input$var2 != "---") {
        rstudioapi::insertText(
          paste(
            "\n",
            input$data,
            " <- ",
            input$data,
            "[order(",
            input$data,
            "$",
            input$var1,
            ", ",
            input$data,
            "$",
            input$var2,
            ", decreasing =",
            input$sort,
            "),]\n",
            sep = ""
          )
        )
      }
    }
    
    observeEvent(input$assignso, {
      if (input$var1 == "---" &
          input$var2 == "---")
        stopApp(print("no variable selected - nothing done"))
      else{
        assign(input$data,  datasetSorted(), pos = .GlobalEnv)
        stopApp("Good bye")
      }
    })
    
    observeEvent(input$assignPasteso, {
      if (input$var1 == "---" &
          input$var2 == "---")
        stopApp(print("no variable selected - nothing done"))
      else{
        assign(input$data,  datasetSorted(), pos = .GlobalEnv)
        pasteSortCode()
        stopApp("Good bye")
      }
    })
    
    observeEvent(input$assignContinueso, {
      if (input$var1 == "---" &
          input$var2 == "---")
        stopApp(print("no variable selected - nothing done"))
      else{
        assign(input$data,  datasetSorted(), pos = .GlobalEnv)
        pasteSortCode()
        updateSelectInput(session,
                          "var1",
                          choices = sData(),
                          selected = "---")
        updateSelectInput(session,
                          "var2",
                          choices = sData(),
                          selected = "---")
        updateSelectInput(session,
                          "data",
                          choices = sData(),
                          selected = "---")
      }
    })
    
    ## subsetting data
    
    dataSubset <- reactive({
      #subsetString <- input$express
      dsub <- dataInput()
      #return(dsub)
      if (input$express == "" &
          is.null(input$selectvar))
        return(dsub)
      else{
        if (input$express != "" & is.null(input$selectvar)) {
          dsub <-
            try(subset(dataInput(), eval(parse(text = input$express))), silent = T)
          if (class(dsub) == "try-error")
            return(dataInput())
          else
            return(dsub)
        }
        if (input$express == "" & !is.null(input$selectvar)) {
          dsub <- try(dataInput()[, input$selectvar], silent = T)
          if (class(dsub) == "try-error")
            return(dataInput())
          else
            return(dsub)
        }
        if (input$express != "" & !is.null(input$selectvar)) {
          dsub <-
            try(subset(dataInput(), eval(parse(text = input$express)), input$selectvar), silent =
                  T)
          if (class(dsub) == "try-error")
            return(dataInput())
          else
            return(dsub)
        }
      }
    })
    
    observe({
      updateSelectInput(session, "selectvar",
                        choices = c("", colnames(dataInput())))
    })
    
    output$infosubset <- renderPrint({
      if (input$subsetname !=  make.names(input$subsetname))
        cat(paste(
          "Warning: No (valid) name, will be renamed to:",
          make.names(input$subsetname),
          "\n"
        ))
      if (make.names(input$subsetname) %in% ls(envir = .GlobalEnv) &
          !(input$data %in% c("---", "No data set found in current R session")))
        cat(
          paste(
            "Warning: there is already an object called",
            make.names(input$subsetname),
            "(assign will replace)\n"
          )
        )
      if (input$express != "") {
        dtemp <- dataInput()
        .try <-
          try(subset(dtemp, eval(parse(text = input$express))), silent = T)
        if (class(.try) == "try-error")
          cat("Expression not valid/complete\n")
      }
    })
    
    output$subsettable <- renderDataTable({
      dataSubset()
    }
    , options = list(
      pageLength = 5,
      lengthMenu = list(c(5,-1), c('5', 'All')),
      searching = F
    ))
    
    observeEvent(input$assignsu, {
      if (input$data == "---")
        stopApp(print("No data selected - nothing done"))
      else{
        if (input$express == "" &
            is.null(input$selectvar))
          stopApp(print(
            "Either expression or variables have to be specified - nothing done"
          ))
        else{
          assign(make.names(input$subsetname),  dataSubset(), pos = .GlobalEnv)
          stopApp("Good bye")
        }
      }
    })
    
    observeEvent(input$assignPastesu, {
      if (input$data == "---")
        stopApp(print("No data selected - nothing done"))
      else{
        if (input$express == "" &
            is.null(input$selectvar))
          stopApp(print(
            "Either expression or variables have to be specified - nothing done"
          ))
        else{
          assign(make.names(input$subsetname),  dataSubset(), pos = .GlobalEnv)
          if (input$express != "" & is.null(input$selectvar)) {
            rstudioapi::insertText(
              paste(
                "\n",
                make.names(input$subsetname),
                " <- subset(",
                input$data,
                ", ",
                input$express,
                ")\n",
                sep = ""
              )
            )
          }
          if (input$express == "" & !is.null(input$selectvar)) {
            rstudioapi::insertText(
              paste(
                "\n",
                make.names(input$subsetname),
                " <- ",
                input$data,
                "[, c(\"",
                paste(input$selectvar, collapse = '\",\"'),
                "\")]\n",
                sep = ""
              )
            )
            
          }
          if (input$express != "" & !is.null(input$selectvar)) {
            rstudioapi::insertText(
              paste(
                "\n",
                make.names(input$subsetname),
                " <- subset(",
                input$data,
                ", ",
                input$express,
                ", select=c(",
                paste(input$selectvar, collapse = ','),
                "))\n",
                sep = ""
              )
            )
          }
          stopApp("Good bye")
        }
      }
    })
    
    ## appending datasets
    
    datasetAppend <- reactive({
      if (input$dataappend %in% noData)
        NULL
      else
        get(input$dataappend)
    })
    
    observe({
      updateSelectInput(session, "dataappend",
                        choices = sData())
    })
    
    output$infodataappend <- renderPrint({
      if (input$dataappend %in% noData)
        cat("No data selected")
      else{
        cat(paste(
          "Variables:",
          dim(datasetAppend())[2],
          ", observations:",
          dim(datasetAppend())[1],
          "\n"
        ))
        if (input$data == input$dataappend)
          cat("Warning: Same datasets selected\n")
        # if(any(sapply(dataInput()[intersect(colnames(dataInput()), colnames(datasetAppend()))],class) !=
        #        sapply(datasetAppend()[intersect(colnames(dataInput()), colnames(datasetAppend()))]), class)) cat("Warning: Some variables are not of same type\n")
        
        if (any(colnames(dataInput()) != make.names(colnames(dataInput()))))
          cat("Warning: Invalid variable names in",
              input$data,
              "detected\n")
        if (any(colnames(datasetAppend()) != make.names(colnames(datasetAppend()))))
          cat("Warning: Invalid variable names in",
              input$dataappend,
              "detected\n")
        if (max(table(colnames(datasetAppend()))) > 1)
          cat(paste(
            "Warning: Some variables in",
            input$dataappend,
            "have the same name\n"
          ))
        if (length(intersect(colnames(dataInput()), colnames(datasetAppend()))) ==
            0)
          cat("ERROR: No common variables detected!\n")
        else{
          if (min(sapply(dataInput()[intersect(colnames(dataInput()), colnames(datasetAppend()))], class) == sapply(datasetAppend()[intersect(colnames(dataInput()), colnames(datasetAppend()))], class)) ==
              0) {
            cat(paste(
              "Warning: Some variables are not of the same type in both datasets\n"
            ))
            .temp <-
              which(sapply(datasetAppend()[intersect(colnames(dataInput()), colnames(datasetAppend()))], class) != sapply(dataInput()[intersect(colnames(dataInput()), colnames(datasetAppend()))], class))
            print(rbind(substr(
              sapply(dataInput()[intersect(colnames(dataInput()), colnames(datasetAppend()))][.temp], class), 1, 3
            ),
            substr(
              sapply(datasetAppend()[intersect(colnames(dataInput()), colnames(datasetAppend()))][.temp], class), 1, 3
            )))
          }
          cat("Varaibles in both datasets:\n")
          cat(paste(length(
            intersect(colnames(dataInput()), colnames(datasetAppend()))
          ), ":",
          substr(
            paste(intersect(
              colnames(dataInput()), colnames(datasetAppend())
            ), collapse = " "), 1, 75
          ), "\n"))
          cat(paste("Varaibles only in", input$data, ": "))
          cat(paste(length(setdiff(
            colnames(dataInput()), colnames(datasetAppend())
          )), ":",
          substr(
            paste(setdiff(
              colnames(dataInput()), colnames(datasetAppend())
            ), collapse = " "), 1, 35
          ), "\n"))
          cat(paste("Varaibles only in", input$dataappend, ": "))
          cat(paste(length(setdiff(
            colnames(datasetAppend()), colnames(dataInput())
          )), ":",
          substr(
            paste(setdiff(
              colnames(datasetAppend()), colnames(dataInput())
            ), collapse = " "), 1, 35
          ), "\n"))
        }
      }
    })
    
    observe({
      if (input$data %in% noData |
          input$dataappend %in% noData)
        options <- "---"
      else{
        if (length(intersect(colnames(dataInput()), colnames(datasetAppend()))) ==
            max(ncol(dataInput()), ncol(datasetAppend())))
          options <- "---"
        else
          options <-
            c("Keep only common variables",
              "keep all variables (assign NA)")
      }
      updateSelectInput(session, "appendopt", choices = options)
    })
    
    output$infoappend <- renderPrint({
      if (input$data != "---" & input$dataappend != "---") {
        if (input$appendname !=  make.names(input$appendname))
          cat(paste(
            "Warning: No (valid) name, will be renamed to:",
            make.names(input$appendname),
            "\n"
          ))
        if (make.names(input$appendname) %in% ls(envir = .GlobalEnv))
          cat(
            paste(
              "Warning: there is already an object called",
              make.names(input$appendname),
              "(assign will replace)\n"
            )
          )
        cat(paste(
          "New dataset has",
          dim(dataInput())[1] + dim(datasetAppend())[1],
          "records"
        ))
      }
    })
    
    observeEvent(input$assignap, {
      if (input$data %in% noData |  input$dataappend %in% noData)
        stopApp(print("not 2 datasets selected - nothing done"))
      else{
        if (length(intersect(colnames(dataInput()), colnames(datasetAppend()))) ==
            max(ncol(dataInput()), ncol(datasetAppend()))) {
          dtemp <- rbind(dataInput(), datasetAppend())
          assign(make.names(input$appendname),  dtemp, pos = .GlobalEnv)
          stopApp("Good bye")
        } else {
          if (input$appendopt == "Keep only common variables") {
            dtemp <-
              rbind(dataInput()[intersect(colnames(dataInput()), colnames(datasetAppend()))], datasetAppend()[intersect(colnames(dataInput()), colnames(datasetAppend()))])
            assign(make.names(input$appendname),  dtemp, pos = .GlobalEnv)
            stopApp("Good bye")
          } else{
            dtemp1 <- dataInput()
            if (length(setdiff(colnames(datasetAppend()), colnames(dataInput()))) >
                0)
              dtemp1[, setdiff(colnames(datasetAppend()), colnames(dataInput()))] <-
                NA
            dtemp2 <- datasetAppend()
            if (length(setdiff(colnames(dataInput()), colnames(datasetAppend()))) >
                0)
              dtemp2[, setdiff(colnames(dataInput()), colnames(datasetAppend()))] <-
              NA
            dtemp <- rbind(dtemp1, dtemp2, make.row.names = F)
            assign(make.names(input$appendname),  dtemp, pos = .GlobalEnv)
            stopApp("Good bye")
          }
        }
      }
    })
    
    observeEvent(input$assignPasteap, {
      if (input$data %in% noData |  input$dataappend %in% noData)
        stopApp(print("not 2 datasets selected - nothing done"))
      else{
        if (length(intersect(colnames(dataInput()), colnames(datasetAppend()))) ==
            max(ncol(dataInput()), ncol(datasetAppend()))) {
          dtemp <- rbind(dataInput(), datasetAppend())
          assign(make.names(input$appendname),  dtemp, pos = .GlobalEnv)
          rstudioapi::insertText(
            paste(
              "\n",
              make.names(input$appendname),
              " <- rbind(",
              input$data,
              ", ",
              input$dataappend,
              ")\n",
              sep = ""
            )
          )
          stopApp("Good bye")
        } else {
          if (input$appendopt == "Keep only common variables") {
            dtemp <-
              rbind(dataInput()[intersect(colnames(dataInput()), colnames(datasetAppend()))],
                    datasetAppend()[intersect(colnames(dataInput()), colnames(datasetAppend()))])
            assign(make.names(input$appendname),  dtemp, pos = .GlobalEnv)
            rstudioapi::insertText(
              paste(
                "\n",
                make.names(input$appendname),
                " <- rbind(",
                input$data,
                "[intersect(colnames(",
                input$data,
                "),colnames(",
                input$dataappend,
                "))], ",
                input$dataappend,
                "[intersect(colnames(",
                input$data,
                "),colnames(",
                input$dataappend,
                "))], make.row.names=F)\n",
                sep = ""
              )
            )
            stopApp("Good bye")
          } else{
            dtemp1 <- dataInput()
            if (length(setdiff(colnames(datasetAppend()), colnames(dataInput()))) >
                0)
              dtemp1[, setdiff(colnames(datasetAppend()), colnames(dataInput()))] <-
                NA
            dtemp2 <- datasetAppend()
            if (length(setdiff(colnames(dataInput()), colnames(datasetAppend()))) >
                0)
              dtemp2[, setdiff(colnames(dataInput()), colnames(datasetAppend()))] <-
              NA
            dtemp <- rbind(dtemp1, dtemp2,  make.row.names = F)
            assign(make.names(input$appendname),  dtemp, pos = .GlobalEnv)
            if (length(setdiff(colnames(datasetAppend()), colnames(dataInput()))) >
                0)
              rstudioapi::insertText(
                paste(
                  "\n",
                  input$data,
                  "[setdiff(colnames(",
                  input$dataappend,
                  "),colnames(",
                  input$data,
                  "))] <- NA\n",
                  sep = ""
                )
              )
            if (length(setdiff(colnames(dataInput()), colnames(datasetAppend()))) >
                0)
              rstudioapi::insertText(
                paste(
                  "\n",
                  input$dataappend,
                  "[setdiff(colnames(",
                  input$data,
                  "),colnames(",
                  input$dataappend,
                  "))] <- NA\n",
                  sep = ""
                )
              )
            rstudioapi::insertText(
              paste(
                "\n",
                make.names(input$appendname),
                " <- rbind(",
                input$data,
                ", ",
                input$dataappend,
                ",make.row.names=F)\n",
                sep = ""
              )
            )
            if (length(setdiff(colnames(datasetAppend()), colnames(dataInput()))) >
                0)
              rstudioapi::insertText(
                paste(
                  "\n",
                  input$data,
                  " <- Filter(function(x)!all(is.na(x)), ",
                  input$data,
                  ")\n",
                  sep = ""
                )
              )
            if (length(setdiff(colnames(dataInput()), colnames(datasetAppend()))) >
                0)
              rstudioapi::insertText(
                paste(
                  "\n",
                  input$dataappend,
                  " <- Filter(function(x)!all(is.na(x)), ",
                  input$dataappend,
                  ")\n",
                  sep = ""
                )
              )
            stopApp("Good bye")
          }
        }
      }
    })
    
    ## Merging datasets
    
    datasetMerge <- reactive({
      if (input$datamerge %in% noData)
        NULL
      else
        get(input$datamerge)
    })
    
    observe({
      updateSelectInput(session, "datamerge",
                        choices = sData())
    })
    
    observe({
      updateSelectInput(session, "mergeid1",
                        choices = c("---", colnames(dataInput())))
    })
    
    observe({
      updateSelectInput(session, "mergeid2",
                        choices = c("---", colnames(datasetMerge())))
    })
    
    output$infodatamerge <- renderPrint({
      if (input$datamerge %in% noData)
        cat("No data selected")
      else{
        cat(paste(
          "Variables:",
          ncol(datasetMerge()),
          ", observations:",
          nrow(datasetMerge()),
          "\n"
        ))
        if (input$data == input$datamerge)
          cat("Warning: Same datasets selected\n")
        if (any(colnames(dataInput()) != make.names(colnames(dataInput()))))
          cat("Warning: Invalid variable names in",
              input$data,
              "detected\n")
        if (any(colnames(datasetMerge()) != make.names(colnames(datasetMerge()))))
          cat("Warning: Invalid variable names in",
              input$datamerge,
              "detected\n")
        if (max(table(colnames(datasetMerge()))) > 1)
          cat(paste(
            "Warning: Some variables in",
            input$datamerge,
            "have the same name\n"
          ))
      }
    })
    
    output$infomerge <- renderPrint({
      if (input$mergename !=  make.names(input$mergename) &
          !(input$datamerge %in% noData))
        cat(paste(
          "Warning: No (valid) name, will be renamed to:",
          make.names(input$mergename),
          "\n"
        ))
      if (make.names(input$mergename) %in% ls(envir = .GlobalEnv) &
          !(input$datamerge %in% noData))
        cat(
          paste(
            "Warning: there is already an object called",
            make.names(input$mergename),
            "(assign will replace)\n"
          )
        )
      
      if (input$mergeid1 != "---" &
          input$mergeid2 != "---" &
          input$data != "---" & input$datamerge != "---") {
        vn1 <- which(colnames(dataInput()) == input$mergeid1)
        vn2 <- which(colnames(datasetMerge()) == input$mergeid2)
        if (length(vn1) == 1 & length(vn2) == 1) {
          if (input$mergeopt %in% c("1:1", "1:m")) {
            if (max(table(dataInput()[, vn1])) > 1) {
              cat(
                paste(
                  "ERROR: ID not unique in '",
                  input$data,
                  "', e.g. ",
                  rev(names(sort(
                    table(dataInput()[, vn1])
                  )))[1],
                  ": ",
                  rev((sort(
                    table(dataInput()[, vn1])
                  )))[1],
                  " times\n",
                  sep = ""
                )
              )
            }
          }
          if (input$mergeopt %in% c("1:1", "m:1")) {
            if (max(table(datasetMerge()[, vn2])) > 1) {
              cat(
                paste(
                  "ERROR: ID not uniquw in '",
                  input$datamerge,
                  "', e.g. ",
                  rev(names(sort(
                    table(datasetMerge()[, vn2])
                  )))[1],
                  ": ",
                  rev((sort(
                    table(datasetMerge()[, vn2])
                  )))[1],
                  " times\n",
                  sep = ""
                )
              )
            }
          }
          if (any(is.na(dataInput()[, vn1])))
            cat(paste("Warning: ID has NA'", input$data, "'\n", sep = ""))
          if (any(is.na(datasetMerge()[, vn2])))
            cat(paste("Warning: ID has NA'", input$datamerge, "'\n", sep = ""))
          if ((input$mergeopt == "1:1" &
               max(table(dataInput()[, vn1])) == 1 &
               max(table(datasetMerge()[, vn2])) == 1) |
              (input$mergeopt == "1:m" &
               max(table(dataInput()[, vn1])) == 1) |
              (input$mergeopt == "m:1" &
               max(table(datasetMerge()[, vn2])) == 1)) {
            cat(
              paste(
                input$data,
                "ID is of type",
                class(dataInput()[, vn1]),
                ",",
                input$datamerge,
                "ID is of type",
                class(datasetMerge()[, vn2]),
                "\n"
              )
            )
            id0 <-
              intersect(dataInput()[, vn1], datasetMerge()[, vn2])
            id1 <-
              setdiff(dataInput()[, vn1], datasetMerge()[, vn2])
            id2 <-
              setdiff(datasetMerge()[, vn2], dataInput()[, vn1])
            if (length(id0) == 0)
              cat("ERROR: 0 matchin IDs\n")
            if (length(setdiff(intersect(
              colnames(dataInput()), colnames(datasetMerge())
            ), input$mergeid1)) > 0)
              cat("Same variable names detected, will be renamed to var.x/var.y\n")
            cat(
              paste(
                "Matching unique IDs:,",
                length(id0),
                ", non-matching unique IDs:",
                length(id1),
                "in",
                input$data,
                ",",
                length(id2),
                "in",
                input$datamerge,
                "\n"
              )
            )
            try(dtemp <-
                  merge(
                    dataInput(),
                    datasetMerge(),
                    by.x = input$mergeid1,
                    by.y = input$mergeid2,
                    all = T
                  ))
            if (class(.Last.value) == "try-error")
              cat("Problem detected merge will likely fail\n")
            else{
              cat(
                paste(
                  "Merged dataset has",
                  ncol(dtemp),
                  "variables, and",
                  nrow(dtemp),
                  "observations\n"
                )
              )
              mname <-
                setdiff(paste(".merge", 0:100, sep = ""), colnames(dtemp))[1]
              dtemp[, mname] <-
                dtemp[, 1] %in% unique(dataInput()[, vn1]) + (dtemp[, 1] %in%
                                                                unique(datasetMerge()[, vn2])) * 2
              cat(paste(
                sum(dtemp[, mname] == 3),
                "obs appeared in both, ",
                sum(dtemp[, mname] == 1),
                "in 1st, ",
                sum(dtemp[, mname] == 2),
                "in 2nd\n"
              ))
              print(dtemp[c(1, nrow(dtemp)), c(1:3, ncol(dataInput()) +
                                                 (1:2))])
            }
          }
        }
      }
    })
    
    observeEvent(input$assignme, {
      if (input$mergeid1 != "---" &
          input$mergeid2 != "---" &
          input$data != "---" & input$datamerge != "---") {
        vn1 <- which(colnames(dataInput()) == input$mergeid1)
        vn2 <- which(colnames(datasetMerge()) == input$mergeid2)
        if (length(vn1) == 1 & length(vn2) == 1) {
          if ((input$mergeopt == "1:1" &
               max(table(dataInput()[, vn1])) == 1 &
               max(table(datasetMerge()[, vn2])) == 1) |
              (input$mergeopt == "1:m" &
               max(table(dataInput()[, vn1])) == 1) |
              (input$mergeopt == "m:1" &
               max(table(datasetMerge()[, vn2])) == 1)) {
            dtemp <-
              merge(
                dataInput(),
                datasetMerge(),
                by.x = input$mergeid1,
                by.y = input$mergeid2,
                all = T
              )
            mname <-
              setdiff(paste(".merge", 0:100, sep = ""), colnames(dtemp))[1]
            dtemp[, mname] <-
              dtemp[, 1] %in% unique(dataInput()[, vn1]) + (dtemp[, 1] %in%
                                                              unique(datasetMerge()[, vn2])) *  2
            assign(make.names(input$mergename),  dtemp, pos = .GlobalEnv)
            stopApp("Good bye")
          }
          else
            print("problem with match type (1:1/1:m/m:1)")
        }
      }
      else
        print("Select 2 datasets and 2 ID variables")
    })
    
    observeEvent(input$assignPasteme, {
      if (input$mergeid1 != "---" &
          input$mergeid2 != "---" &
          input$data != "---" & input$datamerge != "---") {
        vn1 <- which(colnames(dataInput()) == input$mergeid1)
        vn2 <- which(colnames(datasetMerge()) == input$mergeid2)
        if (length(vn1) == 1 & length(vn2) == 1) {
          if ((input$mergeopt == "1:1" &
               max(table(dataInput()[, vn1])) == 1 &
               max(table(datasetMerge()[, vn2])) == 1) |
              (input$mergeopt == "1:m" &
               max(table(dataInput()[, vn1])) == 1) |
              (input$mergeopt == "m:1" &
               max(table(datasetMerge()[, vn2])) == 1)) {
            dtemp <-
              merge(
                dataInput(),
                datasetMerge(),
                by.x = input$mergeid1,
                by.y = input$mergeid2,
                all = T
              )
            mname <-
              setdiff(paste(".merge", 0:100, sep = ""), colnames(dtemp))[1]
            dtemp[, mname] <-
              dtemp[, 1] %in% unique(dataInput()[, vn1]) +
              (dtemp[, 1] %in% unique(datasetMerge()[, vn2])) *  2
            assign(make.names(input$mergename),  dtemp, pos = .GlobalEnv)
            rstudioapi::insertText(
              paste(
                "\n",
                make.names(input$mergename),
                " <- merge(",
                input$data,
                ", ",
                input$datamerge,
                ", by.x=\"",
                input$mergeid1,
                "\", by.y=\"",
                input$mergeid2,
                "\", all=T)\n",
                sep = ""
              )
            )
            rstudioapi::insertText(
              paste(
                "\n",
                make.names(input$mergename),
                "[,\"",
                mname,
                "\"] <-",
                make.names(input$mergename),
                "[,1] %in% ",
                input$data,
                "$",
                input$mergeid1,
                " + 2*(",
                make.names(input$mergename),
                "[,1] %in% ",
                input$datamerge,
                "$",
                input$mergeid2,
                ")\n",
                sep = ""
              )
            )
            stopApp("Good bye")
          }
          else
            print("problem with match type (1:1/1:m/m:1)")
        }
      }
      else
        print("Select 2 datasets and 2 ID variables")
    })
    
    observeEvent(input$help, {
      RStudioTools:::browserHelp("dataGadget", "RStudioTools")
    })
    
    observeEvent(input$quit, {
      stopApp("Good bye")
    })
  })
  
  view <- match.arg(view)
  viewer <- RStudioTools:::selectViewer(view, 800, 800)
  runGadget(ui, server, viewer = viewer)
  
}
