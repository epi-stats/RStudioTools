#' @export
selectViewer <-
function (view, height = 900, width = 900) 
{
    if (view == "dialog") {
        viewer <- dialogViewer("Variable management gadget", 
            width = width, height = height)
    }
    if (view == "browser") {
        WINDOWS <- .Platform$OS.type == "windows"
        if (WINDOWS) 
            browser <- NULL
        else browser <- Sys.getenv("R_BROWSER")
        viewer <- browserViewer(browser = browser)
    }
    if (view == "pane") {
        viewer <- paneViewer(minHeight = height)
    }
    return(viewer)
}
