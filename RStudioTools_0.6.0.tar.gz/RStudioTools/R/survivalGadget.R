#' @title RStudio gadget for survival analysis
#' 
#' @description Tool to perform survival analysis and to generate the associated R-code.
#' 
#' @param view Controls where the gadget is displayed: 'dialog' a new interactive
#' dialogue window, 'pane' the RStudio pane viewer or 'browser' the system default web
#' browser. The pane is usually the most convenient option, but the window size may be
#' too small if the screen size or resolution results in overlapping elements, especially
#' the 'browser' option which provides more space.
#' @details An RStudio addin (shiny gadgets) -
#' runs only with RStudio (v1.1.383 or later). 
#' The application is usually invoked via the Addins pulldown menu
#' (if the toolbar is not visible, choose [View] > [Show toolbars]).
#' The associated R code can be generated (recommended),
#' which will be pasted into the R-script.
#' 
#' The first step is to select [Select data] the dataset. 
#' The tool lists all data frames wich have been defined in the current R session. 
#' In addition 3 example datasets are available.
#' After the data has been selected it is possible to choose the failure variable,
#' which indicates typically if the patient experienced a disease event (or death) or
#' if the observation is censored, i.e. the participant dropped out of the study.
#' Which value represents a failure (death) can be specified next to the variable.
#' The '-auto-' setting will interpret 0/1 (1=dead), TRUE/FALSE (TRUE = death)
#' or 1/2 (2=death), see \code{\link[survival]{Surv}}.
#' A warning message is displayed if the variable has values not compatible with '-auto-'.
#' The time variable indicates the time under observation. Time-start and time-end syntax
#' is not supported. If both time variables are numeric \code{\link[survival]{Surv}} can
#' be used. If the time variables are Dates the 
#' \code{\link[RStudioTools]{variableGadget}} can be used via [calculate],
#' however the equation must be eneterd by hand as: 'as.numeric(enddate - startdate)'.
#' A grouping variable can be entered optionally.
#' 
#' If all variables are correctly specified, the tab [plot] displays the 
#' Kaplan-Maier survival estimates (stratified by group if applicable) estimated by: 
#' \code{\link[survival]{survfit}}.
#' 
#' The tab [Estimate] summarises the survival data, e.g. number of events and
#' median survival.
#' If a group variable is specified the summary is done by group and the log
#'  rank test is performed (\code{\link[survival]{survdiff}}).  
#' 
#' [inspect] provides different options to investigate the data.
#' [info] displays number of records and variables, the variable classes
#' (types) using \code{\link[utils]{str}}.
#' [table] displays a table which can be that can be searched, filtered
#' sorted.
#' [summary] displays a summary of all variables,
#' e.g. quantiles, mean and number of missing values for numeric data.
#' 
#' @examples
#' library(RStudioTools)
#' 
#' # Now start the gadget (better to start via the [Addins] menu)
#' survivalGadget()
#' 
#' # Select 'Example 'lung'' in [select data] and as varaibles:
#' #   'status', 'time' & 'sex'
#' # Text output:
#' #  -  n events median 0.95LCL 0.95UCL
#' #  - group=1 138    112    270     212     310
#' #  - group=2  90     53    426     348     550
#' 
#' @export
#' @import miniUI rstudioapi shiny survival
survivalGadget <-
function(view = c("pane", "dialog", "browser")) {
    require(survival)
    
    ui <- miniPage(
      gadgetTitleBar("Survival analysis",  right = miniTitleBarButton("help", "Help", primary = TRUE)),
      
      miniTabstripPanel(
        miniTabPanel("Data", icon = icon("terminal"),
                     miniContentPanel(
                       fillCol(
                         selectInput(
                           "data",
                           "Select data *",
                           choices = "Example 'lung'",
                           selected = 1
                         ),
                         fillRow(
                           selectInput(
                             "varfail",
                             "Choose failure variable *",
                             choices = "---",
                             multiple = F
                           ),
                           selectInput(
                             "valuefail",
                             "Select value for failure",
                             choices = "-auto-",
                             multiple = F
                           )
                         ),
                         #verbatimTextOutput("strvarfail"),
                         selectInput(
                           "vartime",
                           "Choose time variable *",
                           choices = "---",
                           multiple = F
                         ),
                         selectInput(
                           "vargroup",
                           "Choose group variable",
                           choices = "---",
                           multiple = F
                         ),
                         verbatimTextOutput("strvar"),
                         flex = c(1, 1, 1, 1, 2)
                       )
                     )),
        miniTabPanel(
          "Plot",
          icon = icon("line-chart"),
          miniContentPanel(plotOutput("plot")),
          miniButtonBlock(actionButton(
            "pasteplotcode", "Paste plot code into script"
          ))
        ),
        miniTabPanel(
          "Estimate",
          icon = icon("gears"),
          miniContentPanel(verbatimTextOutput("est")),
          miniButtonBlock(
            actionButton("pastesumcode", "Paste summary code"),
            actionButton("pastedifcode", "Paste log rank code")
          )
        ),
        ## standard inspect panel
        miniTabPanel(
          "inspect",
          icon = icon("search-plus"),
          miniTabstripPanel(
            miniTabPanel("str", icon = icon("info"),
                         miniContentPanel(fillCol(
                           verbatimTextOutput("str")
                         ))),
            miniTabPanel("table", icon = icon("table"),
                         miniContentPanel(fillCol(
                           dataTableOutput('table')
                         ))),
            miniTabPanel("summary", icon = icon("list-ol"),
                         miniContentPanel(fillCol(
                           verbatimTextOutput('summary')
                         )))
          ),
          p("")
          
        )
      )
    )
    
    server <- function(input, output, session) {
      
      dataInput <- reactive({
        if (substr(input$data, 1, 9) == "Example '")
          get(gsub("'", "", substr(input$data, 10, 15), fixed = T))
        else
          get(input$data)
      })
      
      allVar <- reactive({
        c("---", colnames(dataInput()))
      })
      
      numVar <- reactive({
        c("---", colnames(dataInput()[sapply(dataInput(), class) %in% c("integer", "numeric", "logical")]))
      })
      
      varVal <- reactive({
        # changed 250723
        if(input$varfail %in% colnames(dataInput())) {
          vf <- input$varfail
          c("-auto-", sort(unique(dataInput()[, vf])))
        }
      })
      
      survMod <- reactive({
        # changed 250723
        if(input$varfail %in% colnames(dataInput()) & input$vartime %in% colnames(dataInput())) {
          vt <- input$vartime
          time <- dataInput()[, vt]
          vf <- input$varfail
          ifelse(
            input$valuefail == "-auto-",
            fail <-
              dataInput()[, vf],
            fail <- dataInput()[, vf] == input$valuefail
          )
          if (input$vargroup != "---") {
            vg <- which(colnames(dataInput()) == input$vargroup)
            group <- dataInput()[, vg]
            survmod <- survfit(Surv(time, fail) ~ group)
          }
          if (input$vargroup == "---")
            survmod <- survfit(Surv(time, fail) ~ 1)
          return(survmod)
        }    
      })
      
      survObj <- reactive({
        # changed 250723
        if(input$varfail %in% colnames(dataInput()) & input$vartime %in% colnames(dataInput())) {
          vt <- input$vartime
          time <- dataInput()[, vt]
          vf <- input$varfail
          ifelse(
            input$valuefail == "-auto-",
            fail <-
              dataInput()[, vf],
            fail <- dataInput()[, vf] == input$valuefail
          )
          return(Surv(time, fail))
        }  
      })
      sData <- reactive({
        datas <-
          Filter(function(x)
            inherits(get(x), "data.frame"),
            ls(envir = .GlobalEnv))
        c(datas,
          "Example 'lung'",
          "Example 'kidney'",
          "Example 'heart'")
      })
      
      observe({
        updateSelectInput(session, "data",
                          choices = sData())
      })
      observe({
        updateSelectInput(session, "varfail",
                          choices = numVar())
      })
      observe({
        updateSelectInput(session, "valuefail",
                          choices =  varVal())
      })
      observe({
        updateSelectInput(session, "vartime",
                          choices = numVar())
      })
      observe({
        updateSelectInput(session, "vargroup",
                          choices = allVar())
      })
      
      output$strvar <- renderPrint({
        if (input$varfail != "---" &
            (input$varfail == input$vartime |
             input$varfail == input$vargroup))
          print("WARNING: Failure, time and group should be different variables")
        else {
          print(input$varfail)
          if (input$varfail != "---") {
            vf <- which(colnames(dataInput()) == input$varfail)
            if (input$valuefail == "-auto-" &
                length(setdiff(unique(dataInput()[, vf]), c(T, F, 0, 1, 2, NA))) > 0)
              print("WARNING: Failure contains values not compatible with -auto-")
            str(dataInput()[, vf])
            
          }
          if (input$vartime != "---") {
            print(input$vartime)
            vt <- which(colnames(dataInput()) == input$vartime)
            str(dataInput()[, vt])
          }
          if (input$vargroup != "---") {
            print(input$vargroup)
            vg <- which(colnames(dataInput()) == input$vargroup)
            str(dataInput()[, vg])
          }
        }
      })
      output$plot <- renderPlot({
        if (input$vartime == "---" |
            input$varfail == "---")
          plot(
            NA,
            NA,
            xlim = c(0, 1),
            ylim = c(0, 1),
            xaxt = "n",
            yaxt = "n",
            xlab = "",
            ylab = "",
            main = "Failure and time are required fields"
          )
        else{
          if (input$vargroup == "---")
            plot(survMod(), main = "Kaplan-Meier survival estimates")
          if (input$vargroup != "---") {
            groups <- names(survMod()$strata)
            plot(
              survMod(),
              main = paste("Kaplan-Meier survival estimates by", input$vargroup),
              col = 1:length(groups)
            )
            legend(
              "bottomleft",
              legend = as.character(groups),
              col = 1:length(groups),
              lwd = 2
            )
          }
        }
      })
      output$est <- renderPrint({
        if (input$vartime == "---" |
            input$varfail == "---")
          print("Failure and time are required fields")
        else{
          print(survMod())
          if (input$vargroup != "---") {
            vg <- which(colnames(dataInput()) == input$vargroup)
            group <- dataInput()[, vg]
            print(survdiff(survObj() ~ group))
          }
          summary(survMod())
        }
      })
      
      observeEvent(input$pasteplotcode, {
        if (input$vargroup == "---") {
          if (input$valuefail == "-auto-")
            txt <-
              paste(
                "plot(survfit(Surv(",
                input$data,
                "$",
                input$vartime,
                ",",
                input$data,
                "$",
                input$varfail,
                ") ~ 1))",
                sep = ""
              )
          if (input$valuefail != "-auto-")
            txt <-
              paste(
                "plot(survfit(Surv(",
                input$data,
                "$",
                input$vartime,
                ",",
                input$data,
                "$",
                input$varfail,
                "==",
                input$valuefail,
                ") ~ 1))",
                sep = ""
              )
          txt <- gsub("Example ", "", txt)
          txt <- gsub("'", "", txt, fixed = T)
          rstudioapi::insertText(paste(txt, "\n"))
        }
        else {
          vg <- which(colnames(dataInput()) == input$vargroup)
          group <- dataInput()[, vg]
          if (input$valuefail == "-auto-")
            txt <-
            (
              paste(
                "plot(survfit(Surv(",
                input$data,
                "$",
                input$vartime,
                ",",
                input$data,
                "$",
                input$varfail,
                ") ~ ",
                input$data,
                "$",
                input$vargroup,
                "), lwd=2, col=1:",
                length(unique(group)),
                ")",
                sep = ""
              )
            )
          if (input$valuefail != "-auto-")
            txt <-
            (
              paste(
                "plot(survfit(Surv(",
                input$data,
                "$",
                input$vartime,
                ",",
                input$data,
                "$",
                input$varfail,
                "==",
                input$valuefail,
                ") ~ ",
                input$data,
                "$",
                input$vargroup,
                "), lwd=2, col=1:",
                length(unique(group)),
                ")",
                sep = ""
              )
            )
          txt <- gsub("Example ", "", txt)
          txt <- gsub("'", "", txt, fixed = T)
          rstudioapi::insertText(paste(txt, "\n"))
        }
      })
      observeEvent(input$pastesumcode, {
        if (input$vargroup == "---") {
          if (input$valuefail == "-auto-")
            txt <-
              paste(
                "print(survfit(Surv(",
                input$data,
                "$",
                input$vartime,
                ",",
                input$data,
                "$",
                input$varfail,
                ") ~ 1))",
                sep = ""
              )
          if (input$valuefail != "-auto-")
            txt <-
              paste(
                "print(survfit(Surv(",
                input$data,
                "$",
                input$vartime,
                ",",
                input$data,
                "$",
                input$varfail,
                "==",
                input$valuefail,
                ") ~ 1))",
                sep = ""
              )
          txt <- gsub("Example ", "", txt)
          txt <- gsub("'", "", txt, fixed = T)
          rstudioapi::insertText(paste(txt, "\n"))
        }
        else {
          vg <- which(colnames(dataInput()) == input$vargroup)
          group <- dataInput()[, vg]
          if (input$valuefail == "-auto-")
            txt <-
            paste(
              "print(survfit(Surv(",
              input$data,
              "$",
              input$vartime,
              ",",
              input$data,
              "$",
              input$varfail,
              ") ~ ",
              input$data,
              "$",
              input$vargroup,
              "))",
              sep = ""
            )
          if (input$valuefail != "-auto-")
            txt <-
            paste(
              "print(survfit(Surv(",
              input$data,
              "$",
              input$vartime,
              ",",
              input$data,
              "$",
              input$varfail,
              "==",
              input$valuefail,
              ") ~ ",
              input$data,
              "$",
              input$vargroup,
              "))",
              sep = ""
            )
          txt <- gsub("Example ", "", txt)
          txt <- gsub("'", "", txt, fixed = T)
          rstudioapi::insertText(paste(txt, "\n"))
        }
      })
      observeEvent(input$pastedifcode, {
        if (input$vargroup == "---")
          txt <- "# group variable required for log rank test"
        else {
          vg <- which(colnames(dataInput()) == input$vargroup)
          group <- dataInput()[, vg]
          if (input$valuefail == "-auto-")
            txt <- paste(
              "survdiff(Surv(",
              input$data,
              "$",
              input$vartime,
              ",",
              input$data,
              "$",
              input$varfail,
              ") ~ ",
              input$data,
              "$",
              input$vargroup,
              ")",
              sep = ""
            )
          if (input$valuefail != "-auto-")
            txt <-
            paste(
              "survdiff(Surv(",
              input$data,
              "$",
              input$vartime,
              ",",
              input$data,
              "$",
              input$varfail,
              "==",
              input$valuefail,
              ") ~ ",
              input$data,
              "$",
              input$vargroup,
              ")",
              sep = ""
            )
          txt <- gsub("Example ", "", txt)
          txt <- gsub("'", "", txt, fixed = T)
        }
        rstudioapi::insertText(paste(txt, "\n"))
      })
      
      ## standard inspect output when no data not possible
      ## - inspect -
      
      output$str <- renderPrint({
        str(
          dataInput(),
          give.attr = F,
          width = 70,
          strict.width = 'cut'
        )
      })
      output$table <- renderDataTable({
        dataInput()
      },
      options = list(pageLength = 7,  lengthMenu = c(5, 10, 25)))
      output$summary <- renderPrint({
        op <- options()
        options(width = 85)
        print(summary(dataInput()))
        options(op)
      })
      
      observeEvent(input$help, {
        RStudioTools:::browserHelp("survivalGadget", "RStudioTools")
      })
      observeEvent(input$cancel, {
        stopApp(print("Good bye"))
      })
    }
    view <- match.arg(view)
    viewer <- RStudioTools:::selectViewer(view, 700, 750)
    runGadget(ui, server, viewer = viewer, stopOnCancel = F)
  }
