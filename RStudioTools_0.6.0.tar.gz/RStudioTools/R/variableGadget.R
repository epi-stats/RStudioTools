#' @title RStudio Gadget for manipulating variables
#' 
#' @description Interactive interface to manipulate variables. Changing
#' classes (types), recoding, categorizing, transformation or calculation.
#' 
#' @param view Controls where the gadget is displayed: 'dialog' a new interactive
#' dialogue window, 'pane' the RStudio pane viewer or 'browser' the system default web
#' browser. The pane is usually the most convenient option, but the window size may be
#' too small if the screen size or resolution results in overlapping elements, especially
#' the 'browser' option which provides more space.
#' @details An RStudio addin (shiny gadgets) -
#' runs only with RStudio (v1.1.383 or later). 
#' The application is usually invoked via the Addins pulldown menu
#' (if the toolbar is not visible, choose [View] > [Show toolbars]).
#' The associated R code can be generated (recommended),
#' which will be pasted into the R-script.
#' 
#' [select data] pull down menu which lists all data frames available in the
#' R session. If the user has no data frames defined, 'No data in current R
#' session' appears. In this case the application has to be closed and data
#' needs to be be loaded or imported.
#' 
#' The tab panel consists of 6 tabs.
#' 
#' [inspect] provides different options to investigate the data.
#' [info] displays number of records and variables, the variable classes
#' (types) using \code{\link[utils]{str}}.
#' [table] displays a table which can be that can be searched, filtered
#' sorted.
#' [summary] displays a summary of all variables,
#' e.g. quantiles, mean and number of missing values for numeric data.
#' 
#' [change.type] Under this tab several options to manipulate variable
#' types (classes) are provided. It is possible to process several variables
#' at the same time. The tool provides key characteristics of the variables
#' before and after conversion. Most of them are self explaining.
#' The option 'text to numeric' will remove all characters except digits,
#' minus and a point, only the first minus and the first point will be kept
#' and the minus only if it precedes the point. The applied function is:
#' function(x) as.numeric(regmatches(gsub('[^0-9.-]','',x),
#' regexpr('[-]?[0-9]*[.]?[0-9]*',gsub('[^0-9.-]','',x)))))
#' 
#' [recode] This tool provides several options to recode variables, e.g.
#' to recode certain values to missing or to correct misspellings in text
#' or factor variables. The tool expects either one recode value 
#' (all values will be recoded to this value) or the same number of new
#' values to recode and recode values. In the latter case the recoding
#' is done sequentially, i.e. first the 1st specified value will be recoded
#' than the 2nd. Therefore, it is not possible to exchange 2 numbers.
#' In the text output box a preview of the original and recoded variables is
#' shown. If the option 'labels' is selected the new variable will be a factor
#' if 'values' is selected a numeric variable.
#' 
#' [categorise] splits a numerical variable into quantiles
#' or user defined intervals. The tool will show a histogram of the variable
#' to categorise and the single observations together with the category
#' intervals. In the text output box the number of observations in each
#' category are displayed. If the option labels is specified the new variable
#' will be categorical (factor) if values is specified a numeric.
#' 
#' [transform] provides several standard transformations.
#' The minimum, median, maximum and the number of non-missing and missing
#' records are displayed for the original and the transformed variable.
#' In addition, 2 histograms show the distribution of the original
#' and transformed values.
#' 
#'  [calculate] calculate new variables, e.g.
#' ' weight / height^2 ' to calculate the body mass index. The tool evaluates
#' if the entered expression is syntactically correct.
#' If not a warning message is shown.
#' 
#' [Assign & quit] executes the action and stop the application.
#' [Assign, paste and quit] as above + paste the code into the active
#' R-script at the last curser position. 
#' Make sure that the curser is at an appropriate position before running
#' the application.
#' [Assign, paste & continue] as above but will not stop the application.
#' 
#' Additional details and examples are provided in the package vignette (pdf)
#'  \url{/library/RStudioTools/doc/RstudioTools_introduction.pdf}
#' 
#' @export
#' @import miniUI rstudioapi shiny
variableGadget <-
function(view = c("pane", "dialog", "browser")) {
  
  ui <- miniPage(
  
    fillCol(
      fillRow(
        selectInput(
          "data",
          "Select data to manipulate",
          choices = "---",
          selected = 1
        ),
        miniButtonBlock(
          actionButton(
            "help",
            "Help",
            icon = icon("question"),
            style = "color: #ffffff; background-color: #444444"
          ),
          actionButton("quit", "Quit", icon = icon("close"),
                       style = "color: #ffffff; background-color: #444444"),
          border = "bottom"
        ),
        flex = c(3, 1)
      ),
      height = 50,
      style = "border-color: #000000; border-bottom-width: 5px"
    ),
    
    miniTabstripPanel(
      miniTabPanel(
        "inspect",
        icon = icon("search-plus"),
        miniTabstripPanel(
          miniTabPanel("info", icon = icon("info"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput("infoInspect")
                       ))),
          miniTabPanel("table", icon = icon("table"),
                       miniContentPanel(fillCol(
                         dataTableOutput('table')
                       ))),
          miniTabPanel("summary", icon = icon("list-ol"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput('summary')
                       )))
        ),
        p("") # insert space between the nested tab panels
      ),
      
      miniTabPanel(
        "change.type",
        icon = icon("text-width"),
        miniContentPanel(
          fillCol(
            radioButtons(
              "changeType",
              "Type of conversion",
              choices = c(
                "numeric to factor (categories)" = "1",
                "numeric to text" = "2",
                "text/numeric: change decimal from \",\" to \".\"" =
                  "3",
                "text to numeric" = "4",
                "text to factor (categories)" = "5",
                "text: remove leading & trailing spaces" = "6",
                "factor to text" = "7",
                "factor to numeric" = "8"
              ),
              inline = T
            ),
            selectInput(
              "typeVars",
              "Select variable(s)",
              choices = "",
              multiple = T,
              width = "80%"
            ),
            verbatimTextOutput("infoType"),
            miniButtonBlock(
              actionButton("assignCT", "Assign & quit", icon = icon("gears")),
              actionButton("assignPasteCT", "Assign, paste code & quit", icon = icon("paste")),
              actionButton(
                "assignContinueCT",
                "Assign, paste & continue",
                icon = icon("retweet")
              )
            ),
            flex = c(2.4, 2.4, 8.6, 0.8)
          )
        )
      ),
      
      miniTabPanel(
        "recode",
        icon = icon("sort-numeric-desc"),
        miniContentPanel(
          fillCol(
            radioButtons(
              "recodeType",
              "Type of recoding",
              choices = c(
                "Recode numeric values to missing (9, 99, 999 -> NA)" = "1",
                "Recode text/categories to missing ('don't know' & 'other' -> NA)" = "2",
                "Recode numeric values (2 -> 0)" = "3",
                "Aggregate/change categories ('mild','mod.', 'severe' -> 'yes')" = "4",
                "Change text variables ('female' -> 'Female')" = "5"
              ),
              inline = F,
              width = "80%"
            ),
            selectInput(
              "recodeVars",
              "Select variable(s)",
              choices = "",
              multiple = T,
              width = "95%"
            ),
            fillRow(
              selectInput(
                "oriValue",
                "Select values to recode",
                choices = "",
                multiple = T,
                width = "95%"
              ),
              selectInput(
                "recodeValue",
                "Select new values ... OR",
                choices = "",
                multiple = T,
                selected = NULL,
                width = "95%"
              ),
              textInput("insertValue", "Enter new values (e.g.: 0,1,2)"),
              flex = c(1, 1, 1)
            ),
            verbatimTextOutput("infoRecode"),
            miniButtonBlock(
              actionButton("assignRe", "Assign & quit", icon = icon("gears")),
              actionButton("assignPasteRe", "Assign, paste code & quit", icon = icon("paste")),
              actionButton(
                "assignContinueRe",
                "Assign, paste & continue",
                icon = icon("retweet")
              )
            ),
            flex = c(3.2, 1.5, 2, 4.8, 0.68)
          )
        )
      ),
      
      miniTabPanel("categorise", icon = icon("cut"),
                   miniContentPanel(
                     fillCol(
                       fillRow(
                         selectInput(
                           "catVar",
                           "Select variable",
                           choices = "---",
                           multiple = F,
                           width = "80%"
                         ),
                         verbatimTextOutput("infoCatVar"),
                         flex = c(1, 3)
                       ),
                       fillRow(
                         selectInput(
                           "quantile",
                           "Split data into quantiles . . . . . . . . OR",
                           choices = c(
                             "---" = "0",
                             "halfs" = "2",
                             "terciles" = "3",
                             "quartiles" = "4",
                             "qintiles" = "5",
                             "sextiles" = "6"
                           ),
                           multiple = F,
                           width = "80%"
                         ),
                         textInput("catManBreaks", "Specify breaks (separate with ' , ')")
                       ),
                       fillRow(
                         textInput("catName", "Name of new variable", placeholder = "grvar"),
                         selectInput(
                           "catLabel",
                           "Labels or numbers as group names",
                           choices = c("labels" = "1", "numbers" = "2"),
                           multiple = F,
                           width = "80%"
                         )
                       ),
                       verbatimTextOutput("infoCatBreak"),
                       plotOutput("plotCat", height = "300px"),
                       miniButtonBlock(
                         actionButton("assignCat", "Assign & quit", icon = icon("gears")),
                         actionButton("assignPasteCat", "Assign, paste code & quit", icon = icon("paste")),
                         actionButton(
                           "assignContinueCat",
                           "Assign, paste & continue",
                           icon = icon("retweet")
                         )
                       ),
                       flex = c(0.8, 0.8, 0.8, 1.4, 4, 0.47)
                     )
                   )),
      
      miniTabPanel(
        "transform",
        icon = icon("superscript"),
        miniContentPanel(
          fillCol(
            fillRow(
              selectInput(
                "transVar",
                "Select variable",
                choices = "---",
                multiple = F,
                width = "80%"
              ),
              selectInput(
                "transformation",
                "Select transformatoion",
                choices = c(
                  "log(x)",
                  "log(x+1)",
                  "log10(x)",
                  "sqrt(x)",
                  "(x)^2",
                  "asin(sqrt(x))/(pi/2)",
                  "2*asin(sqrt(x))"
                ),
                multiple = F,
                width = "80%"
              ),
              textInput("transName", "Name of new variable", placeholder =
                          "logvar")
            ),
            verbatimTextOutput("infoTrans"),
            plotOutput("plotTrans"),
            miniButtonBlock(
              actionButton("assignTr", "Assign & quit", icon = icon("gears")),
              actionButton("assignPasteTr", "Assign, paste code & quit", icon = icon("paste")),
              actionButton(
                "assignContinueTr",
                "Assign, paste & continue",
                icon = icon("retweet")
              )
            ),
            flex = c(2, 2.4, 9, 0.8)
          )
        )
      ),
      
      miniTabPanel(
        "calculate",
        icon = icon("calculator"),
        miniContentPanel(
          fillCol(
            fillRow(
              selectInput(
                "calcVar",
                "Insert variable in equation",
                choices = "---",
                multiple = F,
                width = "80%"
              ),
              selectInput(
                "operator",
                "Insert operator in equation",
                choices = c(
                  "---",
                  "+",
                  "-",
                  "*",
                  "/",
                  "(",
                  ")",
                  "^2",
                  "sqrt(",
                  "log(",
                  "&",
                  "|",
                  "=="
                ),
                multiple = F,
                width = "80%"
              ),
              textInput("calcName", "Name of new variable", placeholder = "newvar")
            ),
            textInput("equation", "Equation", width = "80%"),
            verbatimTextOutput('infoCalc'),
            miniButtonBlock(
              actionButton("assignCal", "Assign & quit", icon = icon("gears")),
              actionButton("assignPasteCal", "Assign, paste code & quit", icon = icon("paste")),
              actionButton(
                "assignContinueCal",
                "Assign, paste & continue",
                icon = icon("retweet")
              )
            ),
            flex = c(2, 2.4, 9, 0.8)
          )
        )
      )
    )
  )
  
  server <- (function(input, output, session) {
    
    ## - define common strings -
    
    noData <- c("---", "No data found in current R session")
    txtNoData <- "No data selected"
    txtNoVar <- "No variable selected"
    txtSelData <- "Select data"
    txtSelVar <- "Select variable"
    txtSelVars <- "Select variable(s)"
    
    ## - general functions -
    
    varclass <- function(vclass) {
      return(colnames(dataInput()[sapply(dataInput(), class) %in% vclass]))
    }
    
    checkVarName <- function(newname) {
      if (make.names(newname) != newname)
        cat(
          paste(
            "Warning: No (valid) new variable name provided, will be renamed to '",
            make.names(newname),
            "'\n",
            sep = ""
          )
        )
      if (make.names(newname) %in% colnames(dataInput()))
        cat(
          paste(
            "Warning: There is alraedy a variable named '",
            make.names(newname),
            "' in '",
            input$data,
            "' (assign will replace)\n",
            sep = ""
          )
        )
    }
    
    ## - choose data -
    
    dataInput <- reactive({
      if (input$data %in% noData)
        NULL
      else
        get(input$data)
    })
    
    listData <- reactive({
      if (length(Filter(
        function(x)
          inherits(get(x), "data.frame"),
        ls(envir = .GlobalEnv)
      )) > 0)
        c("---", Filter(
          function(x)
            inherits(get(x), "data.frame"),
          ls(envir = .GlobalEnv)
        ))
      else
        "No data found in current R session"
    })
    
    observe({
      updateSelectInput(session, "data", choices = listData())
    })
    
    ## - inspect -
    
    output$infoInspect <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else
        str(
          dataInput(),
          give.attr = F,
          width = 77,
          strict.width = 'cut'
        )
    })
    
    output$table <- renderDataTable({
      dataInput()
    },
    options = list(pageLength = 10,  lengthMenu = c(5, 10, 25)))
    
    output$summary <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        op <- options()
        options(width = 96)
        print(summary(dataInput()))
        options(op)
      }
    })
    
    ## - change type -
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        if (input$changeType %in% c("1", "2"))
          updateSelectInput(session, "typeVars", choices = varclass(c("numeric", "integer")))
        if (input$changeType %in% c("3", "4", "5", "6"))
          updateSelectInput(session, "typeVars", choices = varclass("character"))
        if (input$changeType %in% c("7", "8"))
          updateSelectInput(session, "typeVars", choices = varclass("factor"))
      }
    })
    
    observeEvent(input$changeType, {
      if (!input$data %in% noData) {
        if (input$changeType %in% c("1", "2"))
          updateSelectInput(session, "typeVars", choices = varclass(c("numeric", "integer")))
        if (input$changeType %in% c("3", "4", "5", "6"))
          updateSelectInput(session, "typeVars", choices = varclass("character"))
        if (input$changeType %in% c("7", "8"))
          updateSelectInput(session, "typeVars", choices = varclass("factor"))
      }
    })
    
    output$infoType <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        cat(paste(
          "Variables:",
          ncol(dataInput()),
          ", observations:",
          nrow(dataInput()),
          "\n"
        ))
        if (is.null(input$typeVars))
          cat(txtSelVars)
        else {
          if (all(input$typeVars %in% colnames(dataInput()))) {
            for (i in 1:min(10, length(input$typeVars))) {
              ivar <- input$typeVars[i]
              cat(paste(substr(ivar, 1, 10)))
              cat(str(
                dataInput()[, ivar],
                give.attr = F,
                width = 76,
                strict.width = 'cut'
              ))
              cat(paste("- new:"))
              if (input$changeType %in% c("1", "5"))
                cat(str(
                  as.factor(dataInput()[, ivar]),
                  give.attr = F,
                  width = 76,
                  strict.width = 'cut'
                ))
              if (input$changeType %in% c("2", "7"))
                cat(str(
                  as.character(dataInput()[, ivar]),
                  give.attr = F,
                  width = 76,
                  strict.width = 'cut'
                ))
              if (input$changeType == "3")
                cat(str(
                  as.numeric(gsub(
                    ",", ".", dataInput()[, ivar], fixed = T
                  )),
                  give.attr = F,
                  width = 76,
                  strict.width = 'cut'
                ))
              if (input$changeType == "4")
                cat(str(as.numeric(
                  regmatches(
                    gsub('[^0-9.-]', '', dataInput()[, ivar]),
                    regexpr(
                      '[-]?[0-9]*[.]?[0-9]*',
                      gsub('[^0-9.-]', '', dataInput()[, ivar])
                    )
                  )
                )))
              if (input$changeType == "6")
                cat(str(
                  trimws(dataInput()[, ivar]),
                  give.attr = F,
                  width = 76,
                  strict.width = 'cut'
                ))
              if (input$changeType == "8")
                cat(str(
                  as.numeric(as.character(dataInput()[, ivar])),
                  give.attr = F,
                  width = 76,
                  strict.width = 'cut'
                ))
            }
            if (length(input$typeVars) > 10)
              cat(paste("[output truncated]"))
          }
        }
      }
    })
    
    applyType <- function() {
      tvars <- which(colnames(dataInput()) %in% input$typeVars)
      dtemp <- dataInput()
      if (input$changeType %in% c("1", "5")) {
        if (length(tvars) == 1)
          dtemp[, tvars] <- factor(dtemp[, tvars])
        else
          dtemp[, tvars] <- lapply(dtemp[, tvars], factor)
      }
      if (input$changeType %in% c("2", "7")) {
        if (length(tvars) == 1)
          dtemp[, tvars] <- as.character(dtemp[, tvars])
        else
          dtemp[, tvars] <- lapply(dtemp[, tvars], as.character)
      }
      if (input$changeType == "3") {
        if (length(tvars) == 1)
          dtemp[, tvars] <-
            as.numeric(gsub(",", ".", dtemp[, tvars], fixed = T))
        else
          dtemp[, tvars] <-
            sapply(dtemp[, tvars], function(x)
              as.numeric(gsub(",", ".", (x))))
      }
      if (input$changeType == "4") {
        if (length(tvars) == 1)
          dtemp[, tvars] <-
            as.numeric(regmatches(
              gsub('[^0-9.-]', '', dtemp[, tvars]),
              regexpr('[-]?[0-9]*[.]?[0-9]*', gsub('[^0-9.-]', '', dtemp[, tvars]))
            ))
        else
          dtemp[, tvars] <-
            sapply(dtemp[, tvars], function(x)
              as.numeric(regmatches(
                gsub('[^0-9.-]', '', x),
                regexpr('[-]?[0-9]*[.]?[0-9]*', gsub('[^0-9.-]', '', x))
              )))
      }
      if (input$changeType == "6") {
        if (length(tvars) == 1)
          dtemp[, tvars] <- trimws(dtemp[, tvars])
        else
          dtemp[, tvars] <- sapply(dtemp[, tvars], trimws)
      }
      if (input$changeType == "8") {
        if (length(tvars) == 1)
          dtemp[, tvars] <- as.numeric(as.character(dtemp[, tvars]))
        else
          dtemp[, tvars] <-
            sapply(dtemp[, tvars], function(x)
              as.numeric(as.character(x)))
      }
      assign(input$data, dtemp , pos = .GlobalEnv)
    }
    
    pasteTypeCode <- function() {
      if (length(input$typeVars) == 1)
        vnames <- paste("\"", input$typeVars, "\"", sep = "")
      else
        vnames <-
          paste("c(\"",
                paste(input$typeVars, collapse = "\",\""),
                "\")",
                sep = "")
      if (input$changeType %in% c("1", "5")) {
        if (length(input$typeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- factor(",
              input$data,
              "[,",
              vnames,
              "])\n",
              sep = ""
            )
          )
        else
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- lapply(",
              input$data,
              "[,",
              vnames,
              "], factor)\n",
              sep = ""
            )
          )
      }
      if (input$changeType %in% c("2", "7")) {
        if (length(input$typeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- as.character(",
              input$data,
              "[,",
              vnames,
              "])\n",
              sep = ""
            )
          )
        else
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- sapply(",
              input$data,
              "[,",
              vnames,
              "], as.character)\n",
              sep = ""
            )
          )
      }
      if (input$changeType == 3) {
        if (length(input$typeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- as.numeric(gsub(\",\",\".\",(",
              input$data,
              "[,",
              vnames,
              "])))\n",
              sep = ""
            )
          )
        else
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- sapply(",
              input$data,
              "[,",
              vnames,
              "], function(x) as.numeric(gsub(\",\",\".\",(x))))\n",
              sep = ""
            )
          )
      }
      if (input$changeType == 4) {
        if (length(input$typeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- as.numeric(regmatches(gsub('[^0-9.-]','', ",
              input$data,
              "[,",
              vnames,
              "]), regexpr('[-]?[0-9]*[.]?[0-9]*',gsub('[^0-9.-]','',",
              input$data,
              "[,",
              vnames,
              "]))))\n",
              sep = ""
            )
          )
        else
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- sapply(",
              input$data,
              "[,",
              vnames,
              "], function(x) as.numeric(regmatches(gsub('[^0-9.-]','',x), regexpr('[-]?[0-9]*[.]?[0-9]*',gsub('[^0-9.-]','',x)))))\n",
              sep = ""
            )
          )
      }
      if (input$changeType == 6) {
        if (length(input$typeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- trimws(",
              input$data,
              "[,",
              vnames,
              "])\n",
              sep = ""
            )
          )
        else
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- sapply(",
              input$data,
              "[,",
              vnames,
              "], trimws)\n",
              sep = ""
            )
          )
      }
      if (input$changeType == "8") {
        if (length(input$typeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- as.numeric(as.character(",
              input$data,
              "[,",
              vnames,
              "]))\n",
              sep = ""
            )
          )
        else
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <- sapply(",
              input$data,
              "[,",
              vnames,
              "], function(x) as.numeric(as.character(x)))\n",
              sep = ""
            )
          )
      }
    }
    
    observeEvent(input$assignCT, {
      if (input$data %in% noData)
        print(txtNoData)
      else {
        if (is.null(input$typeVars))
          print(txtNoVar)
        else {
          applyType()
          stopApp(NULL)
        }
      }
    })
    
    observeEvent(input$assignPasteCT, {
      if (input$data %in% noData)
        print(txtNoData)
      else {
        if (is.null(input$typeVars))
          print(txtNoVar)
        else {
          applyType()
          pasteTypeCode()
          stopApp(NULL)
        }
      }
    })
    
    observeEvent(input$assignContinueCT, {
      if (input$data %in% noData)
        print(txtNoData)
      else{
        if (is.null(input$typeVars))
          print(txtNoVar)
        else{
          applyType()
          pasteTypeCode()
          updateSelectInput(session,
                            "data",
                            choices = listData(),
                            selected = "---")
        }
      }
    })
    
    ## - recode -
    
    # update list of eligible variables
    observeEvent({
      input$data
      input$recodeType
    },
    {
      updateTextInput(session,
                      "insertValue",
                      "Enter new values (e.g.: 0,1,2)",
                      value = "")
      if (input$data %in% noData) {
        updateSelectInput(session,
                          "recodeVars",
                          choices = "",
                          selected = "")
      }
      else {
        if (input$recodeType == "1") {
          updateSelectInput(session,
                            "recodeVars",
                            choices = varclass(c("numeric", "integer")),
                            selected = "")
          updateSelectInput(session,
                            "recodeValue",
                            choices = "NA",
                            selected = "NA")
        }
        if (input$recodeType == "2") {
          updateSelectInput(session,
                            "recodeVars",
                            choices = varclass(c("character", "factor")),
                            selected = "")
          updateSelectInput(session,
                            "recodeValue",
                            choices = "NA",
                            selected = "NA")
        }
        if (input$recodeType == "3") {
          updateSelectInput(session,
                            "recodeVars",
                            choices = varclass(c("numeric", "integer")),
                            selected = "")
          updateSelectInput(session,
                            "recodeValue",
                            choices = "",
                            selected = "")
        }
        if (input$recodeType == "4") {
          updateSelectInput(
            session,
            "recodeVars",
            choices = varclass("factor"),
            selected = ""
          )
          updateSelectInput(session,
                            "recodeValue",
                            choices = "",
                            selected = "")
        }
        if (input$recodeType  == "5") {
          updateSelectInput(
            session,
            "recodeVars",
            choices = varclass("character"),
            selected = ""
          )
          updateSelectInput(session,
                            "recodeValue",
                            choices = "",
                            selected = "")
        }
      }
    })
    
    observeEvent(input$recodeVars, {
      updateSelectInput(session, "oriValue", selected = "")
      if (input$data %in% noData |  is.null(input$recodeVars)) {
        updateSelectInput(session,
                          "oriValue",
                          choices = "",
                          selected = "")
      }
      if (!input$data %in% noData & !is.null(input$recodeVars)) {
        svars <- which(colnames(dataInput()) %in% input$recodeVars)
        if (length(svars) > 0) {
          if (input$recodeType %in% c("1", "3", "5"))
            updateSelectInput(session,
                              "oriValue",
                              choices = sort(unique(unlist(
                                dataInput()[, svars]
                              ))),
                              selected = "")
          else
            updateSelectInput(session,
                              "oriValue",
                              choices = sort(unique(as.character(
                                unlist(dataInput()[, svars])
                              ))),
                              selected = "")
          if (input$recodeType %in% c("1", "2")) {
            updateSelectInput(session,
                              "recodeValue",
                              choices = "NA",
                              selected = "NA")
            updateTextInput(session,
                            "insertValue",
                            "Enter new values (e.g.: 0,1,2)",
                            value = "")
          }
          if (input$recodeType %in% c("3", "5"))
            updateSelectInput(
              session,
              "recodeValue",
              choices = sort(unique(unlist(
                dataInput()[, svars]
              ))),
              selected = ""
            )
          if (input$recodeType == "4")
            updateSelectInput(
              session,
              "recodeValue",
              choices = sort(unique(as.character(
                unlist(dataInput()[, svars])
              ))),
              selected = ""
            )
        }
      }
    })
    
    observeEvent(input$recodeValue, {
      if (!is.null(input$recodeValue))
        updateTextInput(session,
                        "insertValue",
                        "Enter new values (e.g.: 0,1,2)",
                        value = "")
    })
    
    observeEvent(input$insertValue, {
      if (input$recodeType %in% c("3", "4", "5") &
          input$insertValue != "")
        updateSelectInput(session, "recodeValue", selected = "")
      if (input$recodeType == "3" &  input$insertValue != "") {
        if (regexec('[^0-9.,-NA]', input$insertValue)[[1]] != -1)
          updateTextInput(
            session,
            "insertValue",
            "Enter new... Only numbers!",
            value = gsub('[^0-9.,-NA]', "", input$insertValue)
          )
      }
    })
    
    output$infoRecode <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        cat(paste(
          "Variables:",
          ncol(dataInput()),
          ", observations:",
          nrow(dataInput()),
          "\n"
        ))
        if (is.null(input$recodeVars))
          cat(txtSelVars)
        else {
          # the variable name check can be at any position - just here for convinience
          if (is.null(input$oriValue) |
              !all(input$recodeVars %in% colnames(dataInput())))
            cat("Specify values to recode")
          else {
            if (is.null(input$recodeValue) &
                input$insertValue == "")
              cat("Specify recode values")
            else {
              oval <- input$oriValue
              if (is.null(input$recodeValue))
                rval <-
                  unlist(strsplit(input$insertValue, split = ","))
              else
                rval <- input$recodeValue
              if (!length(rval) %in% c(1, length(oval)))
                cat(
                  "ERROR: numbers of recode values must be 1 or the same number as original values"
                )
              else {
                cat(paste(
                  "Replacement:",
                  paste(
                    oval,
                    ":",
                    rval,
                    ", ",
                    sep = "",
                    collapse = ","
                  ),
                  "\n"
                ))
                svars <-
                  which(colnames(dataInput()) %in% input$recodeVars)
                for (i in 1:min(5, length(input$recodeVars))) {
                  ivar <- as.character(dataInput()[, svars[i]])
                  cat(paste(
                    substr(input$recodeVars[i], 1, 10),
                    substr(paste((
                      ivar
                    ), collapse = ","), 1, 60),
                    "\n"
                  ))
                  if (length(rval) == 1) {
                    ivar[ivar %in% oval] <- gsub("\"", "", rval)
                    cat(paste(" - new:", substr(
                      paste((ivar), collapse = ","), 1, 60
                    ), "\n"))
                  }
                  else {
                    for (j in 1:length(rval))
                      ivar[ivar == oval[j]] <-
                        gsub("\"", "", rval[j])
                    cat(paste(" - new:", substr(
                      paste((ivar), collapse = ","), 1, 60
                    ), "\n"))
                  }
                }
              }
              if (length(input$recodeVars) > 5)
                cat(paste("[output truncated]"))
            }
          }
        }
      }
    })
    
    checkAssignRecode <- function() {
      ok <- F
      if (input$data %in% noData)
        print(txtNoData)
      else {
        if (is.null(input$recodeVars))
          print(txtNoVar)
        else{
          if (is.null(input$oriValue))
            print("No values to recode specified - nothing done")
          else{
            if (is.null(input$recodeValue) &
                input$insertValue == "")
              print("No recode values specified - nothing done")
            else{
              if (is.null(input$recodeValue))
                rval <-
                  unlist(strsplit(input$insertValue, split = ","))
              else
                rval <- input$recodeValue
              if (!length(rval) %in% c(1, length(input$oriValue)))
                print(
                  "Numbers of recode values must be 1 or the same number as original values - nothing done"
                )
              else
                ok <- T
            }
          }
        }
      }
      return(ok)
    }
    
    pasteRecodeCode <- function() {
      if (length(input$recodeVars) == 1)
        vnames <- paste("\"", input$recodeVars, "\"", sep = "")
      else
        vnames <-
          paste("c(\"",
                paste(input$recodeVars, collapse = "\",\""),
                "\")",
                sep = "")
      if (is.null(input$recodeValue))
        rval <- unlist(strsplit(input$insertValue, split = ","))
      else
        rval <- input$recodeValue
      if (input$recodeType == "1") {
        if (length(input$recodeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              input$recodeVars,
              "[",
              input$data,
              "$",
              input$recodeVars,
              " %in% c(",
              paste(input$oriValue, sep = "", collapse = ","),
              ")] <- NA\n",
              sep = ""
            )
          )
        else
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <-  sapply(",
              input$data,
              "[,",
              vnames,
              "], function(x) ifelse(x %in% c(",
              paste(input$oriValue, sep = "", collapse = ","),
              "), NA, x))\n",
              sep = ""
            )
          )
      }
      if (input$recodeType == "2") {
        for (i in 1:length(input$recodeVars)) {
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              input$recodeVars[i],
              "[",
              input$data,
              "$",
              input$recodeVars[i],
              " %in% c(\"",
              paste(
                input$oriValue,
                sep = "",
                collapse = "\",\""
              ),
              "\")] <- NA",
              sep = ""
            )
          )
        }
      }
      if (input$recodeType == "3") {
        if (length(rval) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <-  sapply(",
              input$data,
              "[,",
              vnames,
              "], function(x) ifelse(x %in% c(",
              paste(input$oriValue, sep = "", collapse = ","),
              "), ",
              rval,
              ", x))\n",
              sep = ""
            )
          )
        else{
          for (i in 1:length(rval)) {
            rstudioapi::insertText(
              paste(
                "\n",
                input$data,
                "[,",
                vnames,
                "] <-  sapply(",
                input$data,
                "[,",
                vnames,
                "], function(x) ifelse(x == ",
                input$oriValue[i],
                ", ",
                rval[i],
                ", x))\n",
                sep = ""
              )
            )
          }
        }
      }
      if (input$recodeType %in% c("4", "5")) {
        if (input$recodeType == "4" & length(input$recodeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              input$recodeVars,
              " <- as.character(",
              input$data,
              "$",
              input$recodeVars,
              ")\n",
              sep = ""
            )
          )
        if (input$recodeType == "4" & length(input$recodeVars) > 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <-  lapply(",
              input$data,
              "[,",
              vnames,
              "], as.character)\n",
              sep = ""
            )
          )
        if (length(rval) == 1 & length(input$recodeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              input$recodeVars,
              "[",
              input$data,
              "$",
              input$recodeVars,
              " %in% c(\"",
              paste(input$oriValue, sep = "", collapse = "\",\""),
              "\")] <- \"",
              rval,
              "\"\n",
              sep = ""
            )
          )
        
        if (length(rval) == 1 & length(input$recodeVars) > 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <-  sapply(",
              input$data,
              "[,",
              vnames,
              "], function(x) ifelse(x %in% c(\"",
              paste(input$oriValue, sep = "", collapse = "\",\""),
              "\"), \"",
              rval,
              "\", x))\n",
              sep = ""
            )
          )
        if (length(rval) > 1) {
          for (i in 1:length(rval))
            rstudioapi::insertText(
              paste(
                "\n",
                input$data,
                "[,",
                vnames,
                "] <-  sapply(",
                input$data,
                "[,",
                vnames,
                "], function(x) ifelse(x == \"",
                input$oriValue[i],
                "\", \"",
                rval[i],
                "\", x))\n",
                sep = ""
              )
            )
        }
        if (input$recodeType == "4" &
            length(input$recodeVars) == 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              input$recodeVars,
              " <- as.factor(",
              input$data,
              "$",
              input$recodeVars,
              ")\n",
              sep = ""
            )
          )
        if (input$recodeType == "4" & length(input$recodeVars) > 1)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "[,",
              vnames,
              "] <-  lapply(",
              input$data,
              "[,",
              vnames,
              "], as.factor)\n",
              sep = ""
            )
          )
      }
    }
    
    applyRecode <- function() {
      tdata <- dataInput()
      tvars <- which(colnames(dataInput()) %in% input$recodeVars)
      if (is.null(input$recodeValue))
        rval <- unlist(strsplit(input$insertValue, split = ","))
      else
        rval <- input$recodeValue
      if (input$recodeType == "1")
        tdata[, tvars] <-
        sapply(tdata[, tvars], function(x)
          ifelse(x %in% input$oriValue, NA, x))
      if (input$recodeType == "2") {
        for (i in 1:length(tvars))
          tdata[tdata[, tvars[i]] %in% input$oriValue, tvars[i]] <-
            NA
      }
      if (input$recodeType == "3") {
        if (length(rval) == 1)
          tdata[, tvars] <- sapply(tdata[, tvars],
                                   function(x)
                                     ifelse(x %in% as.numeric(input$oriValue), as.numeric(rval), x))
        else{
          for (i in 1:length(rval)) {
            tdata[, tvars] <- sapply(tdata[, tvars],
                                     function(x)
                                       ifelse(
                                         x == as.numeric(input$oriValue[i]),
                                         as.numeric(rval[i]),
                                         x
                                       ))
          }
        }
      }
      if (input$recodeType %in% c("4", "5")) {
        if (input$recodeType == "4")
          tdata[, tvars] <-
            lapply(data.frame(tdata[, tvars]), as.character)
        if (length(rval) == 1)
          tdata[, tvars] <- sapply(tdata[, tvars],
                                   function(x)
                                     ifelse(x %in% input$oriValue, rval, x))
        else{
          for (i in 1:length(rval))
            tdata[, tvars] <- sapply(tdata[, tvars],
                                     function(x)
                                       ifelse(x == input$oriValue[i], rval[i], x))
        }
        if (input$recodeType == "4")
          tdata[, tvars] <-
            lapply(data.frame(tdata[, tvars]), as.factor)
      }
      assign(input$data, tdata, pos = .GlobalEnv)
    }
    
    observeEvent(input$assignRe, {
      if (checkAssignRecode()) {
        applyRecode()
        stopApp(NULL)
      }
    })
    
    observeEvent(input$assignPasteRe, {
      if (checkAssignRecode()) {
        applyRecode()
        pasteRecodeCode()
        stopApp(NULL)
      }
    })
    
    observeEvent(input$assignContinueRe, {
      if (checkAssignRecode()) {
        applyRecode()
        pasteRecodeCode()
        updateSelectInput(session,
                          "data",
                          choices = listData(),
                          selected = "---")
      }
    })
    
    ## - categorize -
    
    cutVariable <- function(x) {
      if (input$quantile == "0") {
        breakpoints <-
          suppressWarnings(try(unique(as.numeric(unlist(
            strsplit(input$catManBreaks, split = ",")))), silent = T)) 
        if (class(breakpoints) == "try-error")
          return(NULL)
        if (length(breakpoints) < 2)
          return(NULL)
      } else {
        breakpoints <-
          quantile(x,
                   probs = seq(0, 1, length.out = as.numeric(input$quantile) + 1),
                   na.rm = T)
      }
      if (input$catLabel == "1")
        labels <- NULL
      if (input$catLabel == "2")
        labels <- F
      cvar <-
        try(cut(x,
                breaks = breakpoints,
                labels = labels,
                include.lowest = T,
                dig.lab = 3))
      # if(length(breakpoints) == 1) cutoff <- unique(as.numeric(unlist(strsplit(gsub("]","",gsub("(","",levels(cut(x, breaks=breakpoints)), fixed=T),fixed=T),split=","))))
      # else cutoff <- breakpoints
      # attr(cvar, "points") <- breakpoints
      attr(cvar, "breaks") <- breakpoints
      attr(cvar, "labs") <- labels
      return(cvar)
    }
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(session, "catVar", choices = c("---", varclass(c(
          "numeric", "integer"
        ))))
      }
    })
    
    observeEvent(input$quantile, {
      if (input$quantile != "0")
        updateTextInput(session, "catManBreaks", value = "")
    })
    
    observeEvent(input$catManBreaks, {
      if (input$catManBreaks != "")
        updateSelectInput(session, "quantile", selected = "0")
    })
    
    output$infoCatVar <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else{
        if (input$catVar == "---" |
            !input$catVar %in% colnames(dataInput()))
          cat(txtSelVar)
        else{
          tvar <- dataInput()[, input$catVar]
          cat(paste(
            input$catVar,
            "-  N non-NA:",
            sum(!is.na(tvar)),
            ", N NA:",
            sum(is.na(tvar)),
            "\n",
            sep = ""
          ))
          cat(paste(
            c("min:", ", q25: ", ", med: ", ", q75:", ", max: "),
            quantile(tvar, na.rm = T)
          ))
        }
      }
    })
    
    output$infoCatBreak <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else{
        if (input$catVar == "---" |
            !input$catVar %in% colnames(dataInput()))
          cat(txtSelVar)
        else{
          if (input$quantile == "0" &
              input$catManBreaks == "")
            cat("Specify group intervals")
          else{
            checkVarName(input$catName)
            tvar <- dataInput()[, input$catVar]
            cvar <- try(cutVariable(tvar))
            if (!is.null(cvar))
              cat(paste("breaks:", paste(
                attr(cvar, "breaks"), collapse = ","
              ), "\n"))
            if (!is.null(cvar))
              cat(paste(
                "Freq:",
                paste(
                  names(table(cvar, useNA = "always")),
                  ":",
                  table(cvar, useNA = "always"),
                  ", ",
                  sep = "",
                  collapse = ""
                )
              ))
          }
        }
      }
    })
    
    output$plotCat <- renderPlot({
      if (!input$data %in% noData &
          input$catVar != "---" &
          input$catVar %in% colnames(dataInput())) {
        tvar <- dataInput()[, input$catVar]
        cvar <- cutVariable(tvar)
        if (!is.null(cvar)) {
          mincut <- min(attr(cvar, "breaks"))
          maxcut <- max(attr(cvar, "breaks"))
          par(mfrow = c(2, 1), mar = c(0.2, 2, 2, 1))
          hist(
            tvar,
            breaks = 20,
            xlim = c(min(c(
              tvar, mincut
            ), na.rm = T), max(c(
              tvar, maxcut
            ), na.rm = T)),
            xaxt = "n",
            yaxt = "n",
            xlab = "",
            main = paste("Histogram of", input$catVar)
          )
          set.seed(1103)
          par(mar = c(2, 2, 0.2, 1))
          plot(
            tvar,
            rnorm(length(tvar), 0, 0.2),
            ylim = c(-1, 1),
            xlim = c(min(c(
              tvar, mincut
            ), na.rm = T), max(c(
              tvar, maxcut
            ), na.rm = T)),
            yaxt = "n"
          )
          cvar <- cutVariable(tvar)
          abline(v = attr(cvar, "breaks"),
                 col = "red",
                 lwd = 2)
        }
      }
    })
    
    checkAssignCat <- function() {
      ok <- F
      if (input$data %in% noData)
        print(txtNoData)
      else{
        if (input$catVar == "---")
          print(txtNoVar)
        else{
          if (input$quantile == "0" &
              input$catManBreaks == "")
            print("No labels specified")
          else
            ok <- T
        }
      }
      return(ok)
    }
    
    observeEvent(input$assignCat, {
      if (checkAssignCat()) {
        tvar <- dataInput()[, input$catVar]
        cvar <- try(cutVariable(tvar))
        if (is.null(cvar) |
            class(cvar) == "try-error")
          print("Categorisation was not successful - nothing done")
        else {
          dtemp <- dataInput()
          dtemp[, make.names(input$catName)] <- cvar
          assign(input$data, dtemp, pos = .GlobalEnv)
          stopApp(NULL)
        }
      }
    })
    
    observeEvent(input$assignPasteCat, {
      if (checkAssignCat()) {
        tvar <- dataInput()[, input$catVar]
        cvar <- try(cutVariable(tvar))
        if (is.null(cvar) |
            class(cvar) == "try-error")
          print("Categorisation was not successful - nothing done")
        else {
          dtemp <- dataInput()
          dtemp[, make.names(input$catName)] <- cvar
          assign(input$data, dtemp, pos = .GlobalEnv)
          br <- attr(cvar, "breaks")
          labs <- attr(cvar, "labs")
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              make.names(input$catName),
              " <- cut(",
              input$data,
              "$",
              input$catVar,
              ", breaks=c(",
              paste(br, collapse = ","),
              "), include.lowest=T, labels =",
              labs,
              ")\n",
              sep = ""
            )
          )
          stopApp(NULL)
        }
      }
    })
    
    observeEvent(input$assignContinueCat, {
      if (checkAssignCat()) {
        tvar <- dataInput()[, input$catVar]
        cvar <- try(cutVariable(tvar))
        if (is.null(cvar) |
            class(cvar) == "try-error")
          print("Categorisation was not successful - nothing done")
        else {
          dtemp <- dataInput()
          dtemp[, make.names(input$catName)] <- cvar
          assign(input$data, dtemp, pos = .GlobalEnv)
          br <- attr(cvar, "breaks")
          labs <- attr(cvar, "labs")
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              make.names(input$catName),
              " <- cut(",
              input$data,
              "$",
              input$catVar,
              ", include.lowest=T, breaks=c(",
              paste(br, collapse = ","),
              "), labels =",
              labs,
              ")\n",
              sep = ""
            )
          )
          updateSelectInput(session,
                            "data",
                            choices = listData(),
                            selected = "---")
        }
      }
    })
    
    ## - transform data -
    
    trans <- function(x)
      eval(parse(text = input$transformation))
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(session, "transVar", choices = c("---", varclass(c(
          "numeric", "integer"
        ))))
      }
    })
    
    output$infoTrans <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        if (input$transVar == "---" |
            !input$transVar %in% colnames(dataInput()))
          cat(txtSelVar)
        else{
          checkVarName(input$transName)
          vori <- dataInput()[, input$transVar]
          cat(
            paste(
              input$transVar,
              " - min:",
              round(min(vori, na.rm = T), 1),
              ", median:",
              round(median(vori, na.rm = T), 1),
              ", max:",
              round(max(vori, na.rm = T), 1),
              ", N non-NA:",
              sum(!is.na(vori)),
              ", N NA:",
              sum(is.na(vori)),
              "\n",
              sep = ""
            )
          )
          suppressWarnings(vnew <- trans(vori))
          suppressWarnings(cat(
            paste(
              make.names(input$transName),
              " - min:",
              round(min(vnew, na.rm = T), 1),
              ", median:",
              round(median(vnew, na.rm = T), 1),
              ", max:",
              round(max(vnew, na.rm = T), 1),
              ", N non-NA:",
              sum(!is.na(vnew)),
              ", N NA:",
              sum(is.na(vnew)),
              "\n",
              sep = ""
            )
          ))
        }
      }
    })
    
    output$plotTrans <- renderPlot({
      if (!input$data %in% noData &
          input$transVar != "---" &
          input$transVar %in% colnames(dataInput())) {
        vori <- dataInput()[, input$transVar]
        suppressWarnings(vnew <- trans(vori))
        par(mfrow = c(2, 1), mar = c(2, 2, 2, 1))
        hist(
          vori,
          xlab = "",
          main = paste("Histogram of", input$transVar),
          breaks = 20
        )
        if (any(is.finite(vnew)))
          hist(
            vnew,
            xlab = "",
            main = paste("Histogram of", make.names(input$transName)),
            breaks = 20
          )
        else
          plot(
            1,
            1,
            xaxt = "n",
            yaxt = "n",
            xlab = "",
            ylab = "",
            main = paste("No finite values in", make.names(input$transName))
          )
      }
    })
    
    observeEvent(input$assignTr, {
      if (input$data %in% noData)
        stopApp(print(txtNoData))
      else{
        if (input$transVar == "---")
          stopApp(print(txtNoVar))
        else{
          vori <- dataInput()[, input$transVar]
          suppressWarnings(vnew <- trans(vori))
          if (!any(is.finite(vnew)))
            stopApp(print(
              "No finite values in transformed variable - nothing done"
            ))
          else{
            assigntxt <-
              paste(
                input$data,
                "$",
                make.names(input$transName),
                " <<- c(",
                paste(vnew, collapse = ","),
                ")",
                sep = ""
              )
            eval(parse(text = assigntxt))
            stopApp(NULL)
          }
        }
      }
    })
    
    observeEvent(input$assignPasteTr, {
      if (input$data %in% noData)
        stopApp(print(txtNoData))
      else{
        if (input$transVar == "---")
          stopApp(print(txtNoVar))
        else{
          vori <- dataInput()[, input$transVar]
          suppressWarnings(vnew <- trans(vori))
          if (!any(is.finite(vnew)))
            print("No finite values in transformed variable - nothing done")
          else{
            assigntxt <-
              paste(
                input$data,
                "$",
                make.names(input$transName),
                " <<- c(",
                paste(vnew, collapse = ","),
                ")",
                sep = ""
              )
            eval(parse(text = assigntxt))
            vartxt <-
              paste(input$data, "$", input$transVar, sep = "")
            rstudioapi::insertText(paste(
              "\n",
              input$data,
              "$",
              make.names(input$transName),
              " <- ",
              gsub("x", vartxt, input$transformation, fixed = T),
              "\n",
              sep = ""
            ))
            stopApp(NULL)
          }
        }
      }
    })
    
    observeEvent(input$assignContinueTr, {
      if (input$data %in% noData)
        stopApp(print(txtNoData))
      else{
        if (input$transVar == "---")
          stopApp(print(txtNoVar))
        else{
          vori <- dataInput()[, input$transVar]
          suppressWarnings(vnew <- trans(vori))
          if (!any(is.finite(vnew)))
            stopApp(print(
              "No finite values in transformed variable - nothing done"
            ))
          else{
            assigntxt <-
              paste(
                input$data,
                "$",
                make.names(input$transName),
                " <<- c(",
                paste(vnew, collapse = ","),
                ")",
                sep = ""
              )
            eval(parse(text = assigntxt))
            vartxt <-
              paste(input$data, "$", input$transVar, sep = "")
            rstudioapi::insertText(paste(
              "\n",
              input$data,
              "$",
              make.names(input$transName),
              " <- ",
              gsub("x", vartxt, input$transformation, fixed = T),
              "\n",
              sep = ""
            ))
            updateSelectInput(session,
                              "data",
                              choices = listData(),
                              selected = "---")
          }
        }
      }
    })
    
    ## - calculate -

    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(session, "calcVar", choices = c("---", varclass(c(
          "numeric", "integer", "Date"
        ))))
      }
    })
    
    output$infoCalc <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        if (input$equation == "")
          cat("Specify equation")
        else {
          checkVarName(input$calcName)
          newVar <-
            try(with(dataInput(), eval(parse(text = input$equation))), silent = T)
          if (class(newVar) %in% c("try-error","function"))
            cat("Equation not complete or not valid")
          else
            print(cbind(newVar,
                        dataInput()[which(unlist(mapply(
                          grepl, colnames(dataInput()), input$equation
                        )))])[1:min(nrow(dataInput()), 18), ])
        }
      }
    })
    
    observeEvent(input$calcVar, {
      if (input$calcVar != "---")
        updateTextInput(session,
                        "equation",
                        value = paste(input$equation, input$calcVar))
    })
    
    observeEvent(input$operator, {
      if (input$operator != "---")
        updateTextInput(session,
                        "equation",
                        value = paste(input$equation, input$operator))
    })
    
    observeEvent(input$assignCal, {
      if (input$data %in% noData)
        stopApp(print(txtNoData))
      else {
        newVar <-
          try(with(dataInput(), eval(parse(text = input$equation))), silent = T)
        if (class(newVar) == "try-error")
          cat("Equation not complete or not valid")
        else {
          newVar <- as.data.frame(list(newVar))
          colnames(newVar) <- make.names(input$calcName)
          assign(input$data, cbind(dataInput(), newVar), pos = .GlobalEnv)
          stopApp(NULL)
        }
      }
    })
    
    observeEvent(input$assignPasteCal, {
      if (input$data %in% noData)
        stopApp(print(txtNoData))
      else{
        newVar <-
          try(with(dataInput(), eval(parse(text = input$equation))), silent = T)
        if (class(newVar) == "try-error")
          cat("Equation not complete or not valid")
        else {
          newVar <- as.data.frame(list(newVar))
          colnames(newVar) <- make.names(input$calcName)
          assign(input$data, cbind(dataInput(), newVar), pos = .GlobalEnv)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              make.names(input$calcName),
              " <- with(",
              input$data,
              ", ",
              input$equation,
              ")\n",
              sep = ""
            )
          )
          stopApp(NULL)
        }
      }
    })
    
    observeEvent(input$assignContinueCal, {
      if (input$data %in% noData)
        stopApp(print(txtNoData))
      else{
        newVar <-
          try(with(dataInput(), eval(parse(text = input$equation))), silent = T)
        if (class(newVar) == "try-error")
          cat("Equation not complete or not valid")
        else {
          newVar <- as.data.frame(list(newVar))
          colnames(newVar) <- make.names(input$calcName)
          assign(input$data, cbind(dataInput(), newVar), pos = .GlobalEnv)
          rstudioapi::insertText(
            paste(
              "\n",
              input$data,
              "$",
              make.names(input$calcName),
              " <- with(",
              input$data,
              ", ",
              input$equation,
              ")\n",
              sep = ""
            )
          )
          updateSelectInput(session,
                            "data",
                            choices = listData(),
                            selected = "---")
        }
      }
    })
    
    observeEvent(input$help, {
      RStudioTools:::browserHelp("variableGadget", "RStudioTools")
    })
    
    observeEvent(input$quit, {
      stopApp("Good bye")
    })
  })
  view <- match.arg(view)
  viewer <- RStudioTools:::selectViewer(view, 800, 800)
  runGadget(ui, server, viewer = viewer)
}
