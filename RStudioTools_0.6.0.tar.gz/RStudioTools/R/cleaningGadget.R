#' @title RStudio Gadget for cleaning data
#' 
#' @description Interactive interface to identify and correct errornous
#' or inconsisten values.
#' 
#' @param view Controls where the gadget is displayed: 'dialog' a new interactive
#' dialogue window, 'pane' the RStudio pane viewer or 'browser' the system default web
#' browser. The pane is usually the most convenient option, but the window size may be
#' too small if the screen size or resolution results in overlapping elements, especially
#' the 'browser' option which provides more space.
#' @details An RStudio addin (shiny gadgets) -
#' runs only with RStudio (v1.1.383 or later). 
#' The application is usually invoked via the Addins pulldown menu
#' (if the toolbar is not visible, choose [View] > [Show toolbars]).
#' The associated R code can be generated (recommended),
#' which will be pasted into the R-script.
#' 
#' The gadget is split into an upper and a lower part separated by the black line.
#' 
#' [select data] pull down menu which lists all data frames available in the
#' R session. If the user has no data frames defined, 'No data in current R
#' session' appears. In this case the application has to be closed and data
#' needs to be be loaded or imported.
#' 
#' The 3 fields [Change value of...], [... to ...] and [... if ...] are used
#' to change values of a variable if a certain condition is fulfilled.
#' Currently, only numeric and text variables are supported.
#' For example, in the dataset 'households' the value 99 represents missing
#' in variable 'agehh'. Selecting 'agehh' in the [Change value of..],
#' NA in [.. to ..] and  typing 'agehh == 99' in [..if..], will change
#' all values of 99 to missing.
#' The number of changes and the approx. first 10 changes (rec-nr:oldvalue->
#' newvalue) are shown in the text output field to the right.
#' Note: recodeing values to missing can be done in a more comfortable way
#' with \code{\link[RStudioTools]{variableGadget}} ([recode] tab).
#' More than 1 variable can be specified in the condition, 
#' e.g. 'sex=="male" | age < 15'. The application checks if the 
#' specified condition is syntactically correct.
#' NOTE: Conditions follow the usual R interpretation: if the condition
#' results in NA the corresponding values will be replaced by NA, too.
#' The change will applied once an [Assign...] button is clicked.
#' [Assign & quit] executes the action and stop the application.
#' [Assign, paste and quit] as above + paste the code into the active
#' R-script at the last curser position. 
#' Make sure that the curser is at an appropriate position before running
#' the application.
#' [Assign, paste & continue] as above but will not stop the application.
#' The \code{\link[RStudioTools]{dataGadget}} ([subset] tab) features
#' an alternative way to detect inconsistencies among 2 variables (but not to
#' correct them).
#' 
#' The lower part of the application is a tab panel with 5 tabs.
#' 
#' [inspect] provides different options to investigate the data.
#' [info] displays number of records and variables, the variable classes
#' (types) using \code{\link[utils]{str}}.
#' [table] displays a table which can be that can be searched, filtered
#' sorted.
#' [summary] displays a summary of all variables,
#' e.g. quantiles, mean and number of missing values for numeric data.
#' The gadget has one additional tab to inspect the missing pattern in
#' the data [missing]. Note that [inspect] presents the original data
#' even if a condition is specified.
#' 
#' [find.duplicates] To identify duplicates all, a single or a few variables can
#' be selected. The output box will show all records, which are identical with
#' respect to the selected variables.
#' 
#' [var.details] shows some basic variable characteristics.
#' If the variable is numeric and has 10 or more unique values,
#' the number of missing values, the range, mean, sd, var, quantiles, 
#' the 5 smallest and largest values, a histogram and a boxplot are shown. 
#' if the selcted variable is a factor or numeric with fewer than 10 unique
#' values, the number of missing observations,
#' a table and a barplot are shown.
#' 
#' [cross.table] is useful to check inconsistencies among 2 variables with
#' few values. E.g. variables sex and pregnancy should never have the
#' combination male and pregnant.
#' It is also useful to check if conditional variables are fitting to each other.
#' Displayed are either counts, row percentages or column percentages.
#' It is also possible to show the table stratified for a 3rd variable
#' (e.g. separate tables for males and females) and it is possible to
#' specify if missing values should be omitted or considered as an own category.
#' 
#' [bivariate] is used to identify bivariate outlier in 2 continuous variables.
#' The variables can be displayed on untransformed scale or log scale.
#' Note that 0 and negative values are omitted on log scale.
#' A third variable can be specified to display the color code. Yellow symbols 
#' represent small, blue symbols large values. Another variable can be selected
#' to show its values as labels next the symbols.
#' It is also possible to drag a rectangle  around some symbols in the plot
#' (keep left mouse button pressed). The value of all observatios inside the 
#' rectangle are displayed in the box on the right side.
#' If the box [jitter] is checked some small noise is added to avoid overplotting.
#' 
#' Additional details and examples are provided in the package vignette (pdf)
#'  \url{/library/RStudioTools/doc/RstudioTools_introduction.pdf}
#' 
#' @examples
#' library(RStudioTools)
#' data("children", package="RStudioTools")
#' 
#' # Now start the gadget (better to start via the [Addins] menu)
#' cleaningGadget()
#' 
#' 
#' # Change tab to [find.duplicates]
#' # Select 'children' in [select data] and 'childid' in [Select variables(s)]
#' # Text output:
#' #  -  rec childid
#' #  - [1,]  58  525
#' #  - [2,] 116  105
#' #  - [3,] 156  105
#' #  - [4,] 175  525
#' # So there are 2 duplicates in the unique identifier
#' 
#' # Anthropometric data often contain erroneous measurements,
#' # e.g. weigh for height Z-scores
#' # Change tab to [var.details] and select 'wfhz' in [Select variables(s)]
#' # We see outlier at the lower side.
#' # A W/H Z-score of below -5 is biologically implausibe - likely an error
#' 
#' # Change tab to [bivariate] and select 'weight' and 'height' in [X/Y variables]
#' # Now one outlier is quite obvious
#' # Select 'childid' as label and 'age' as color variable. 
#' # Drag with the mouse an rectangle around the dot with label 79.
#' # Text output:
#' #  -    weight height  childid
#' #  - 96   8     87.5     79
#' #  The color code indicates that children of the same age are of approx
#' #  same height, i.e. weight is likely incorrect.
#' #  Select weight in [Change value of...], NA in [... to ...] 
#' #  and type 'childid == 79' in [... if ...]
#' 
#' @export
#' @import miniUI rstudioapi shiny
cleaningGadget <-
function(view = c("pane", "dialog", "browser")) {
  ui <- miniPage(
    fillCol(
      fillRow(
        selectInput(
          "data",
          "Select data to manipulate",
          choices = "---",
          selected = 1
        ),
        miniButtonBlock(
          actionButton(
            "help",
            "Help",
            icon = icon("question"),
            style = "color: #ffffff; background-color: #444444"
          ),
          actionButton("quit", "Quit", icon = icon("close"),
                       style = "color: #ffffff; background-color: #444444"),
          border = "bottom"
        ),
        flex = c(3, 1)
      ),
      fillRow(
        selectInput(
          "changeVar",
          "Change value of ...",
          choices = "",
          multiple = F,
          width = "90%"
        ),
        textInput("changeTo", "... to ...", value = "NA",  width = "80%"),
        textInput(
          "changeIf",
          "... if ...",
          placeholder = "age > 99",
          width = "90%"
        )        ,
        verbatimTextOutput("infoChange"),
        flex = c(2, 1, 2, 5)
      ),
      
      miniButtonBlock(
        actionButton("assignChange", "Assign & quit", icon = icon("gears")),
        actionButton(
          "assignPasteChange",
          "Assign, paste code & quit",
          icon = icon("paste")
        ),
        actionButton(
          "assignContinueChange",
          "Assign, paste & continue",
          icon = icon("retweet")
        ),
        border = "bottom",
        style = "border-color: #000000; border-bottom-width: 5px"
      ),
      flex = c(3, 4, 2),
      height = 180
    ),
    
    miniTabstripPanel(
      miniTabPanel(
        "inspect",
        icon = icon("search-plus"),
        miniTabstripPanel(
          miniTabPanel("info", icon = icon("info"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput("str")
                       ))),
          miniTabPanel("table", icon = icon("table"),
                       miniContentPanel(fillCol(
                         dataTableOutput('table')
                       ))),
          miniTabPanel("summary", icon = icon("list-ol"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput('summary')
                       ))),
          miniTabPanel(
            "missing",
            icon = icon("flag-checkered"),
            miniContentPanel(fillRow(
              verbatimTextOutput('missingText'),
              plotOutput('missingPlot'),
              flex = c(1.3, 2)
            ))
          )
        ),
        p("")  # insert space between the nested tab panels
        
      ),
      
      miniTabPanel(
        "find.duplicates",
        icon = icon("tags"),
        miniContentPanel(fillCol(
          #fillRow(
          selectInput(
            "dupliVars",
            "Select variable(s)",
            choices = "-all-",
            multiple = T,
            width = "80%"
          ),
          #  checkboxInput("dupliIgnore", "Ignore missing values") # difficult to implement since incomparable = NA not working fro obvject data frame
          verbatimTextOutput("infoDupli"),
          flex = c(1, 4)
        ))
      ),
      
      miniTabPanel(
        "var.details",
        icon = icon("binoculars"),
        miniContentPanel(
          fillCol(
            selectInput(
              "detailVar",
              "Select variable",
              choices = "---",
              multiple = F,
              width = "40%"
            ),
            plotOutput("plotDetail"),
            verbatimTextOutput("infoDetail"),
            flex = c(1, 4, 3)
          )
        )
      ),

      miniTabPanel(
        "cross.table",
        icon = icon("th-large", lib = "glyphicon"),
        miniContentPanel(fillCol(
          fillRow(
            selectInput(
              "rVarXtab",
              "Select row variable *",
              choices = "---",
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "cVarXtab",
              "Select column variable *",
              choices = "---",
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "sVarXtab",
              "Stratify by",
              choices = "---",
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "cell",
              "Cell stats",
              choices = c(
                "counts" = 0,
                "row %" = 1,
                "col %" = 2
              ),
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "useNA",
              "Use missing",
              choices = c("no", "ifany", "always"),
              multiple = F,
              width = "90%"
            ),
            checkboxInput("addTotal", "Add total"),
            
            #actionButton("copyClip", "Copy to clipboard", icon = icon("close")),
            flex = c(2, 2, 2, 1, 1, 1)
          ),
          verbatimTextOutput("infoXtab"),
          flex = c(1, 5)
        ))
      ),
      
      miniTabPanel(
        "bivariate",
        icon = icon("line-chart"),
        miniContentPanel(fillCol(
          fillRow(
            selectInput(
              "xVarScatter",
              "X variable *",
              choices = "---",
              multiple = F,
              width = "95%"
            ),
            selectInput(
              "yVarScatter",
              "Y variable *",
              choices = "---",
              multiple = F,
              width = "95%"
            ),
            selectInput(
              "labVar",
              "Label variable",
              choices = "---",
              multiple = F,
              width = "95%"
            ),
            selectInput(
              "colVar",
              "Color variable",
              choices = "---",
              multiple = F,
              width = "95%"
            ),
            fillCol(
              checkboxInput("xLog", "Log X"),
              checkboxInput("yLog", "Log Y"),
              height = 50
            ),
            fillCol(
              checkboxInput("jitter", "Jitter"),
              checkboxInput("big", "Big o"),
              height = 50
            ),
            flex = c(5, 5, 5, 5, 2, 2, 2)
          ),
          fillRow(
            plotOutput("plotBivar", brush = "plot_brush"),
            verbatimTextOutput("tabBivar"),
            flex = c(7, 5)
          ),
          
          flex = c(1.2, 5)
        ))
      )
    )
  )
  
  
  server <- (function(input, output, session) {
    
    ## - define common strings -
    
    noData <- c("---", "No data found in current R session")
    txtNoData <- "No data selected"
    txtNoVar <- "No variable selected"
    txtSelData <- "Select data"
    txtSelVar <- "Select variable"
    txtSelVars <- "Select variable(s)"
    
    ## - general functions -
    
    varclass <- function(vclass) {
      return(colnames(dataInput()[sapply(dataInput(), class) %in% vclass]))
    }
    
    ## - choose data -
    
    dataInput <- reactive({
      if (input$data %in% noData)
        NULL
      else
        get(input$data)
    })
    
    listData <- reactive({
      if (length(Filter(
        function(x)
          inherits(get(x), "data.frame"),
        ls(envir = .GlobalEnv)
      )) > 0)
        c("---", Filter(
          function(x)
            inherits(get(x), "data.frame"),
          ls(envir = .GlobalEnv)
        ))
      else
        "No data found in current R session"
    })
    
    observe({
      updateSelectInput(session, "data", choices = listData())
    })
    
    ## - Change expression -
    
    changeValues <- function() {
      return(try(with(dataInput(), ifelse(
        eval(parse(text = input$changeIf)),
        eval(parse(text = input$changeTo)), dataInput()[, input$changeVar]
      )), silent = T)
      )
    }
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(session, "changeVar", choices = c("---", varclass(c(
          "numeric", "integer", "logical", "character"
        ))))
      }
    })
    
    output$infoChange <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        if (input$changeIf == "")
          cat("Specify equation")
        else {
          newVar <- changeValues()
          if (class(newVar) %in% c("try-error","function") |
              length(newVar) != nrow(dataInput()))
            cat("Equation not complete or not valid")
          else {
              index <-
                which((newVar == dataInput()[, input$changeVar]) %in% c(F, NA) & 
                        !(is.na(newVar) & is.na(dataInput()[, input$changeVar])))              
            changeString <-
              paste(
                index,
                ":",
                dataInput()[index, input$changeVar],
                "->",
                newVar[index],
                ", ",
                sep = "",
                collapse = ""
              )
            if (nchar(changeString) > 128)
              changeString <- paste(substr(changeString, 1, 124), "...")
            cat(paste(length(index), "Changes:", changeString))
          }
        }
      }
    })
    
    checkChangeCode <- function() {
      OK <- F
      if (input$data %in% noData)
        print(txtNoData)
      else {
        if (input$changeVar == "---")
          print(txtNoVar)
        else {
          if (input$changeTo == "")
            print("No value to change to specified")
          else {
            newVar <- changeValues()
            if (class(newVar) %in% c("try-error","function") |
                length(newVar) != nrow(dataInput()))
              print("Equation not complete or not valid")
            else
              OK <- T
          }
        }
      }
      return(OK)
    }
    
    observeEvent(input$assignChange, {
      if (checkChangeCode()) {
        newData <- dataInput()
        newData[, input$changeVar] <- changeValues()
        assign(input$data, newData, pos = .GlobalEnv)
        stopApp(NULL)
      }
    })
    observeEvent(input$assignPasteChange, {
      if (checkChangeCode()) {
        newData <- dataInput()
        newData[, input$changeVar] <- changeValues()
        assign(input$data, newData, pos = .GlobalEnv)
        rstudioapi::insertText(
          paste(
            "\n",
            input$data,
            "$",
            input$changeVar,
            " <- with(",
            input$data,
            ", ifelse(",
            input$changeIf,
            ", ",
            input$changeTo,
            ", ",
            input$changeVar,
            "))\n",
            sep = ""
          )
        )
        stopApp(NULL)
      }
    })
    observeEvent(input$assignContinueChange, {
      if (checkChangeCode()) {
        newData <- dataInput()
        newData[, input$changeVar] <- changeValues()
        assign(input$data, newData, pos = .GlobalEnv)
        rstudioapi::insertText(
          paste(
            "\n",
            input$data,
            "$",
            input$changeVar,
            " <- with(",
            input$data,
            ", ifelse(",
            input$changeIf,
            ", ",
            input$changeTo,
            ", ",
            input$changeVar,
            "))\n",
            sep = ""
          )
        )
        updateSelectInput(session,
                          "data",
                          choices = listData(),
                          selected = "---")
        updateSelectInput(session,
                          "changeVar",
                          choices = listData(),
                          selected = "---")
        updateTextInput(session, "changeIf", value = "")
        updateTextInput(session, "changeTo", value = "NA")
      }
    })
    
    ## - inspect -
    
    output$str <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else
        str(
          dataInput(),
          give.attr = F,
          width = 77,
          strict.width = 'cut'
        )
    })
    
    output$table <- renderDataTable({
      dataInput()
    },
    options = list(lengthMenu = list(c(8, 20,-1), c('8', '20', 'All')),
                   pageLength = 8))
    
    output$summary <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        op <- options()
        options(width = 106)
        print(summary(dataInput()))
        options(op)
      }
    })
    
    output$missingPlot <- renderPlot({
      if (!input$data %in% noData) {
        par(mar = c(2.8, 6, 1.5, 1))
        image(
          is.na(dataInput()),
          xaxt = "n",
          yaxt = "n",
          col = c("white", "gray30")
        )
        mtext(
          substr(colnames(dataInput()), 1, 13),
          side = 2,
          at = seq(0, 1, length.out = ncol(dataInput())),
          line = 0.2,
          las = 1
        )
        axis(1,
             at = round(seq(1, nrow(
               dataInput()
             ), length.out = 6)) / nrow(dataInput()),
             label = round(seq(1, nrow(
               dataInput()
             ), length.out = 6)))
        mtext("Record number", side = 1, line = 1.8)
        mtext("Missing data pattern (grey box=missing)",
              side = 3,
              line = 0.2)
        box()
      }
    })#, height=300)
    
    output$missingText <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else{
        op <- options()
        options(width = 38)
        cat("Number of missing values in variable:\n")
        print(apply(dataInput(), 2, function(x)
          sum(is.na(x))))
        options(op)
      }
    })
    
    ## - find duplicates -
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(session, "dupliVars", choices = c("-all-", colnames(dataInput())))
      }
    })
    
    observeEvent(input$dupliVars, {
      if (!input$data %in% noData & length(input$dupliVars) > 1) {
        if (any(input$dupliVars %in% "-all-"))
          updateSelectInput(session, "dupliVars", selected = "-all-")
      }
    })
    
    output$infoDupli <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        if (is.null(input$dupliVars))
          cat(txtSelVars)
        else {
          if (any(!input$dupliVars %in% c("-all-", colnames(dataInput()))))
            cat(txtSelVars)
          else {
            if (any(input$dupliVars %in% "-all-"))
              dvar <- dataInput()
            else
              dvar <- dataInput()[, input$dupliVars]
            if (is.null(dim(dvar))) {
              index <-
                which(rowSums(cbind(
                  duplicated(dvar), duplicated(dvar, fromLast = T)
                )) >= 1)
              res <- cbind(index, dvar[index])
              colnames(res) <- c("rec", input$dupliVars)
              print(res)
            }
            else{
              for (i in ncol(dvar):1)
                dvar <- dvar[order(dvar[, i]),]
              index <-
                rowSums(cbind(duplicated(dvar), duplicated(dvar, fromLast = T))) >= 1
              op <- options()
              options(width = 110)
              cat("Duplicate records:\n")
              print(dvar[index, ])
              options(op)
            }
          }
        }
        
      }
    })
    
    ## - details -
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(
          session,
          "detailVar",
          choices = c("---", varclass(
            c("numeric", "integer", "factor")
          )),
          selected = "---"
        )
      }
    })
    
    output$infoDetail <- renderPrint({
      if (input$data %in% noData)
        cat(txtSelData)
      else {
        if (input$detailVar == "---" |
            !input$detailVar %in% colnames(dataInput()))
          cat(txtSelVar)
        else {
          dvar <- dataInput()[, input$detailVar]
          cat(
            paste(
              "Type: ",
              class(dvar),
              ",  missing: ",
              sum(is.na(dvar)),
              "/",
              length(dvar),
              ",  unique (non-NA) values: ",
              length(unique(na.omit(dvar))),
              sep = ""
            )
          )
          if (class(dvar) %in% c("numeric", "integer"))
            cat(paste(
              ",  range:",
              min(dvar, na.rm = T),
              "-",
              max(dvar, na.rm = T),
              "\n"
            ))
          else
            cat("\n")
          if (length(unique(na.omit(dvar))) < 10 |
              class(dvar) == "factor") {
            cat("\nFrequencies:")
            print(table(noName <- dvar))
          }
          else {
            cat(paste(
              "mean: ",
              round(mean(dvar, na.rm = T), 1),
              ",  sd: ",
              round(sd(dvar, na.rm = T), 1),
              ",  var: ",
              round(var(dvar, na.rm = T), 1),
              "\n",
              sep = ""
            ))
            cat(paste(
              "Quantiles: ",
              paste(
                c("10%", "25%", "50%", "75%", "90%"),
                round(quantile(
                  dvar,
                  probs = c(0.1, 0.25, 0.5, 0.75, 0.9),
                  na.rm = T
                ), 1),
                ", ",
                sep = " ",
                collapse = ""
              ),
              "\n"
            ))
            cat(paste(
              "Smallest values (rec): ",
              paste(
                round(sort(dvar)[1:5], 1),
                " (",
                order(dvar)[1:5],
                "), ",
                sep = "",
                collapse = ""
              ),
              "\n"
            ))
            cat(paste(
              "Largest values (rec): ",
              paste(
                round(sort(dvar, decreasing = T)[1:5], 1),
                " (",
                order(dvar,  decreasing = T)[1:5],
                "), ",
                sep = "",
                collapse = ""
              ),
              "\n"
            ))
          }
        }
      }
    })
    
    output$plotDetail <- renderPlot({
      if (!input$data %in% noData &
          !input$detailVar == "---" &
          input$detailVar %in% colnames(dataInput())) {
        dvar <- dataInput()[, input$detailVar]
        par(mar = c(2, 4, 2, 0) + 0.5)
        if (length(unique(na.omit(dvar))) < 10 |
            class(dvar) == "factor")
          barplot(table(dvar), ylab = "Frequencies")
        else {
          htemp <- hist(dvar, plot = F)
          plot(
            htemp,
            ylim = c(-max(htemp$counts), max(htemp$counts)),
            main = "",
            yaxt = "n",
            xlab = "",
            ylab = ""
          )
          axis(2, at = c(0, max(htemp$counts)))
          boxplot(
            dvar,
            horizontal = T,
            add = T,
            at = -max(htemp$counts) * 0.5,
            boxwex = max(htemp$counts) / 2
          )
          abline(h = 0, lwd = 2)
          mtext(
            c("Boxplot", "Histogramm"),
            side = 2,
            line = 3,
            at = c(-max(htemp$counts) / 2, max(htemp$counts) / 2)
          )
        }
        
      }
    }, height = 240)
    
    ## - X-tab -
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(session, "rVarXtab", choices = c("---", varclass(
          c("numeric", "integer", "factor")
        )))
        updateSelectInput(session, "cVarXtab", choices = c("---", varclass(
          c("numeric", "integer", "factor")
        )))
        updateSelectInput(session, "sVarXtab", choices = c("---", varclass(
          c("numeric", "integer", "factor")
        )))
      }
    })
    
    output$infoXtab <- renderPrint({
      if (!input$data %in% noData &
          input$cVarXtab != "---" &
          input$cVarXtab %in% colnames(dataInput()) &
          input$rVarXtab != "---" &
          input$rVarXtab %in% colnames(dataInput())) {
        if (input$sVarXtab == "---") {
          tab <-
            table(dataInput()[, input$rVarXtab], dataInput()[, input$cVarXtab], useNA =
                    input$useNA)
          if (input$cell != "0")
            tab <- prop.table(tab, as.numeric(input$cell))
          if (input$cell != "0" &
              input$addTotal)
            tab <- addmargins(tab, 3 - as.numeric(input$cell))
          if (input$cell == "0" &
              input$addTotal)
            tab <- addmargins(tab)
        }
        else {
          tab <-
            table(dataInput()[, input$rVarXtab],
                  dataInput()[, input$cVarXtab],
                  dataInput()[, input$sVarXtab],
                  useNA = input$useNA)           # class(tabcount) <- "matrix"
          if (input$cell != "0")
            tab <- prop.table(tab, c(as.numeric(input$cell), 3))
          if (input$cell != "0" &
              input$addTotal)
            tab <- addmargins(tab, 3 - as.numeric(input$cell))
          if (input$cell == "0" &
              input$addTotal)
            tab <- addmargins(tab)
        }
        if (input$cell != "0")
          tab <- round(tab, 3) * 100
        op <- options()
        options(width = 100)
        print(tab)
        options(op)
      }
    })
    
    ## - bivariate -
    
    # function for color code
    rescale100 <-
      function(x)
        ifelse(is.na(x), 1, round((x - min(x, na.rm = T)) / (max(x, na.rm = T) - min(x, na.rm =
                                                                                       T)) * 99 + 1))
    
    observeEvent(input$data, {
      if (!input$data %in% noData) {
        updateSelectInput(session, "xVarScatter", choices = c("---", varclass(c(
          "numeric", "integer"
        ))))
        updateSelectInput(session, "yVarScatter", choices = c("---", varclass(c(
          "numeric", "integer"
        ))))
        updateSelectInput(session,
                          "labVar",
                          choices = c("---", "-record number-", varclass(
                            c("numeric", "integer", "factor", "string")
                          )))
        updateSelectInput(session, "colVar", choices = c("---", varclass(c(
          "numeric", "integer"
        ))))
      }
    })
    
    jitterLog <- function(vals) {
      res <-  suppressWarnings(rnorm(length(vals), mean=vals, sd=abs(vals)*0.06))
      res[vals <= 0] <- NA
      res
    }

    output$plotBivar <- renderPlot({
      if (!input$data %in% noData &
          input$xVarScatter != "---" &
          input$xVarScatter %in% colnames(dataInput()) &
          input$yVarScatter != "---" &
          input$yVarScatter %in% colnames(dataInput())) {
        xvar <- dataInput()[, input$xVarScatter]
        yvar <- dataInput()[, input$yVarScatter]
        NlogNA <- sum(xvar <= 0 | yvar <= 0, na.rm=T)
        # x1perc <- (max(xvar, na.rm = T) - min(xvar, na.rm = T)) / 100
        # y1perc <- (max(yvar, na.rm = T) - min(yvar, na.rm = T)) / 100
        if (input$jitter) {
          if (input$xLog)
            xvar <- jitterLog(xvar)
          else 
            xvar <- jitter(xvar, amount=0)
          if (input$yLog)
            yvar <- jitterLog(yvar)
          else 
            yvar <- jitter(yvar, amount=0)
        }
        if (input$colVar == "---")
          cols = "black"
        else
          cols <-
          rainbow(100, end = 4 / 6)[rescale100(dataInput()[, input$colVar])]
        logscale <- ""
        if (input$xLog)
          logscale <- "x"
        if (input$yLog)
          logscale <- "y"
        if (input$xLog & input$yLog)
          logscale <- "xy"
        par(mar = c(4, 4, 1.2, 1))
        suppressWarnings(
          plot(
            xvar,
            yvar,
            col = cols,
            cex = 1 + input$big,
            lwd = 1 + input$big,
            xlab = input$xVarScatter,
            ylab = input$yVarScatter,
            log = logscale,
            main = ""
          )
        )
        mtext("Brush points with mouse to show records",
              side = 3,
              line = 0.2)
        if (input$labVar != "---") {
          if (input$labVar != "-record number-") {
            labelvar <- round(dataInput()[, input$labVar],2)
            if (class(labelvar) == "numeric") 
              label <- labelvar
            else 
              label <- substr(labelvar, 1, 3)
          }  
          else label <- 1:nrow(dataInput()) 
            text(
              xvar,
              yvar,
              label,
              pos=4,
              offset=input$big/4+0.25)

        }
        if ((input$xLog | input$yLog) & NlogNA > 0) mtext(paste(NlogNA ,"records with values <= 0, omitted on log scale"), side=3, line=-1)
      }
    })
    
    output$tabBivar <- renderPrint({
      if (!input$data %in% noData &
          input$xVarScatter != "---" &
          input$xVarScatter %in% colnames(dataInput()) &
          input$yVarScatter != "---" &
          input$yVarScatter %in% colnames(dataInput())) {
        # With base graphics, need to tell it what the x and y variables are.
        varsToDisplay <- c(input$xVarScatter, input$yVarScatter)
        index <- rowSums(is.na(dataInput()[, varsToDisplay])) == 0
        if (!input$labVar %in% c("---", "-record number-"))
          varsToDisplay <- c(varsToDisplay, input$labVar)
        else if (!input$colVar == "---")
          varsToDisplay <- c(varsToDisplay, input$colVar)
        brushedPoints(
          dataInput()[index, varsToDisplay],
          input$plot_brush,
          xvar = input$xVarScatter,
          yvar = input$yVarScatter
        )
      }
    })
    
    ## - quit and help -
    
    observeEvent(input$help, {
      RStudioTools:::browserHelp("cleaningGadget", "RStudioTools")
    })
    
    observeEvent(input$quit, {
      stopApp("Good bye")
    })
  })
  view <- match.arg(view)
  viewer <- RStudioTools:::selectViewer(view, 800, 900)
  runGadget(ui, server, viewer = viewer)
}
