#' @title RStudio gadget to compare 2 groups
#' 
#' @description Interactive interface to compare 2 groups with respect to
#' an continuouse measure and to generate the associated R-code.
#' Independent and paired data are supported.
#' 
#' @param view Controls where the gadget is displayed: 'dialog' a new interactive
#' dialog window, 'pane' the RStudio pane viewer or 'browser' the system's
#' default web browser. The dialog window is zhe most
#' compfortable option but the window size is fixed (in pixel).
#' if the screen size or resolution results in overlapping elements,
#' especially the option 'browser' provides more space.
#' @details An RStudio addin (shiny gadgets) -
#' runs only with RStudio (v0.99.878 or later). 
#' The application is usually invoked via the Addins pulldown menu
#' (if the toolbar is not visible, choose [View] > [Show toolbars]).
#' The associated R code can be generated (recommended),
#' which will be pasted into the R-script.
#' 
#' The first step is to select [Select data] the dataset. 
#' The tool lists all data frames wich are found in the current R session. 
#' In addition 1 example datasets is available.
#' 
#' [independent] In case of independent data the outcome variable and the
#'  grouping variable have to be selected. If there are more than 2 unique
#' non-missing values in the grouping variables the first 2 values occurring
#' in the data are considered and all other values are ignored and a warning
#' message will be displayed.
#' Only numerical variables qualify as measurement variable whereas numerical,
#' factor or text variables might represent the grouping levels. 
#' The application provides some diagnostic plots to select the apprpriate test.
#' The user can select either the \code{\link[stats]{t.test}} (adjusted or 
#' unadjsusted for unequal variances) or the Mann-Whithney-U-test
#' \code{\link[stats]{wilcox.test}}. 
#' 
#' [paired] The test for paired data follows the same logic, except that the
#' 2 measurements are assumed to be in different variables. The application
#' shows the boxplot, a histogram and a qq-plot of the paired differences.
#' The following tests are available: paired \code{\link[stats]{t.test}},
#' Wilcoxon signed rank test (\code{\link[stats]{wilcox.test}}) and the
#' sign test (via function \code{\link[stats]{binom.test}}).
#' 
#' [inspect] provides different options to investigate the data.
#' [info] displays number of records and variables, the variable classes
#' (types) using \code{\link[utils]{str}}.
#' [table] displays a table which can be that can be searched, filtered
#' sorted.
#' [summary] displays a summary of all variables,
#' e.g. quantiles, mean and number of misssing values for numeric data.
#' 
#' @examples
#' library(RStudioTools)
#' data("birthwt", package="MASS")
#' 
#' # Start the gadget (better to start via the [Addins] menu)
#' twoGroupsGadget()
#' 
#' # Select 'birthwt' in [select data]
#' # Select 'bwt' as [measurement] and 'smoke' as [group]
#' # What arguments would speak for or against each test available?
#' 
#' @export
#' @import miniUI rstudioapi shiny
twoGroupsGadget <-
function(view = c("pane", "dialog", "browser")) {
  ui <- miniPage(
    gadgetTitleBar("compare 2 groups",  right = miniTitleBarButton("help", "Help", primary = TRUE)),
    
    #fillCol(
    selectInput(
      "data",
      "Select data *",
      choices = c("Example 'children'"),
      width = "40%"
    ),
    
    miniTabstripPanel(
      miniTabPanel(
        "independent",
        icon = icon("object-ungroup"),
        fillCol(
          fillRow(
            selectInput(
              "outcome",
              "Select measure variable *",
              choices = c("---"),
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "group",
              "Select group variable *",
              choices = "---",
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "testi",
              "Select test *",
              choices = c(
                "---" = 0,
                "t-test" = 1,
                "t-test (unequal variances)" = 2,
                "Mann-Whitney-U" = 3
              ),
              multiple = F,
              width = "90%"
            )
          ),
          plotOutput("ploti"),
          verbatimTextOutput("texti"),
          miniButtonBlock(actionButton("pasteIndCode", "Paste code into script")),
          flex = c(1, 5, 4, 1)
        )
      ),
      
      miniTabPanel(
        "paired",
        icon = icon("object-group"),
        fillCol(
          fillRow(
            selectInput(
              "pair1",
              "Select 1st variable *",
              choices = c("---"),
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "pair2",
              "Select 2nd variable *",
              choices = "---",
              multiple = F,
              width = "90%"
            ),
            selectInput(
              "testp",
              "Select test *",
              choices = c(
                "---" = 0,
                "paired t-test" = 1,
                "Wilcoxon signed rank" = 2,
                "sign test" = 3
              ),
              multiple = F,
              width = "90%"
            )
          ),
          plotOutput("plotp"),
          verbatimTextOutput("textp"),
          miniButtonBlock(actionButton(
            "pastePairCode", "Paste code into script"
          )),
          flex = c(1, 5.5, 4.5, 1)
        )
      ),
      
      ## standard inspect panel
      
      miniTabPanel(
        "inspect",
        icon = icon("search-plus"),
        miniTabstripPanel(
          miniTabPanel("str", icon = icon("info"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput("str")
                       ))),
          miniTabPanel("table", icon = icon("table"),
                       miniContentPanel(fillCol(
                         dataTableOutput('table')
                       ))),
          miniTabPanel("summary", icon = icon("list-ol"),
                       miniContentPanel(fillCol(
                         verbatimTextOutput('summary')
                       )))
        ),
        p("")
      )
    )
  )
  
  server <- function(input, output, session) {
    # functions
    
    niceP <- function(p.val) {
      if (p.val >= 0.0095)
        nP <- round(p.val, 2)
      else if (p.val < 0.001)
        nP <- "<0.001"
      else
        nP <- round(p.val, 3)
      nP
    }
    
    varclass <- function(vclass) {
      return(colnames(dataInput()[sapply(dataInput(), class) %in% vclass]))
    }
    
    # data input
    
    dataInput <- reactive({
      if (input$data == "Example 'children'") {
        RStudioTools::children
      }
      else
        get(input$data)
    })
    
    sData <- reactive({
      datas <-
        Filter(function(x)
          inherits(get(x), "data.frame"),
          ls(envir = .GlobalEnv))
      c(datas, "Example 'children'")
    })
    
    observe({
      updateSelectInput(session, "data", choices = sData())
    })
    
    observeEvent(input$data,
                 {
                   updateSelectInput(
                     session,
                     "outcome",
                     choices = c("---", varclass(c(
                       "numeric", "integer"
                     ))),
                     selected = "---"
                   )
                   updateSelectInput(session,
                                     "group",
                                     choices = c("---", varclass(
                                       c("numeric", "integer", "logical", "factor", "character")
                                     )),
                                     selected = "---")
                   updateSelectInput(session,
                                     "pair1",
                                     choices = c("---", varclass(c(
                                       "numeric", "integer"
                                     ))),
                                     selected = "---")
                   updateSelectInput(session,
                                     "pair2",
                                     choices = c("---", varclass(c(
                                       "numeric", "integer"
                                     ))),
                                     selected = "---")
                 })
    
    # plot independent
    
    output$ploti <- renderPlot({
      if (all(c(input$outcome, input$group) %in% colnames(dataInput()))) {
        if (length(unique(na.omit(dataInput()[, input$group]))) >= 2)
          par(mfcol = c(2, 3), mar = c(2, 2, 3, 0) + 0.8)
        out <- dataInput()[, input$outcome]
        gr <- unique(na.omit(dataInput()[, input$group]))[1:2]
        gr1 <-
          which(dataInput()[, input$group] %in% gr[1] & !is.na(out))
        gr2 <-
          which(dataInput()[, input$group] %in% gr[2] & !is.na(out))
        boxplot(out[gr1], horizontal = T, cex = 2)
        mtext(
          paste(" Group:", gr[1]),
          side = 3,
          line = -1.5,
          at = min(out[gr1]),
          adj = 0
        )
        mtext("Box-plot",
              side = 3,
              line = 1)
        boxplot(out[gr2], horizontal = T, cex = 2)
        mtext(
          paste(" Group:", gr[2]),
          side = 3,
          line = -1.5,
          at = min(out[gr2]),
          adj = 0
        )
        hist(out[gr1], freq = F, main = "")
        curve(dnorm(x, mean = mean(out[gr1]), sd = sd(out[gr1])),
              col = "red",
              add = T)
        mtext("Histogram",
              side = 3,
              line = 1)
        hist(out[gr2], freq = F, main = "")
        curve(dnorm(x, mean = mean(out[gr2]), sd = sd(out[gr2])),
              col = "red",
              add = T)
        qqnorm(out[gr1], main = "")
        mtext("qq-plot",
              side = 3,
              line = 1)
        qqnorm(out[gr2], main = "")
        
      }
    }, height = 250)
    
    # plot paired
    
    output$plotp <- renderPlot({
      if (all(c(input$pair1, input$pair2) %in% colnames(dataInput()))) {
        par(mfcol = c(1, 3), mar = c(3, 2, 4, 0) + 0.8)
        pdif <-
          (dataInput()[, input$pair1] - dataInput()[, input$pair2])
        boxplot(pdif, horizontal = T, cex = 2)
        mtext(
          paste(" Paired differences"),
          side = 3,
          line = -1.5,
          at = min(pdif),
          adj = 0
        )
        mtext("Box-plot",
              side = 3,
              line = 1)
        hist(pdif, freq = F, main = "")
        curve(dnorm(
          x,
          mean = mean(pdif, na.rm = T),
          sd = sd(pdif, na.rm = T)
        ),
        col = "red",
        add = T)
        mtext("Histogram",
              side = 3,
              line = 1)
        qqnorm(pdif, main = "")
        mtext("qq-plot",
              side = 3,
              line = 1)
      }
    }, height = 250)
    
    # output text
    
    output$texti <- renderPrint({
      if (!all(c(input$outcome, input$group) %in% colnames(dataInput())))
        cat("Outcome and group must be specified")
      else{
        if (length(unique(na.omit(dataInput()[, input$group]))) < 2)
          cat("Group variable should have 2 unique values")
        else{
          if (length(unique(na.omit(dataInput()[, input$group]))) > 2)
            cat(
              "Warning: Group variable has more than 2 unique values, only first 2 will be used!\n"
            )
          out <- dataInput()[, input$outcome]
          gr <- unique(na.omit(dataInput()[, input$group]))[1:2]
          gr1 <-
            which(dataInput()[, input$group] %in% gr[1] &
                    !is.na(out))
          gr2 <-
            which(dataInput()[, input$group] %in% gr[2] &
                    !is.na(out))
          rank1 <-
            sum(rank(c(out[gr1], out[gr2])[1:length(gr1)]))
          rank2 <-
            sum(rank(c(out[gr2], out[gr1])[1:length(gr2)]))
          cat(
            paste(
              "Group",
              gr[1],
              "- N:",
              length(gr1),
              ", mean:",
              round(mean(out[gr1]), 2),
              ", var:",
              round(var(out[gr1]), 2),
              ", mean rank:",
              round(rank1 / length(gr1), 1),
              "\n"
            )
          )
          cat(
            paste(
              "Group",
              gr[2],
              "- N:",
              length(gr2),
              ", mean:",
              round(mean(out[gr2]), 2),
              ", var:",
              round(var(out[gr2]), 2),
              ", mean rank:",
              round(rank2 / length(gr2), 1),
              "\n"
            )
          )
          if (input$testi == 1)
            cat("2 sample t-test H1: true difference in means is not equal to 0\n")
          if (input$testi == 2)
            cat(
              "2 sample t-test adjusted for unequal variance (aka Welch test)\n H1: true diff in means is not equal to 0\n"
            )
          if (input$testi %in% 1:2)
            cat(
              paste(
                "Assumptions:\n - independent observations (not pairs, clusters, time-series)\n",
                "- no significant outliers (check boxplot and histogram)\n",
                "- approximately normally distributed (check qq-plot & histofram, fairly robust if N > 30)\n"
              )
            )
          if (input$testi == 1)
            cat(" - equal variances (fairly robust if N1 ~ N2)\n")
          if (input$testi == 1)
            t.est <- t.test(out[gr1], out[gr2], var.equal = T)
          if (input$testi == 2)
            t.est <- t.test(out[gr1], out[gr2], var.equal = F)
          if (input$testi %in% 1:2)
            cat(
              paste(
                "Difference in means:",
                round(mean(out[gr1] - mean(out[gr2])), 1),
                ", 95% CI:",
                round(t.est[[4]][1], 1),
                "-",
                round(t.est[[4]][2], 1),
                ", t =",
                round(t.est[[1]], 2),
                ", df =",
                round(t.est[[2]], 1),
                ", p =",
                niceP(t.est[[3]])
              )
            )
          if (input$testi == 3) {
            cat(
              paste(
                "Mann-Whitney U test, H1: one population tends to have larger values \n",
                "Assumptions:\n - independent observations (not pairs, clusters, time-series)\n",
                "Note: p-value is not exact in the presence of ties (same values -> shared ranks)\n"
              )
            )
            w.est <-
              suppressWarnings(wilcox.test(out[gr1], y = out[gr2]))
            cat(paste(
              "Difference in mean Ranks:",
              round(mean(out[gr1] - mean(out[gr2])), 1),
              ", U:",
              round(w.est[[1]], 1),
              ", p =",
              niceP(w.est[[3]])
            ))
          }
        }
      }
    })
    
    output$textp <- renderPrint({
      if (!all(c(input$pair1, input$pair2) %in% colnames(dataInput())))
        cat("Two variables must be specified")
      else{
        p1 <- dataInput()[, input$pair1]
        p2 <- dataInput()[, input$pair2]
        ok <- complete.cases(p1, p2)
        if (sum(ok) < 3)
          cat("Less tan 3 complete observations")
        else{
          pdif <- p1[ok] - p2[ok]
          n0 <- sum(pdif[pdif == 0])
          prank <- rank(abs(pdif[pdif != 0]))
          cat(
            paste(
              "N: ",
              sum(ok),
              ", mean ",
              input$pair1,
              ": ",
              round(mean(p1[ok]), 1),
              ", mean ",
              input$pair2,
              ": ",
              round(mean(p2[ok]), 1),
              "\n N (diff. = 0): ",
              n0,
              ", rank sum pos diff.: ",
              round(sum(prank[pdif[pdif != 0] > 0]), 1),
              ", rank sum neg diff.: ",
              round(sum(prank[pdif[pdif != 0] < 0]), 1),
              "\n",
              sep = ""
            )
          )
          if (input$testp == 1)
            cat("paired t-test H1: true difference in means is not equal to 0\n")
          if (input$testp == 2)
            cat("Wilcoxon signed rank test\n H1: true diff in means is not equal to 0\n")
          if (input$testp == 3)
            cat(
              "Sign test\n H1: one variable tend to be higher\n   (probability of pos. diff. is not equal to 0.5)\n"
            )
          if (input$testp != 0)
            cat("Assumptions:\n - paired observations\n")
          if (input$testp == 1) {
            cat(
              " - no significant outliers (check boxplot and histogram)\n - differences are approx normally distributed\n   (check qq-plot & histogram, fairly robust if N > 30)\n"
            )
            t.est <- t.test(p1[ok], p2[ok], paired = T)
            cat(
              paste(
                "Difference in means:",
                round(t.est[[5]], 1),
                ", 95% CI:",
                round(t.est[[4]][1], 1),
                "-",
                round(t.est[[4]][2], 1),
                ", t =",
                round(t.est[[1]], 2),
                ", df =",
                round(t.est[[2]], 1),
                ", p =",
                niceP(t.est[[3]])
              )
            )
          }
          if (input$testp == 2) {
            cat(
              " - no significant outliers (check boxplot and histogram)\n - differences are approx symmetrically distributed\n   (check histogram)\n"
            )
            w.est <-
              suppressWarnings(wilcox.test(p1[ok], y = p2[ok], paired = T))
            cat(paste("W:",
                      round(w.est[[1]], 1),
                      ", p =",
                      niceP(w.est[[3]])))
          }
          if (input$testp == 3) {
            cat(" Note: this test has low statistical power\n")
            s.est <-  binom.test(sum(pdif > 0), sum(pdif != 0))
            cat(paste(
              "N diff > 0:",
              s.est[[1]],
              ", N diff != 0:",
              s.est[[2]],
              ", p =",
              niceP(s.est[[3]])
            ))
          }
        }
      }
    })
    
    # Paste and assign
    
    observeEvent(input$pasteIndCode,
                 {
                   if (!all(c(input$outcome, input$group) %in% colnames(dataInput())) |
                       input$testi == 0)
                     cat("Outcome, group and test must be specified")
                   else{
                     nuval <- length(unique(na.omit(dataInput()[, input$group])))
                     if (nuval < 2)
                       cat("Group variable should have 2 unique values")
                     else{
                       mtxt <-
                         setdiff(paste("testigr", 1:100, sep = ""), ls(pos = .GlobalEnv))[1]
                       dtxt <-
                         ifelse (input$data == "Example 'children'",
                                 "RStudioTools::children",
                                 input$data)
                       #if (input$data == "Example 'children'")
                       #   rstudioapi::insertText("\ndata(\"children\", package=\"RStudioTools\")")
                       if (nuval == 2) {
                         if (input$testi == 1)
                           ttxt <- paste(
                             "t.test(",
                             input$outcome,
                             " ~ ",
                             input$group,
                             ", data = ",
                             dtxt,
                             ", var.equal = T)",
                             sep = ""
                           )
                         if (input$testi == 2)
                           ttxt <- paste(
                             "t.test(",
                             input$outcome,
                             " ~ ",
                             input$group,
                             ", data = ",
                             dtxt,
                             ", var.equal = F)",
                             sep = ""
                           )
                         if (input$testi == 3)
                           ttxt <- paste(
                             "wilcox.test(",
                             input$outcome,
                             " ~ ",
                             input$group,
                             ", data = ",
                             dtxt,
                             ")",
                             sep = ""
                           )
                       }
                       if (nuval > 2) {
                         gr <- unique(na.omit(dataInput()[, input$group]))[1:2]
                         if (!is.numeric(gr))
                           gr <- paste("\"", gr, "\"", sep = "")
                         rstudioapi::insertText(paste(
                           "\ntable(",
                           dtxt,
                           "$",
                           input$group,
                           ", useNA=\"ifany\")",
                           sep = ""
                         ))
                         if (input$testi == 1)
                           ttxt <- paste(
                             "t.test(",
                             input$outcome,
                             " ~ ",
                             input$group,
                             ", data = ",
                             dtxt,
                             ", subset = ",
                             dtxt,
                             "$",
                             input$group,
                             " %in% c(",
                             gr[1],
                             ", ",
                             gr[2],
                             ")",
                             ", var.equal = T)",
                             sep = ""
                           )
                         if (input$testi == 2)
                           ttxt <- paste(
                             "t.test(",
                             input$outcome,
                             " ~ ",
                             input$group,
                             ", data = ",
                             dtxt,
                             ", subset = ",
                             dtxt,
                             "$",
                             input$group,
                             " %in% c(",
                             gr[1],
                             ", ",
                             gr[2],
                             ")",
                             ", var.equal = F)",
                             sep = ""
                           )
                         if (input$testi == 3)
                           ttxt <- paste(
                             "wilcox.test(",
                             input$outcome,
                             " ~ ",
                             input$group,
                             ", data = ",
                             dtxt,
                             ", subset = ",
                             dtxt,
                             "$",
                             input$group,
                             " %in% c(",
                             gr[1],
                             ", ",
                             gr[2],
                             "))",
                             sep = ""
                           )
                       }
                       rstudioapi::insertText(paste("\n", mtxt, " <- ", ttxt, "\n", mtxt, "\n",
                                                    sep = ""))
                       assign(mtxt, eval(parse(text = ttxt)), pos = .GlobalEnv)
                     }
                   }
                 })
    
    observeEvent(input$pastePairCode,
                 {
                   if (!all(c(input$pair1, input$pair2) %in% colnames(dataInput())) |
                       input$testp == 0)
                     cat("2 variables and test must be specified")
                   else {
                     mtxt <-
                       setdiff(paste("testpgr", 1:100, sep = ""), ls(pos = .GlobalEnv))[1]
                     dtxt <-
                       ifelse (input$data == "Example 'children'",
                               "RStudioTools::children",
                               input$data)
                     # if (input$data == "Example 'children'")
                     #   rstudioapi::insertText("\ndata(\"children\", package=\"RStudioTools\")")
                     if (input$testp == 1)
                       ttxt <- paste(
                         "t.test(",
                         dtxt,
                         "$",
                         input$pair1,
                         ", ",
                         dtxt,
                         "$",
                         input$pair2,
                         ", paired = T)",
                         sep = ""
                       )
                     if (input$testp == 2)
                       ttxt <- paste(
                         "wilcox.test(",
                         dtxt,
                         "$",
                         input$pair1,
                         ", ",
                         dtxt,
                         "$",
                         input$pair2,
                         ", paired = T)",
                         sep = ""
                       )
                     if (input$testp == 3)
                       ttxt <- paste(
                         "binom.test(sum(na.omit(",
                         dtxt,
                         "$",
                         input$pair1,
                         " - ",
                         dtxt,
                         "$",
                         input$pair2,
                         " > 0)) , sum(na.omit(",
                         dtxt,
                         "$",
                         input$pair1,
                         " - ",
                         dtxt,
                         "$",
                         input$pair2,
                         " != 0)))",
                         sep = ""
                       )
                     rstudioapi::insertText(paste("\n", mtxt, " <- ", ttxt, "\n", mtxt, "\n",
                                                  sep = ""))
                     assign(mtxt, eval(parse(text = ttxt)), pos = .GlobalEnv)
                   }
                 })
    
    ## standard inspect output when no data not possible
    ## - inspect -
    
    output$str <- renderPrint({
      str(
        dataInput(),
        give.attr = F,
        width = 70,
        strict.width = 'cut'
      )
    })
    
    output$table <- renderDataTable({
      dataInput()
    },
    options = list(pageLength = 7,  lengthMenu = c(5, 10, 25)))
    output$summary <- renderPrint({
      op <- options()
      options(width = 85)
      print(summary(dataInput()))
      options(op)
    })
    
    observeEvent(input$help, {
      RStudioTools:::browserHelp("twoGroupsGadget", "RStudioTools")
    })
    
    observeEvent(input$cancel, {
      stopApp(print("Good bye"))
    })
  }
  
  view <- match.arg(view)
  viewer <- RStudioTools:::selectViewer(view, height = 800, width = 750)
  runGadget(ui, server, viewer = viewer, stopOnCancel = F)
}
