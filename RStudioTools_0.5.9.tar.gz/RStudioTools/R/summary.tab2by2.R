#' @export
summary.tab2by2 <-
function (object) 
{
    print(object$call)
    cat(paste("\n", ifelse(object$ratio.type == "OR", "Odds ratio: ", 
        "Relative risk (risk ratio): "), round(object$ratio, 
        4), sep = ""))
    cat(paste("\nNumber of observations:", object$N, ifelse(object$N.na > 
        0, paste("(", object$N.na, " observations deleted due to missingness)", 
        sep = ""), "")))
    cat("\n\n2 x 2 table")
    print(addmargins(object$table))
    cat("\nEstimates\n")
    print(format(object$result, width = 8, quote = F, justify = "right"))
    cat(paste("\nConfidence interval estimation:", object$conf.type, 
        "\nP-value estimation: Fisher exact\n"))
}
