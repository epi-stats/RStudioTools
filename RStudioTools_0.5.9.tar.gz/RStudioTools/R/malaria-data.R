#' Hypothetical malaria data
#'
#' A dataset containing basic demographic and morbidity data.
#' Although the data are artificially generated, they behave roughly as in
#' Hagmann et al. 2003 Malaria Journal 2:15.
#'
#' \itemize{
#'   \item id unique identifier 
#'   \item sex m/f
#'   \item age in years
#'   \item net availability of a mosquito net (1: yes, 2: no)
#'   \item holes presence of holes in the house (1: yes, : no)
#'   \item pcv packed cell volume
#'   \item temp body temperature in Celsius
#'   \item pf Plasmodium falciparum per microliter blood
#'   \item pos Plasmodium falciparum infection (1: yes, 0: no)
#' }
#'
#' @format A data frame with 400 records and 9 variables
#' @docType data
#' @usage data("malaria")
"malaria"
