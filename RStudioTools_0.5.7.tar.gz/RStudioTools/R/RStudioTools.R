#' Several RStudio addins which are especially useful for R Beginners.
#'
#' RStudioTools allows you to execute many data import, management and
#' cleaning via interactive menues (called addins).
#'
#' The results are usually 'previewed'
#' to ensure that the result is as expected.
#'
#' Since especially data manipulation and management oprtaions are less
#' intuitive for beginners, the learning curve of R is expected to be steeper.
#' In addition the code to reproduce can be pasted into the R script,
#' which is highly recommended. Because some actions are very flexible
#' the genrated code might not always be the code with best readability.
#' Some basic data analysis tools (esspecially useful for biostatistics)
#' are also implemented.
#'
#' Since R and Rstudio are nor responsive when the application is running.
#' The corresponding help files are always shown in the default browser 
#' independent from the help settings in RStudio.
#' Additional details and examples are provided in the package vignette (pdf)
#'  \url{/library/RStudioTools/doc/RstudioTools_introduction.pdf}
#'
#' Note: Some of the tools might not work as expected if the data are imported
#' from Stata, SPSS or SAS using the haven package.
#' The following line should resolve the problem:
#'
#' data <- data.frame(mydata) 
#'
#' If the problem persists, it is always be possible to write the data in ASCII
#' format and to reload it again:
#'
#' write.table(mydata, 'mydata.txt')
#' mydata <- read.table('mydata.txt')
#'
"_PACKAGE"
