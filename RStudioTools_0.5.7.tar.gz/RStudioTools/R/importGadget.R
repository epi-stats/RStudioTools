#' @title RStudio gadget to import data
#' 
#' @description Interactive interface for data import. Supported are plain
#' text (CSV), Excel and Stata files.
#' 
#' @param view Controls where the gadget is displayed: 'dialog' a new interactive
#' dialog window, 'pane' the RStudio pane viewer or 'browser' the system's
#' default web browser. The dialog window is zhe most
#' compfortable option but the window size is fixed (in pixel).
#' if the screen size or resolution results in overlapping elements,
#' especially the option 'browser' provides more space.
#' @details An RStudio addin (shiny gadgets) -
#' runs only with RStudio (v0.99.878 or later). 
#' The application is usually invoked via the Addins pulldown menu
#' (if the toolbar is not visible, choose [View] > [Show toolbars]).
#' The associated R code can be generated (recommended),
#' which will be pasted into the R-script.
#' 
#' Click [Choose file to import] to open a
#' file browser and navigate to the data file.
#' [Name of imported data] the name of the imported data in R. 
#' If no (valid) name is provided a name will generated (usually X).
#' If an object with the specified name already exisis, 
#' a warning message will appear but the command can be executed (the object
#' will be replcaed).
#' 
#' The tab panel offers options for different data formats: [CSV], [Excel]
#' or [Stata]. A preview of the data is shown to ensure appropriate settings.
#' 
#' [CSV] to import plain text files where values are seperated by tab, space,
#' comma or semicolon (usually with file extensions .txt, .csv or .raw).
#' The data import is done by calling \code{\link[utils]{read.csv}}.
#' 
#' [Excel] Excel files are imported via \code{\link[readxl]{read_excel}}.
#' 
#' [Stata] Stata files are imported via \code{\link[foreign]{read.dta}}.
#' Only Stata data files saved in version 12 or below are supported.
#' In Stata versions 13+ the data needs to be saved in old format: 
#' \itemize{
#' \item saveold mydata.dta, version(12)
#' }
#' 
#' The import of large excel files or files located on a server can be slow.
#' 
#' [Assign & quit] executes the action and stop the application.
#' [Assign, paste and quit] as above + paste the code into the active
#' R-script at the last curser position. 
#' Make sure that the curser is at an appropriate postion before running
#' the application.
#' [Assign, paste & continue] as above but will not stop the application.
#' 
#' Additional details and examples are provided in the package vignette (pdf)
#'  \url{/library/RStudioTools/doc/RstudioTools_introduction.pdf}
#' 
#' @examples
#' library(RStudioTools)
#' 
#' # Look for an Excel file shipped with the readxl package
#' system.file("extdata/datasets.xlsx",package="readxl")
#' 
#' # Now start the gadget (better to start via the [Addins] menu)
#' importGadget()
#' 
#' # Click the [Choose file to import] button and navigate to 'datasets.xlsx'
#' # Change to [Excel] tab and select the sheet you would like to import 
#' 
#' @export
#' @import miniUI rstudioapi shiny readxl foreign
importGadget <-
function(view = c("pane", "dialog", "browser")) {
  ui <- miniPage(
    fillCol(
      fillRow(
        miniButtonBlock(actionButton("selectFile", "Choose file to import"),
                        border = "bottom"),
        miniButtonBlock(
          actionButton(
            "help",
            "Help",
            icon = icon("question"),
            style = "color: #ffffff; background-color: #444444"
          ),
          actionButton("quit", "Quit", icon = icon("close"),
                       style = "color: #ffffff; background-color: #444444"),
          border = "bottom"
        ),
        flex = c(3, 1)
      ),
      textInput("dataname", "Name of imported data", value = "mydata"),
      verbatimTextOutput("warnData"),
      height = 180
    ),
    
    miniTabstripPanel(
      miniTabPanel("CSV", icon = icon("table"),
                   miniContentPanel(
                     fillCol(
                       fillRow(
                         checkboxInput('headercsv', 'Header', TRUE),
                         radioButtons(
                           'sep',
                           'Separator',
                           c(
                             Comma = ',',
                             Semicolon = ';',
                             Tab = '\t',
                             Space = ''
                           ),
                           ','
                         ),
                         radioButtons(
                           'quote',
                           'Quote',
                           c(
                             None = '',
                             'Double Quote' = '"',
                             'Single Quote' = "'"
                           ),
                           '"'
                         )
                       ),
                       verbatimTextOutput("strcsv")
                     )
                   )),
      
      miniTabPanel("excel", icon = icon("file-excel-o"),
                   miniContentPanel(
                     fillCol(
                       fillRow(
                         selectInput(
                           "scheetxls",
                           "Sheet",
                           choices = "",
                           multiple = F,
                           width = "80%"
                         ),
                         checkboxInput('headerxls', 'Header', TRUE,
                                       width = "80%"),
                         numericInput(
                           "skipxls",
                           "Skip rows",
                           value = 0,
                           min = 0,
                           max = 99,
                           step = 1,
                           width = "80%"
                         )
                         ,
                         flex = c(3, 1, 1)
                       ),
                       verbatimTextOutput("strxls")
                     )
                   )),
      
      miniTabPanel("STATA", icon = icon("th"),
                   miniContentPanel(
                     fillCol(fillRow(
                       checkboxInput('factorstata', 'Use labels', F)
                     ),
                     verbatimTextOutput("strstata"))
                   ))
    ),
    
    miniButtonBlock(
      actionButton("assign", "Assign & quit", icon = icon("gears")),
      actionButton("assignPaste", "Assign, paste code & quit", icon = icon("paste")),
      actionButton(
        "assignContinue",
        "Assign, paste & continue",
        icon = icon("retweet")
      )
    )
  )
  
  server <- (function(input, output, session) {
    filePath <- "No file selected"
    
    observeEvent(input$selectFile, {
      tryCatch(.path <- file.choose(), error = function(x){}) # do nothing on cancel error
      if (exists(".path"))
        filePath <<- .path
    })
    
    output$warnData <- renderPrint({
      if (input$selectFile > 0)
        cat("")
      if (nchar(filePath) < 80)
        cat(paste(filePath, "\n"))
      else
        cat(paste("...", substr(
          filePath, nchar(filePath) - 77, nchar(filePath)
        ), "\n"))
      if (input$dataname != make.names(input$dataname))
        cat(paste(
          "Warning: no (valid) name specified, using '",
          make.names(input$dataname),
          "'\n",
          sep = ""
        ))
      if (make.names(input$dataname) %in% ls(envir = .GlobalEnv))
        cat(
          paste(
            "Warning: there is already an object called '",
            make.names(input$dataname),
            "' (assign will replace)",
            sep = ""
          )
        )
    })
    
    output$strcsv <- renderPrint({
      if (input$selectFile > 0)
        cat("")
      if (filePath == "No file selected")
        print("---")
      else{
        if (!substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".csv", ".txt", ".tsv", ".tab"))
          cat("Warning: File extension not .csv, .txt, .tsv, .tab")
        else{
          dtemp <-
            read.csv(
              filePath,
              header = input$headercsv,
              sep = input$sep,
              quote = input$quote,
              nrows = 3
            )
          print(dtemp[, 1:min(6, dim(dtemp)[2])])
        }
      }
    })
    
    sheetsExcel <- reactive({
      if (input$selectFile > 0)
        cat("")
      if (filePath == "No file selected")
        c("---")
      else {
        if (!substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".xls", "xlsx"))
          c("File extension not .xls(x)")
        else {
          es <- readxl::excel_sheets(filePath)
          c(es)
        }
      }
    })
    
    observe({
      updateSelectInput(session, "scheetxls", choices = sheetsExcel())
    })
    
    output$strxls <- renderPrint({
      if (input$selectFile > 0)
        cat("")
      if (input$scheetxls == "---")
        cat("Excel sheet needs to be specified")
      else{
        try(dtemp <-
              readxl::read_excel(
                filePath,
                sheet = input$scheetxls,
                col_names = input$headerxls,
                skip = input$skipxls
              ),
            silent = T)
        if (exists("dtemp"))
          print(dtemp[1:3, 1:min(6, dim(dtemp)[2])])
      }
    })
    
    output$strstata <- renderPrint({
      cat("Note: Only Stata format up to V12 is supported (use in Stata 'saveold' otherwise)\n")
      if (input$selectFile > 0)
        cat("")
      if (filePath == "No file selected")
        print("---")
      else{
        if (!substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".dta"))
          cat("Warning: File extension not .dta")
        else{
          try(dtemp <-
                foreign::read.dta(filePath, convert.factors = input$factorstata))
          if (exists("dtemp"))
            print(dtemp[1:3, 1:min(6, dim(dtemp)[2])])
          else
            cat("Error: Not a Stata version 5-12 .dta file?")
        }
      }
    })
    
    observeEvent(input$assign, {
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".csv", ".txt", ".tsv", ".tab")) {
        assign(
          make.names(input$dataname),
          read.csv(
            filePath,
            header = input$headercsv,
            sep = input$sep,
            quote = input$quote
          ),
          pos = .GlobalEnv
        )
        stopApp(print(paste(
          "#", make.names(input$dataname), "created"
        )))
      }
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".xls", "xlsx")) {
        assign(
          make.names(input$dataname),
          readxl::read_excel(
            filePath,
            sheet = input$scheetxls,
            col_names = input$headerxls,
            skip = input$skipxls
          ),
          pos = .GlobalEnv
        )
        stopApp(print(paste(
          "#", make.names(input$dataname), "created"
        )))
      }
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".dta")) {
        assign(
          make.names(input$dataname),
          foreign::read.dta(filePath, convert.factors = input$factorstata),
          pos = .GlobalEnv
        )
        stopApp(print(paste(
          "#", make.names(input$dataname), "created"
        )))
      }
    })
    
    observeEvent(input$assignPaste, {
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".csv", ".txt", ".tsv", ".tab")) {
        assign(
          make.names(input$dataname),
          read.csv(
            filePath,
            header = input$headercsv,
            sep = input$sep,
            quote = input$quote3
          ),
          pos = .GlobalEnv
        )
        txt <-
          paste(
            "\n",
            make.names(input$dataname),
            "<- read.csv(\"",
            gsub("\\", "/", filePath, fixed = T),
            "\"",
            ", header = " ,
            input$headercsv,
            ", sep = \"",
            input$sep,
            "\"",
            ", quote = \"",
            gsub("\"", "\\\"", input$quote, fixed = T),
            "\")",
            sep = ""
          )
        rstudioapi::insertText(paste(txt, "\n"))
        stopApp(print(paste(
          "#", make.names(input$dataname), "created"
        )))
      }
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".xls", "xlsx")) {
        assign(
          make.names(input$dataname),
          readxl::read_excel(
            filePath,
            sheet = input$scheetxls,
            col_names = input$headerxls,
            skip = input$skipxls
          ),
          pos = .GlobalEnv
        )
        txt <- paste(
          "\nlibrary(readxl)\n",
          make.names(input$dataname),
          "<- read_excel(\"",
          gsub("\\", "/", filePath, fixed = T),
          "\"",
          ", sheet = \"" ,
          input$scheetxls,
          "\"",
          ", col_names = ",
          input$headerxls,
          ", skip = ",
          input$skipxls,
          ")",
          sep = ""
        )
        rstudioapi::insertText(paste(txt, "\n"))
        stopApp(print(paste(
          "#", make.names(input$dataname), "created"
        )))
      }
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".dta")) {
        assign(
          make.names(input$dataname),
          foreign::read.dta(filePath, convert.factors = input$factorstata),
          pos = .GlobalEnv
        )
        txt <- paste(
          "\nlibrary(foreign)\n",
          make.names(input$dataname),
          "<- read.dta(\"",
          gsub("\\", "/", filePath, fixed = T),
          "\"",
          ", convert.factors = ",
          input$factorstata,
          ")",
          sep = ""
        )
        rstudioapi::insertText(paste(txt, "\n"))
        stopApp(print(paste(
          "#", make.names(input$dataname), "created"
        )))
      }
    })
    
    observeEvent(input$assignContinue, {
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".csv", ".txt", ".tsv", ".tab")) {
        assign(
          make.names(input$dataname),
          read.csv(
            filePath,
            header = input$headercsv,
            sep = input$sep,
            quote = input$quote3
          ),
          pos = .GlobalEnv
        )
        txt <-
          paste(
            "\n",
            make.names(input$dataname),
            "<- read.csv(\"",
            gsub("\\", "/", filePath, fixed = T),
            "\"",
            ", header = " ,
            input$headercsv,
            ", sep = \"",
            input$sep,
            "\"",
            ", quote = \"",
            gsub("\"", "\\\"", input$quote, fixed = T),
            "\")",
            sep = ""
          )
        rstudioapi::insertText(paste(txt, "\n"))
        print(paste("#", make.names(input$dataname), "created"))
      }
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".xls", "xlsx")) {
        assign(
          make.names(input$dataname),
          readxl::read_excel(
            filePath,
            sheet = input$scheetxls,
            col_names = input$headerxls,
            skip = input$skipxls
          ),
          pos = .GlobalEnv
        )
        txt <- paste(
          "\nlibrary(readxl)\n",
          make.names(input$dataname),
          "<- read_excel(\"",
          gsub("\\", "/", filePath, fixed = T),
          "\"",
          ", sheet = \"" ,
          input$scheetxls,
          "\"",
          ", col_names = ",
          input$headerxls,
          ", skip = ",
          input$skipxls,
          ")",
          sep = ""
        )
        rstudioapi::insertText(paste(txt, "\n"))
        print(paste("#", make.names(input$dataname), "created"))
      }
      if (substr(filePath, nchar(filePath) - 3, nchar(filePath)) %in% c(".dta")) {
        assign(
          make.names(input$dataname),
          foreign::read.dta(filePath, convert.factors = input$factorstata),
          pos = .GlobalEnv
        )
        txt <- paste(
          "\nlibrary(foreign)\n",
          make.names(input$dataname),
          "<- read.dta(\"",
          gsub("\\", "/", filePath, fixed = T),
          "\"",
          ", convert.factors = ",
          input$factorstata,
          ")",
          sep = ""
        )
        rstudioapi::insertText(paste(txt, "\n"))
        print(paste("#", make.names(input$dataname), "created"))
      }
    })
    
    observeEvent(input$help, {
      RStudioTools:::browserHelp("importGadget", "RStudioTools")
    })
    
    observeEvent(input$quit, {
      stopApp("Good bye")
    })
    
  })
  
  view <- match.arg(view)
  viewer <- RStudioTools:::selectViewer(view, 700, 700)
  runGadget(ui, server, viewer = viewer)

}
