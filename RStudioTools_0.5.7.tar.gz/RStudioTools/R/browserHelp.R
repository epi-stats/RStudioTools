#' @export
browserHelp <-
function (fun, pkg) 
{
    .saveOptBr <- getOption("browser")
    WINDOWS <- .Platform$OS.type == "windows"
    if (WINDOWS) 
        options(browser = NULL)
    else options(browser = Sys.getenv("R_BROWSER"))
    print(help(fun, package = paste(pkg), help_type = "html"))
    options(browser = .saveOptBr)
}
